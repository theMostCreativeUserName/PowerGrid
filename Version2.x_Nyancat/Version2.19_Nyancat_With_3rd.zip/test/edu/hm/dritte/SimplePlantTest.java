package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static edu.hm.cs.rs.powergrid.datastore.Resource.Coal;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Garbage;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Oil;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Uranium;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class SimplePlantTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // constructor and getter
    @Test(expected = IllegalArgumentException.class)
    public void constructorInvalidNumber() {
        factory.newPlant(-1, Plant.Type.Coal, 5, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorInvalidResources() {
        factory.newPlant(14, Plant.Type.Eco, -4, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorNegativeCities() {
        factory.newPlant(14, Plant.Type.Eco, 143, -1);
    }

    @Test (expected = IllegalArgumentException.class)
    public void constructorZeroCities() {
        factory.newPlant(14, Plant.Type.Eco, 143, 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorTypeNull() {
        factory.newPlant(14, null, 143, 41);
    }

    @Test
    public void getAll1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        assertEquals(1, sut.getNumber());
        assertEquals(Plant.Type.Oil, sut.getType());
        assertEquals(2, sut.getNumberOfResources());
        assertEquals(3, sut.getCities());
    }

    @Test
    public void getAll2() {
        final Plant sut = factory.newPlant(4, Plant.Type.Coal, 5, 6);
        assertEquals(4, sut.getNumber());
        assertEquals(Plant.Type.Coal, sut.getType());
        assertEquals(5, sut.getNumberOfResources());
        assertEquals(6, sut.getCities());
    }

    @Test
    public void getAll3() {
        final Plant sut = factory.newPlant(7, Plant.Type.Garbage, 8, 9);
        assertEquals(7, sut.getNumber());
        assertEquals(Plant.Type.Garbage, sut.getType());
        assertEquals(8, sut.getNumberOfResources());
        assertEquals(9, sut.getCities());
    }

    @Test
    public void getAll4() {
        final Plant sut = factory.newPlant(10, Plant.Type.Fusion, 11, 12);
        assertEquals(10, sut.getNumber());
        assertEquals(Plant.Type.Fusion, sut.getType());
        assertEquals(11, sut.getNumberOfResources());
        assertEquals(12, sut.getCities());
    }

    @Test
    public void getAll5() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        assertEquals(0, sut.getNumber());
        assertEquals(Plant.Type.Oil, sut.getType());
        assertEquals(0, sut.getNumberOfResources());
        assertEquals(1, sut.getCities());
    }

    // hasOperated and setOperated
    @Test
    public void hasOperated() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        assertFalse(sut.hasOperated());
    }

    @Test
    public void hasOperatedTrue() {
        final Plant sut = factory.newPlant(0, Plant.Type.Fusion, 0, 1);
        sut.setOperated(true);
        assertTrue(sut.hasOperated());
    }

    @Test
    public void hasOperatedFalse() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        sut.setOperated(false);
        assertFalse(sut.hasOperated());
    }

    @Test
    public void hasOperatedTrueThenFalse() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        sut.setOperated(true);
        assertTrue(sut.hasOperated());
        sut.setOperated(false);
        assertFalse(sut.hasOperated());
    }


}
