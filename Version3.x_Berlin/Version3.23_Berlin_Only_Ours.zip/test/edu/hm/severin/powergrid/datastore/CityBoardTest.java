package edu.hm.severin.powergrid.datastore;


import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Board;
import edu.hm.cs.rs.powergrid.datastore.City;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import org.junit.Assert;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.Set;

import static org.junit.Assert.*;


/**
 * test for city and board classes.
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @author Severin
 */
public class CityBoardTest{
    @Rule public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    private final String fqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory"; // package path

    private final Factory factory = Factory.newFactory(fqcn);

    private City getCity(String name, int region){  // specific City
        return factory.newCity(name, region);
    }
    private Board getBoardGermany(){  // specific Board
        return factory.newBoard(new EditionGermany());
    }

    // ------------------------------------------- Tests -----------------------------------------------------
    @Test public void newCity() {
        // arrange
        City sut = getCity("Entenhausen", 1);
        // act
        // assert
        assertEquals("Entenhausen", sut.getName());
        assertEquals(1, sut.getRegion());
    }
    @Test (expected =  IllegalArgumentException.class)
    public void newIllegalCity1() {
        // arrange
        City sut = getCity("", 1);
    }
    @Test (expected =  NullPointerException.class)
    public void newIllegalCity2() {
        // arrange
        City sut = getCity(null, 1);
    }
    @Test (expected =  IllegalArgumentException.class)
    public void newIllegalCity3() {
        // arrange
        City sut = getCity("", 0);
    }
    @Test (expected =  IllegalArgumentException.class)
    public void newIllegalCity4() {
        // arrange
        City sut = getCity("AnotherCity", -1);
    }
    @Test public void getCityName() {
        // arrange
        City sut = getCity("Entenhausen", 1);
        assertEquals(sut.getName(), "Entenhausen");
    }

    @Test public void getCityArea() {
        // arrange
        City sut = getCity("Entenhausen", 1);
        assertEquals(sut.getRegion(), 1);
    }
    @Test public void connectCity1(){
        City sut = getCity("city", 1);
        City sat = getCity("city2", 2);
        sut.connect(sat, 30);
        assertEquals("{city2 2=30}",sut.getConnections().toString());
    }
    @Test (expected = IllegalArgumentException.class)
    public void connectCity2(){
        City sut = getCity("city", 1);
        City sat = getCity("city2", 2);
        sut.connect(sat, -1);
        assertEquals("{city2 2=30}",sut.getConnections().toString());
    }
    @Test (expected = IllegalArgumentException.class)
    public void connectCity3(){
        City sut = getCity("city", 1);
        sut.connect(sut, 30);
        assertEquals("{city2 2=30}",sut.getConnections().toString());
    }
    @Test (expected = IllegalArgumentException.class)
    public void connectCity4(){
        City sut = getCity("city", 1);
        City sat = getCity("city2", 2);
        sut.connect(sat, 30);
        sut.connect(sat, 30);
        assertEquals("{city2 2=30}",sut.getConnections().toString());
    }
    @Test (expected = IllegalArgumentException.class)
    public void connectCity5(){
        City sut = getCity("city", 1);
        City sat = getCity("city2", 2);
        sut.connect(sat, 30);
        sut.connect(sat, 50);
        assertEquals("{city2 2=30}",sut.getConnections().toString());
    }
    @Test (expected = IllegalStateException.class)
    public void connectCity6(){
        City sut = getCity("city", 1);
        City sat = getCity("city2", 2);
        sut.close();
        sut.connect(sat, 30);
        assertEquals("{city2 2=30}",sut.getConnections().toString());
    }

    @Test (expected = IllegalStateException.class)
    public void closeBoard(){
        Board sut = getBoardGermany();
        sut.close();
        sut.close();
    }
    @Test public void newBoard() {
        // arrange
        Board sut = getBoardGermany();
        // act
        sut.close();
        // assert
        assertFalse(sut.getCities().isEmpty());
    }
    @Test (expected = NullPointerException.class)
    public void newIllegalBoard(){
        Board sut = factory.newBoard(null);
    }
    @Test public void newBoardFindCity1() {
        // arrange
        Board sut = getBoardGermany();
        // act
        sut.close();
        // assert
        assertEquals(getCity("W\u00FCrzburg",4).toString(), sut.findCity("W\u00FCrzburg").toString());
    }
    @Test public void newBoardFindCity2() {

        Board sut = getBoardGermany();

        assertEquals(null, sut.findCity("Japan"));
    }
    @Test public void closeRegionsBoard1(){
        Board sut = getBoardGermany();
        sut.closeRegions(2);
        assertEquals(null, sut.findCity("M\u00FCnchen"));
    }
    @Test (expected = NullPointerException.class)
    public void closeRegionsBoard2(){
        Board sut = getBoardGermany();
        sut.closeRegions(2);
        assertEquals(null, sut.findCity("M\u00FCnchen").getConnections());
    }
    @Test (expected = IllegalStateException.class)
    public void closeRegionsBoard4(){
        Board sut = getBoardGermany();
        sut.close();
        sut.closeRegions(2);
    }
    @Test public void closeRegionsBoard3(){
        Board sut = getBoardGermany();
        sut.closeRegions(2);
        assertEquals(14,sut.getCities().size() );
    }
    @Test public void closeRegionsBoard5(){
        Board sut = getBoardGermany();
        sut.closeRegions(2);
        City city = sut.findCity("Berlin");
        assertTrue(sut.findCity("Berlin").getConnections().size() == 4);
    }
    @Test public void getCitiesOfBoard1(){
        Board sut = getBoardGermany();
        assertEquals(42,sut.getCities().size());
    }
    @Test public void getCitiesOfBoard2(){
        Board sut = getBoardGermany();
        assertEquals(factory.newCity("W\u00FCrzburg",4).toString(), sut.findCity("W\u00FCrzburg").toString());
    }
    @Test public void getCitiesOfBoard3(){
        Board sut = getBoardGermany();
        Assert.assertFalse( sut.findCity("W\u00FCrzburg").getConnections().isEmpty());
    }
    @Test (expected = IllegalStateException.class)
    public void closeRegionsTwice(){
        City sut = getCity("mm", 3);
        sut.close();
        sut.close();
    }

    @Test (expected = IllegalStateException.class)
    public void closedAfterCloseMethod(){
        Board board = getBoardGermany();
        City city = factory.newCity("Unicorntown", 1000);
        City city2 = factory.newCity("Softwarehausen", 1000);
        Set<City> cities = board.getCities();
        cities.add(city);
        cities.add(city2);
        board.close();
        city.connect(city2, 1000);
    }

    @Test public void newBoard2() {
        // arrange
        final EditionGermany edition = new EditionGermany();
        final Board sut = factory.newBoard(edition);
        // act
        sut.close();
        // assert
        assertEquals("board holds all specified cities",
                (long)edition.getCitySpecifications().size(),
                sut.getCities().size());
    }

    @Test public void closeNew() {
        // arrange
        final EditionGermany edition = new EditionGermany();
        final Board sut = factory.newBoard(edition);
        // act
        sut.close();
        // assert
        assertEquals("board holds all specified cities",
                (long)edition.getCitySpecifications().size(),
                sut.getCities().size());
    }
    @Test (expected = IllegalStateException.class)
    public void cityCloseNew(){
        final City sut = factory.newCity("UnicornLand", 4);
        sut.close();
    }

    @Test (expected = UnsupportedOperationException.class)
    public void boardClose2(){
        final Board sut = factory.newBoard(new EditionGermany());
        sut.close();
        sut.getCities().add(factory.newCity("UnicorCity", 666));
    }
    @Test (expected = IllegalStateException.class)
    public void boardClose3(){
        final Board sut = factory.newBoard(new EditionGermany());
        sut.close();
        sut.close();
    }
    @Test(expected = IllegalStateException.class)
    public void cityClose(){
        City sut = factory.newCity("Unicorn", 4);
        City s = factory.newCity("TheSatanists", 666);
        sut.connect(s, 5);
        sut.close();
        sut.close();
    }
    @Test(expected = IllegalStateException.class)
    public void cityClose2(){
        City sut = factory.newCity("Unicorn", 4);
        City s = factory.newCity("TheSatanists", 666);
        s.close();
        sut.connect(s, 5);
        sut.close();
    }
    @Test(expected = IllegalStateException.class)
    public void cityClose3(){
        City sut = factory.newCity("Unicorn", 4);
        sut.close();
        City s = factory.newCity("TheSatanists", 666);
        s.close();
        sut.connect(s, 5);

    }

    //Neue Tests 2:
    @Test(expected = IllegalArgumentException.class)
    public void nameStartWithNumber(){
        City sut = factory.newCity("1Bims", 2);
    }

    @Test(expected = IllegalStateException.class)
    public void connectionAfterCloseCity(){
        City sut = factory.newCity("Testhausen", 2);
        City sut2 = factory.newCity("Lolhausen", 3);
        City sut3 = factory.newCity("UnicornCity", 3);
        sut.connect(sut2, 5);
        sut.close();
        sut.connect(sut3, 10);
    }

    @Test public void getCitiesOfBoard50(){
        Board sut = getBoardGermany();
        City mutant = sut.findCity("Flensburg");
        assertEquals(1, mutant.getRegion());
        assertEquals("{Kiel 1=4}", mutant.getConnections().toString());
        assertEquals(42,sut.getCities().size());
    }

    @Test
    public void emptyConnectionsAfterRemoving(){
        Board sut = getBoardGermany();
        final City stuttgart = sut.findCity("Stuttgart");
        sut.closeRegions(4);
        assertTrue(stuttgart.getConnections().isEmpty());
    }

    // x.23
    @Test (expected = IllegalArgumentException.class)
    public void closeRegionsBoard6(){
        Board sut = getBoardGermany();
        sut.closeRegions(0);
    }

    @Test (expected = IllegalArgumentException.class)
    public void closeRegionsBoard7(){
        Board sut = getBoardGermany();
        sut.closeRegions(7);
    }

    @Test
    public void closeRegionsBoard8(){
        Board sut = getBoardGermany();
        sut.closeRegions(6);
        assertEquals(sut.findCity("Passau").getRegion(), 6);
    }

}
