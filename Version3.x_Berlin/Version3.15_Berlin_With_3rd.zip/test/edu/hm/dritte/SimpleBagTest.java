package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.severin.powergrid.ListBag;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class SimpleBagTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);

    private Bag<Integer> getSUT() {
        return new ListBag<>(1, 2, 3);
    }

    // RS smoke tests
    @Test
    public void emptySize() {
        // arrange
        Bag<Void> sut = new ListBag<>();
        // act
        //  assert
        assertEquals(0, sut.size());
    }

    @Test
    public void addSome() {
        // arrange
        Bag<Boolean> sut = new ListBag<>();
        // act
        sut.add(true);
        sut.add(false);
        sut.add((Boolean) null);
        sut.add(true);
        //  assert
        assertEquals(4, sut.size());
    }

    @Test
    public void getSome() {
        // arrange
        final List<Integer> numbers = List.of(1, 2, 2, 42);
        Bag<Integer> sut = new ListBag<>(numbers);
        // act
        List<Integer> readback = new ArrayList<>();
        for (int number : sut)
            readback.add(number);
        // assert
        Collections.sort(readback);
        assertEquals(numbers, readback);
    }

    @Test
    public void removeSome() {
        // arrange
        Bag<String> sut = new ListBag<>("1st", "2nd", "3rd", "2nd");
        // act
        sut.remove("2nd");
        sut.remove("4th");
        // assert
        assertEquals(3, sut.size());
    }

    // immutable and modifying methods
    @Test
    public void bagImmutableSecureView() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable();
        final Bag<Integer> s =sut.add(5, 1);
        assertEquals(4, s.size());
    }

    @Test
    public void bagImmutableOriginAdd() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable();
        sut.add(5);
        assertEquals(4, sut.size());
    }

    @Test
    public void bagImmutableOriginRemove() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable();
        sut.remove(2);
        assertEquals(2, sut.size());
    }

    @Test
    public void bagImmutableReadOnly() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        final Bag<Integer> readOnly = sut.immutable();
        final int want = 4;
        sut.add(4);
        final int have = readOnly.size();
        assertEquals(want, have);
        assertEquals(sut.size(), readOnly.size());
    }

    @Test(expected = UnsupportedOperationException.class)
    public void bagImmutableAdd() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable().add(5);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void bagImmutableAddTimes() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable().add(5, 7);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void bagImmutableAddBag() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable().add(sut);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void bagImmutableRemove() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable().remove(5);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void bagImmutableRemoveTimes() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable().remove(5, 7);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void bagImmutableRemoveBag() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        sut.immutable().remove(getSUT());
    }

    // getSize
    @Test
    public void getSize() {
        final Bag<Integer> sut = getSUT();
        final int want = 3;
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void getSizeWithNull() {
        final Bag<String> sut = new ListBag<>("asd", null);
        final int want = 2;
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void getSizeEmpty() {
        final Bag<Integer> sut = new ListBag<>();
        final int want = 0;
        final int have = sut.size();
        assertEquals(want, have);
    }

    // iterator
    @Test
    public void bagIteratorNext() {
        final Bag<Integer> sut = getSUT();
        final int want = 1;
        final int have = sut.iterator().next();
        assertEquals(want, have);
    }

    @Test
    public void bagIteratorNext2() {
        final Bag<Integer> sut = getSUT();
        final int want = 2;
        final Iterator<Integer> iterator = sut.iterator();
        iterator.next();
        final int have = iterator.next();
        assertEquals(want, have);
    }

    @Test
    public void bagIteratorNext3() {
        final Bag<Integer> sut = getSUT();
        final int want = 3;
        final Iterator<Integer> iterator = sut.iterator();
        iterator.next();
        iterator.next();
        final int have = iterator.next();
        assertEquals(want, have);
    }

    @Test
    public void bagIteratorNextWithNull() {
        final Bag<String> sut = new ListBag<>("asd", null);
        final Iterator<String> iterator = sut.iterator();
        iterator.next();
        final String have = iterator.next();
        assertNull(have);
    }

    @Test
    public void bagIteratorNoNext() {
        final Bag<Integer> sut = getSUT();
        final Iterator<Integer> iterator = sut.iterator();
        iterator.next();
        iterator.next();
        iterator.next();
        assertFalse(iterator.hasNext());
    }

    @Test(expected = RuntimeException.class)
    public void bagIteratorNextNoElement() {
        final Bag<Integer> sut = getSUT();
        final Iterator<Integer> iterator = sut.iterator();
        iterator.next();
        iterator.next();
        iterator.next();
        iterator.next();
    }

    // distinct
    @Test
    public void bagDistinct() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 4, 4, 3, 1, 2);
        final Set<Integer> want = new HashSet<>(List.of(1, 2, 3, 4));
        final Set<Integer> have = sut.distinct();
        assertEquals(want, have);
    }

    @Test
    public void bagDistinct2() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 4);
        final Set<Integer> want = new HashSet<>(List.of(1, 2, 3, 4));
        final Set<Integer> have = sut.distinct();
        boolean t = have.containsAll(want);
        assertTrue(have.contains(1));
    }

    @Test
    public void bagDistinct3() {
        final Bag<Integer> sut = new ListBag<>(1);
        final Set<Integer> want = new HashSet<>(List.of(1));
        final Set<Integer> have = sut.distinct();
        assertEquals(want, have);
    }

    @Test
    public void bagDistinct4() {
        final Bag<String> sut = new ListBag<>("asd", "asdd", null);
        final Set<String> want = new HashSet<>(List.of("asd", "asdd"));
        want.add(null);
        final Set<String> have = sut.distinct();
        assertEquals(want, have);
    }

    @Test
    public void bagDistinct5() {
        final Bag<String> sut = new ListBag<>("asd", "asdd", null);
        final Set<String> want = new HashSet<>(List.of("asd", "asdd", "ddd", "kas"));
        want.add(null);
        final Set<String> have = sut.distinct();
        assertNotEquals(want, have);
    }

    // add single object
    @Test
    public void bagAddSingleElement() {
        final Bag<Integer> sut = getSUT();
        assertTrue(sut.add(1));
        assertEquals(4, sut.size());
    }

    @Test
    public void bagAddSingleElement2() {
        final Bag<String> sut = new ListBag<>("s", "asd", "asd", null);
        assertTrue(sut.add("asd"));
        assertEquals(5, sut.size());
    }

    @Test
    public void bagAddSingleElement3() {
        final Bag<Bag<String>> sut = new ListBag<>();
        assertTrue(sut.add((Bag<String>) null));
        assertEquals(1, sut.size());
    }

    @Test
    public void bagAddSingleElement4() {
        final Bag<String> sut = new ListBag<>();
        assertNotEquals(false, sut.add("asd"));
    }

    @Test
    public void bagAddSingleElementFalse() {
        final Bag<Integer> sut = getSUT();
        assertTrue(sut.add(Integer.MAX_VALUE));
        assertEquals(4, sut.size());
    }

    @Test
    public void bagAddSingleElementWithNull() {
        final Bag<String> sut = new ListBag<>("s", "asd", "asd", null);
        assertTrue(sut.add((String) null));
        assertEquals(5, sut.size());
        assertEquals(2, sut.count(null));
    }

    @Test
    public void bagAddSingleElementSize() {
        final Bag<Integer> sut = getSUT();
        sut.add(1);
        final int want = 4;
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagAddSingleElementSize2() {
        final Bag<String> sut = new ListBag<>("s", "asd", "asd", null);
        final int want = 5;
        sut.add((String) null);
        final int have = sut.size();
        assertEquals(want, have);
    }

    // add multiple elements
    @Test
    public void bagAddMultipleElements() {
        final Bag<Integer> sut = getSUT();
        Bag<Integer> s =sut.add(1, 2);
        final int want = 5;
        final int have = s.size();
        assertEquals(want, have);
    }

    @Test
    public void bagAddMultipleElements2() {
        final Bag<Integer> sut = getSUT();
        sut.add(1, 0);
        final int want = 3;
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagAddMultipleElementsWithNull() {
        final Bag<String> sut = new ListBag<>("s", "asd", "asd", null);
        Bag<String> s =sut.add(null, 2);
        final int want = 6;
        final int have = s.size();
        assertEquals(want, have);
    }

    @Test(expected = IllegalArgumentException.class)
    public void bagAddMultipleElementsInvalid() {
        final Bag<Integer> sut = getSUT();
        sut.add(1, -2);
    }

    // add bag
    @Test
    public void bagAddBag() {
        final Bag<Integer> sut = getSUT();
        Bag<Integer> s = sut.add(getSUT());
        final int want = 6;
        final int have = s.size();
        assertEquals(want, have);
    }

    @Test
    public void bagAddBag2() {
        final Bag<Integer> sut = getSUT();
        sut.add(new ListBag<>());
        final int want = 3;
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagAddBag3() {
        final Bag<String> sut = new ListBag<>("asd", null);
        Bag<String> s =sut.add(new ListBag<>("asd", null, "asdd"));
        final int want = 5;
        final int have = s.size();
        assertEquals(want, have);
    }

    // count
    @Test
    public void bagCount() {
        final Bag<String> sut = new ListBag<>(new HashSet<>(List.of("asd", ",", "asdd")));
        final int want = 1;
        final int have = sut.count("asd");
        assertEquals(want, have);
    }

    @Test
    public void bagCount2() {
        final Bag<Integer> sut = new ListBag<>(new ArrayList<>(List.of(1, 2, 3, 5, 3, 4, 5, 66, 6)));
        final int want = 2;
        final int have = sut.count(5);
        assertEquals(want, have);
    }

    @Test
    public void bagCount3() {
        final Bag<Integer> sut = new ListBag<>(1, 3, 3, 5, 3, 4, 5, 66, 6);
        final int want = 0;
        final int have = sut.count(12);
        assertEquals(want, have);
    }

    @Test
    public void bagCountWithNull() {
        final Bag<String> sut = new ListBag<>("asd", null, "asdsd", null);
        final int want = 2;
        final int have = sut.count(null);
        assertEquals(want, have);
    }

    // contains
    @Test
    public void bagContains() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        assertTrue(sut.contains(new ListBag<>(1, 2)));
    }

    @Test
    public void bagContains2() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        assertTrue(sut.contains(new ListBag<>(1, 2, 3)));
    }

    @Test
    public void bagContains3() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss");
        assertTrue(sut.contains(new ListBag<>("asd", "sss")));
    }

    @Test
    public void bagContains4() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        assertFalse(sut.contains(new ListBag<>(6)));
    }

    @Test
    public void bagContains5() {
        final Bag<String> sut = new ListBag<>("asd", "s", null);
        assertTrue(sut.contains(new ListBag<>("asd", "s", null)));
    }

    @Test
    public void bagContains6RS() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 1, 3);
        final Bag<Integer> sut2 = new ListBag<>(1, 2, 1, 1, 3);
        assertFalse(sut.contains(sut2));
        assertTrue(sut2.contains(sut));
        /*(1, 2, 1, 3).contains(1, 2, 1, 1, 3) liefert true => fixen
        bag.remove(bag) stürzt ab => fixen*/
    }

    // remove bag
    @Test
    public void bagRemoveBag() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss");
        final int want = 1;
        sut.remove(new ListBag<>("asd", "s"));
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveBag2() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss");
        final int want = 3;
        sut.remove(new ListBag<>());
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveBag3() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss", "asd");
        final int want = 3;
        sut.remove(new ListBag<>("asd"));
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveItselfImmutable() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 1, 3);
        sut.remove(sut.immutable());
    }

    @Test
    public void bagRemoveItself() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 1, 3);
        sut.remove(sut);
    }

    @Test
    public void bagRemoveBagWithNull() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss", null);
        final int want = 1;
        sut.remove(new ListBag<>("asd", "s", null));
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test(expected = NoSuchElementException.class)
    public void bagRemoveBagDiffElement() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss");
        final int want = 1;
        sut.remove(new ListBag<>("k", "s"));
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test(expected = NoSuchElementException.class)
    public void bagRemoveBagTooBig() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss");
        sut.remove(new ListBag<>("asd", "s", "sss", "dddasd"));
    }

    @Test(expected = NoSuchElementException.class)
    public void bagRemoveBagTooBig2() {
        final Bag<String> sut = new ListBag<>("asd", "s", "sss");
        sut.remove(new ListBag<>("asd", "s", "sss", "sss"));
    }

    // remove single element
    @Test
    public void bagRemoveSingleElement() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        assertTrue(sut.remove(1));
    }

    @Test
    public void bagRemoveSingleElement2() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        assertFalse(sut.remove(7));
    }

    @Test
    public void bagRemoveSingleElementDiffElement() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3);
        assertFalse(sut.remove((String) null));
    }

    @Test
    public void bagRemoveSingleElementNullAndInt() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, null);
        assertTrue(sut.remove((String) null));
    }

    @Test
    public void bagRemoveSingleElementWithNull() {
        final Bag<String> sut = new ListBag<>("asd", "sdd", null);
        assertTrue(sut.remove((String) null));
    }

    // remove multiple elements
    @Test
    public void bagRemoveMultipleElements() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 1);
        final int want = 2;
        sut.remove(1, 3);
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveMultipleElements2() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 1);
        final int want = 2;
        sut.remove(1, 90);
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveMultipleElements3() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 1);
        final int want = 3;
        sut.remove(1, 1);
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveMultipleElements4() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 1);
        final int want = 4;
        sut.remove(9, 1);
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveMultipleElements5() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 1);
        final int want = 4;
        sut.remove(1, 0);
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test
    public void bagRemoveMultipleElementsWithNull() {
        final Bag<String> sut = new ListBag<>("dd", "ds", null, null, null);
        final int want = 3;
        sut.remove(null, 2);
        final int have = sut.size();
        assertEquals(want, have);
    }

    @Test(expected = IllegalArgumentException.class)
    public void bagRemoveMultipleElementsInvalid() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 1);
        final int want = 2;
        sut.remove(1, -3);
        final int have = sut.size();
        assertEquals(want, have);
    }

    // equals
    @Test
    public void nullEqualsBag() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        assertNotEquals(null, sut);
    }

    @Test
    public void bagEqualsDiffGeneric() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        final Bag<Integer> that = new ListBag<>(1, 2, 4, 4);
        assertNotEquals(sut, that);
        assertNotEquals(that, sut);
    }

    @Test
    public void bagEqualsDiffGenerics2() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        final Bag<Integer> that = new ListBag<>(1, 2, 4, 4);
        assertNotEquals(sut, that);
    }

    @Test
    public void bagEqualsThis() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        assertEquals(sut, sut);
    }

    @Test
    public void bagEqualsTransitivity() {
        final Bag<String> sut = new ListBag<>("1", "2", "3");
        final Bag<String> sut2 = new ListBag<>("3", "1", "2");
        final Bag<String> sut3 = new ListBag<>("2", "3", "1");
        final boolean equality = sut.equals(sut2) == sut.equals(sut3);
        assertEquals(equality, sut2.equals(sut3));
    }

    @Test
    public void bagEqualsTransitivity2() {
        final Bag<String> sut = new ListBag<>("asd", "dsa", "test");
        final Bag<String> sut2 = new ListBag<>("test", "asd", "dsa");
        final Bag<String> sut3 = new ListBag<>("dsa", "test", "asd");
        final boolean equality = sut.equals(sut2) == sut2.equals(sut3);
        assertEquals(equality, sut.equals(sut3));
    }

    @Test
    public void bagEqualsTransitivity3() {
        final Bag<String> sut = new ListBag<>("as2d", "dsa", "test");
        final Bag<String> sut2 = new ListBag<>("te3st", "asd", "dsa");
        final Bag<String> sut3 = new ListBag<>("ds4a", "test", "asd");
        final boolean equality = sut.equals(sut2) == sut2.equals(sut3);
        assertNotEquals(equality, sut.equals(sut3));
    }

    @Test
    public void bagEqualsNull() {
        final Bag<String> sut = new ListBag<>("asd", "asd", "test");
        assertNotEquals(sut, null);
    }

    @Test
    public void bagEqualsImmutable() {
        final Bag<String> sut = new ListBag<>("asd", "asd", "test");
        final Bag<String> sut2 = new ListBag<>("asd", "asd", "test");
        assertEquals(sut, sut2.immutable());
    }

    @Test
    public void bagEqualsDiffClass() {
        final Bag<String> sut = new ListBag<>("asd", "asd", "test");
        class Ignore {
        }
        final Ignore sut2 = new Ignore();
        assertNotEquals(sut, sut2);
    }

    @Test
    public void bagEqualsClassCastException() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        assertNotEquals(sut, Collections.EMPTY_LIST);
    }

    @Test
    public void bagEqualsClassDoubleInt() {
        final ListBag<Double> d = new ListBag<>(1.0, 6.0);
        final ListBag<Integer> b = new ListBag<>(1, 6);
        assertNotEquals(b, d);
        assertNotEquals(d, b);
        assertNotEquals(d.hashCode(), b.hashCode());
    }

    @Test
    public void bagEqualsInheritance() {
        class A {
        }
        class B extends A {
        }
        final ListBag<A> d = new ListBag<>(List.of(new A()));
        final ListBag<B> b = new ListBag<>(List.of(new B()));
        assertNotEquals(b, d);
        assertNotEquals(d, b);
        assertNotEquals(d.hashCode(), b.hashCode());
    }

    @Test
    public void bagEqualsInheritance2() {
        class A {
        }
        class B extends A {
        }
        final ListBag<A> d = new ListBag<>();
        final ListBag<B> b = new ListBag<>();
        assertEquals(b, d);
        assertEquals(d, b);
        assertEquals(d.hashCode(), b.hashCode());
    }

    @Test
    public void bagEqualsStringInt() {
        final ListBag<String> d = new ListBag<>();
        final ListBag<Integer> b = new ListBag<>();
        assertEquals(b, d);
        assertEquals(d, b);
        assertEquals(d.hashCode(), b.hashCode());
    }

    @Test
    public void bagEquals() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        final Bag<String> that = new ListBag<>("asd", "dsa", "test");
        assertEquals(sut, that);
    }

    @Test
    public void bagEquals2() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        final Bag<String> that = new ListBag<>("assd", "dsa", "test");
        assertNotEquals(sut, that);
    }

    @Test
    public void bagEquals3() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        final Bag<String> that = new ListBag<>("asd", "dsa", "test");
        assertEquals(sut.equals(that), that.equals(sut));
    }

    @Test
    public void bagEquals4() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        final Bag<String> that = new ListBag<>("assd", "dsa", "test");
        assertEquals(sut.equals(that), that.equals(sut));
    }

    @Test
    public void bagEquals5() {
        final Bag<String> sut = new ListBag<>("asd", "asd", "test");
        final Bag<String> sut2 = new ListBag<>("test", "test", "asd");
        assertNotEquals(sut, sut2);
    }

    // hashCode
    @Test
    public void bagHashCodeFixed() {
        final Bag<Integer> sut = new ListBag<>(0);
        assertEquals(sut.hashCode(), 962);
    }

    @Test
    public void bagHashCodeFixed2() {
        final Bag<Integer> sut = new ListBag<>(2);
        assertEquals(sut.hashCode(), 1024);
    }

    @Test
    public void bagHashCodeFixed3() {
        final Bag<String> sut = new ListBag<>((String) null);
        assertEquals(sut.hashCode(), 962);
    }

    @Test
    public void bagHashCodeFixed4() {
        final Bag<Integer> sut = new ListBag<>(0, 0);
        assertEquals(sut.hashCode(), 963); //62
    }

    @Test
    public void bagHashCodeFixedImmutable() {
        final Bag<Integer> sut = new ListBag<>(0, 0);
        assertEquals(sut.immutable().hashCode(), 963);
    }

    @Test
    public void bagHashCode() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dsa");
        final Bag<String> that = new ListBag<>("assd", "dsa", "test");
        assertNotEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void bagHashCode2() {
        final Bag<String> sut = new ListBag<>("asd", "tedst", "dsa");
        final Bag<String> that = new ListBag<>("assd", "dsa", "test");
        assertNotEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void bagHashCode3() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dssa");
        final Bag<String> that = new ListBag<>("asd", "dssa", "test");
        assertEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void bagHashCode4() {
        final Bag<String> sut = new ListBag<>("asd", "test", "dssa");
        final Bag<String> that = new ListBag<>("assd", "dssa", "test");
        assertNotEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void bagHashCode5() {
        final Bag<Integer> sut = new ListBag<>(1, 2, 3, 4);
        final Bag<Integer> that = new ListBag<>(4, 3, 2, 1);
        assertEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void bagHashCode6() {
        final Bag<Integer> sut = new ListBag<>(2);
        final Bag<Integer> that = new ListBag<>(2);
        assertEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void bagHashCode7() {
        final Bag<String> sut = new ListBag<>("a");
        final Bag<String> that = new ListBag<>("b");
        assertNotEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void bagHashCode8() {
        final Bag<Integer> sut = new ListBag<>(1);
        final Bag<Integer> that = new ListBag<>(2);
        assertNotEquals(sut.hashCode(), that.hashCode());
    }

    @Test
    public void hashCodeOnly9() {
        final Bag<Integer> sut = new ListBag<>(0, 0, 0);
        final Bag<Integer> sut2 = new ListBag<>(0, 0);
        assertNotEquals(sut.hashCode(), sut2.hashCode());
    }

    @Test
    public void hashCodeOnly0with10() {
        final Bag<Integer> sut = new ListBag<>(1);
        final Bag<Integer> sut2 = new ListBag<>(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        assertNotEquals(sut.hashCode(), sut2.hashCode());
    }

    // hashCode and equals
    @Test
    public void bagHashCodeAndEquals() {
        final Bag<String> sut = new ListBag<>("a");
        final Bag<String> that = new ListBag<>("b");
        assertEquals(sut.hashCode() == that.hashCode(), sut.equals(that));
    }

    @Test
    public void bagHashCodeAndEquals2() {
        final Bag<String> sut = new ListBag<>("b");
        final Bag<String> that = new ListBag<>("b");
        assertEquals(sut.hashCode() == that.hashCode(), sut.equals(that));
    }

    // toString
    @Test
    public void testToString() {
        final Bag<Integer> sut = new ListBag<>(1);
        final String want = "ListBag{elements=[1], readOnly=false}";
        final String have = sut.toString();
        assertEquals(want, have);
    }

    // method chaining
    @Test
    public void bagMethodChaining() {
        final Bag<String> sut = new ListBag<>("a", "b", "c", "d", "e", "f");
        sut.remove("a", 1);
        Bag<String> s =sut.remove(new ListBag<>(List.of("b", "c")))
                .add("bc", 3)
                .add(new ListBag<>("asd"));
         s.remove("d");
        assertEquals(6, s.size());
    }
}
