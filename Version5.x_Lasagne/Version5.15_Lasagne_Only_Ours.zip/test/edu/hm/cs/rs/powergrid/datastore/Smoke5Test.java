package edu.hm.cs.rs.powergrid.datastore;

import edu.hm.cs.rs.powergrid.EditionGermany;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;
import java.util.List;

/**
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-09
 */
public class Smoke5Test {
    @Rule public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    private final String fqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";

    private final Factory factory = Factory.newFactory(fqcn);

    @Test public void newGame() {
        // arrange
        Game sut = factory.newGame(new EditionGermany());
        // act
        Game have = factory.newGame(new EditionGermany());
        // assert
        Assert.assertSame(sut, have);
        Assert.assertSame(factory, sut.getFactory());
    }

    @Test public void newPlantMarket() {
        // arrange
        PlantMarket sut = factory.newPlantMarket(new EditionGermany());
        // act
        PlantMarket have = factory.newPlantMarket(new EditionGermany());
        // assert
        Assert.assertSame(sut, have);
    }

    @Test public void newAuctiont() {
        // arrange
        Auction sut = factory.newAuction(factory.newPlant(3, Plant.Type.Eco, 1, 1),
                List.of(factory.newPlayer("123", "red"),
                        factory.newPlayer("456", "blue")));
        // act
        Auction have = factory.newAuction(factory.newPlant(3, Plant.Type.Coal, 2, 2),
                List.of(factory.newPlayer("789", "yellow"),
                        factory.newPlayer("012", "green")));
        // assert
        Assert.assertSame(sut, have);
    }

}