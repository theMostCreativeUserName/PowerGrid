package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Auction;
import edu.hm.cs.rs.powergrid.datastore.Board;
import edu.hm.cs.rs.powergrid.datastore.City;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.PlantMarket;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.cs.rs.powergrid.datastore.ResourceMarket;
import edu.hm.severin.powergrid.datastore.NeutralFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

public class SimpleFactoryTest {
    private final static Edition GERMANY = new EditionGermany();
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // newCity
    @Test
    public void newCityNotNull() {
        assertNotNull(factory.newCity("any name", 1283));
    }

    @Test
    public void newCity1() {
        final City city = factory.newCity("test", 4);

        assertEquals("test", city.getName());
        assertEquals(4, city.getRegion());
    }

    // duplicates newCity
    @Test
    public void dupeCityInitSame() {
        final City sut = factory.newCity("West", 2);
        sut.connect(factory.newCity("North", 1), 90);
        final City otherCity = factory.newCity("West", 3);
        assertEquals(sut.getConnections(), otherCity.getConnections());
    }

    @Test
    public void dupeCityInitDifferent() {
        final City sut = factory.newCity("West", 2);
        sut.connect(factory.newCity("South", 12), 9);
        final City otherCity = factory.newCity("East", 9);
        assertNotEquals(sut.getConnections(), otherCity.getConnections());
    }

    @Test
    public void newCity2() {
        final City city = factory.newCity("abc", 5);

        assertEquals("abc", city.getName());
        assertEquals(5, city.getRegion());
    }

    // newBoard (with edition of Germany)
    @Test
    public void newBoardHasCities() {
        final Board board = factory.newBoard(GERMANY);

        assertFalse(board.getCities().isEmpty());
    }

    @Test
    public void newBoardContainsCorrectCities() {
        final Board board = factory.newBoard(GERMANY);

        assertNotNull(board.findCity("Flensburg"));
        assertNotNull(board.findCity("Kiel"));
        assertNotNull(board.findCity("Hamburg"));
        assertNotNull(board.findCity("Frankfurt-Oder"));
        assertNotNull(board.findCity("Freiburg"));
        assertNotNull(board.findCity("M\u00FCnchen"));
        assertNotNull(board.findCity("Konstanz"));
    }

    @Test
    public void newBoardMunichCorrect() {
        final Board board = factory.newBoard(GERMANY);

        final City munich = board.findCity("M\u00FCnchen");
        assertEquals("M\u00FCnchen", munich.getName());
        assertEquals(6, munich.getRegion());

        assertEquals(3, munich.getConnections().size());

        assertTrue(munich.getConnections().containsKey(board.findCity("Augsburg")));
        assertTrue(munich.getConnections().containsKey(board.findCity("Regensburg")));
        assertTrue(munich.getConnections().containsKey(board.findCity("Passau")));

        assertTrue(board.findCity("Augsburg").getConnections().containsKey(munich));
        assertTrue(board.findCity("Regensburg").getConnections().containsKey(munich));
        assertTrue(board.findCity("Passau").getConnections().containsKey(munich));

        final int AtoM = board.findCity("Augsburg").getConnections().get(munich);
        assertEquals(6, AtoM);
        final int RtoM = board.findCity("Regensburg").getConnections().get(munich);
        assertEquals(10, RtoM);
        final int PtoM = board.findCity("Passau").getConnections().get(munich);
        assertEquals(14, PtoM);
    }

    @Test
    public void newBoardFuldaCorrect() {
        final Board board = factory.newBoard(GERMANY);

        final City fulda = board.findCity("Fulda");
        assertEquals("Fulda", fulda.getName());
        assertEquals(4, fulda.getRegion());

        assertEquals(4, fulda.getConnections().size());

        assertTrue(fulda.getConnections().containsKey(board.findCity("Frankfurt-Main")));
        assertTrue(fulda.getConnections().containsKey(board.findCity("W\u00FCrzburg")));
        assertTrue(board.findCity("Erfurt").getConnections().containsKey(fulda));
        assertTrue(board.findCity("Kassel").getConnections().containsKey(fulda));

        final int FtoF = fulda.getConnections().get(board.findCity("Frankfurt-Main"));
        assertEquals(8, FtoF);
        final int FtoW = fulda.getConnections().get(board.findCity("W\u00FCrzburg"));
        assertEquals(11, FtoW);
        final int FtoE = board.findCity("Erfurt").getConnections().get(fulda);
        assertEquals(13, FtoE);
        final int FtoK = board.findCity("Kassel").getConnections().get(fulda);
        assertEquals(8, FtoK);
    }

    @Test
    public void newBoardFuldaCorrectAfterClose() {
        final Board board = factory.newBoard(GERMANY);
        final City frankfurt = board.findCity("Frankfurt-Main");
        board.closeRegions(4);

        final City fulda = board.findCity("Fulda");
        assertEquals("Fulda", fulda.getName());
        assertEquals(4, fulda.getRegion());

        assertNull(board.findCity("Frankfurt-Main"));
        assertTrue(frankfurt.getConnections().isEmpty());

        assertFalse(fulda.getConnections().containsKey(frankfurt));
    }

    // duplicates newBoard
    @Test
    public void duplicatesNewBoard() {
        final Board sut = factory.newBoard(GERMANY);
        final Board sut2 = factory.newBoard(GERMANY);
        assertEquals(sut, sut2);
        assertEquals(sut2, sut);
        sut.getCities().clear();
        assertTrue(sut2.getCities().isEmpty());
    }

    // newPlayer
    @Test
    public void newPlayerNotNull() {
        assertNotNull(factory.newPlayer("geheim", "orange"));
    }

    @Test
    public void newPlayer1() {
        Player player = factory.newPlayer("secret", "red");

        assertEquals("secret", player.getSecret());
        assertEquals("red", player.getColor());
    }

    @Test
    public void newPlayer2() {
        Player player = factory.newPlayer("terces", "blue");

        assertEquals("terces", player.getSecret());
        assertEquals("blue", player.getColor());
    }

    // duplicates newPlayer
    @Test
    public void dupePlayerInitSame() {
        final Player sut = factory.newPlayer("code", "blue");
        sut.setElectro(5000);
        final Player otherPlayer = factory.newPlayer("code", "blue");
        assertEquals(sut.getElectro(), otherPlayer.getElectro());
    }

    @Test
    public void dupePlayerInitDifferent() {
        final Player sut = factory.newPlayer("code", "blue");
        sut.setElectro(5000);
        final Player otherPlayer = factory.newPlayer("code", "red");
        assertNotEquals(sut.getElectro(), otherPlayer.getElectro());
    }

    // newPlant
    @Test
    public void newPlantNotNull() {
        assertNotNull(factory.newPlant(9, Plant.Type.Hybrid, 4, 6));
    }

    @Test
    public void newPlant1() {
        Plant plant = factory.newPlant(1, Plant.Type.Coal, 2, 4);

        assertEquals(1, plant.getNumber());
        assertEquals(Plant.Type.Coal, plant.getType());
        assertEquals(2, plant.getNumberOfResources());
        assertEquals(4, plant.getCities());
    }

    @Test
    public void newPlant2() {
        Plant plant = factory.newPlant(5, Plant.Type.Fusion, 8, 3);

        assertEquals(5, plant.getNumber());
        assertEquals(Plant.Type.Fusion, plant.getType());
        assertEquals(8, plant.getNumberOfResources());
        assertEquals(3, plant.getCities());
    }

    // duplicates newPlant
    @Test
    public void dupePlantInitSame() {
        final Plant sut = factory.newPlant(1, Plant.Type.Coal, 2, 3);
        sut.setOperated(true);
        final Plant otherPlant = factory.newPlant(1, Plant.Type.Fusion, 3, 5);
        assertEquals(sut.hasOperated(), otherPlant.hasOperated());
    }

    @Test
    public void dupePlantInitDifferent() {
        final Plant sut = factory.newPlant(1, Plant.Type.Coal, 2, 3);
        sut.setOperated(true);
        final Plant otherPlant = factory.newPlant(3, Plant.Type.Fusion, 3, 5);
        assertNotEquals(sut.hasOperated(), otherPlant.hasOperated());
    }

    // newAuction
    @Test
    public void newAuctionNotNull() {
        final Plant plant = factory.newPlant(1, Plant.Type.Coal, 4, 5);
        final List<Player> players = new ArrayList<>();
        players.add(factory.newPlayer("1234", "123456"));

        assertNotNull(factory.newAuction(plant, players));
    }

    @Test
    public void newAuction1() {
        final Plant plant = factory.newPlant(0, Plant.Type.Coal, 4, 5);
        final Player player1 = factory.newPlayer("1234", "123456");
        final Player player2 = factory.newPlayer("4321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        assertEquals(0, sut.getAmount());
        assertEquals(plant, sut.getPlant());
        assertEquals(players, sut.getPlayers());
    }

    @Test
    public void newAuction2() {
        final Plant plant = factory.newPlant(25, Plant.Type.Fusion, 4, 5);
        final Player player1 = factory.newPlayer("1234", "123456");
        final Player player2 = factory.newPlayer("4321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        assertEquals(25, sut.getAmount());
        assertEquals(plant, sut.getPlant());
        assertEquals(players, sut.getPlayers());
    }

    @Test(expected = IllegalArgumentException.class)
    public void newAuctionEmptyPlayerListException() {
        final Plant plant = factory.newPlant(4, Plant.Type.Fusion, 4, 5);

        factory.newAuction(plant, new ArrayList<>());
    }

    // duplicates newAuction
    @Test
    public void dupeAuctionInitSame() {
        final Plant plant = factory.newPlant(10, Plant.Type.Fusion, 4, 5);
        final Player player1 = factory.newPlayer("1234", "123456");
        final Player player2 = factory.newPlayer("4321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        sut.setAmount(15);
        final Auction otherSut = factory.newAuction(plant, players);
        assertEquals(otherSut.getAmount(), sut.getAmount());
    }

    @Test
    public void dupeAuctionInitDifferent() {
        final Plant plant = factory.newPlant(10, Plant.Type.Fusion, 4, 5);
        final Plant otherPlant = factory.newPlant(12, Plant.Type.Fusion, 4, 5);
        final Player player1 = factory.newPlayer("1234", "123456");
        final Player player2 = factory.newPlayer("4321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        sut.setAmount(15);
        final Auction otherSut = factory.newAuction(otherPlant, players);
        assertNotEquals(otherSut.getAmount(), sut.getAmount());
    }

    // newPlantMarket
    @Test
    public void newPlantMarketInit() {
        factory.newPlantMarket(GERMANY);
    }

    @Test(expected = NullPointerException.class)
    public void newPlantMarketInvalidInit() {
        factory.newPlantMarket(null);
    }

    @Test
    public void newPlantMarketDetails() {
        final PlantMarket plantMarket = factory.newPlantMarket(GERMANY);

        assertEquals(0, plantMarket.getActual().size());
        assertEquals(0, plantMarket.getFuture().size());
        assertEquals(42, plantMarket.getHidden().size());

        assertEquals(3, plantMarket.findPlant(3).getNumber());
        assertEquals(2, plantMarket.findPlant(3).getNumberOfResources());
        assertEquals(1, plantMarket.findPlant(3).getCities());
        assertEquals(Plant.Type.Oil, plantMarket.findPlant(3).getType());

        assertEquals(30, plantMarket.findPlant(30).getNumber());
        assertEquals(3, plantMarket.findPlant(30).getNumberOfResources());
        assertEquals(6, plantMarket.findPlant(30).getCities());
        assertEquals(Plant.Type.Garbage, plantMarket.findPlant(30).getType());
    }

    // duplicates newPlantMarket
    @Test
    public void newPlantMarketOnlyOne() {
        final PlantMarket plantMarket = factory.newPlantMarket(GERMANY);
        assertEquals(plantMarket, factory.newPlantMarket(GERMANY));
    }

    // newResourceMarket
    @Test
    public void newResourceMarketInit() {
        factory.newResourceMarket(GERMANY);
    }

    @Test(expected = NullPointerException.class)
    public void newResourceMarketInvalidInit() {
        factory.newResourceMarket(null);
    }

    @Test
    public void newResourceMarketResources() {
        final ResourceMarket resourceMarket = factory.newResourceMarket(GERMANY);
        assertFalse(resourceMarket.getAvailable().isEmpty());
        assertEquals(resourceMarket.getAvailable().count(Resource.Coal), 24);

        assertFalse(resourceMarket.getSupply().isEmpty());
        assertEquals(resourceMarket.getSupply().count(Resource.Oil), 6);
    }

    // duplicates newResourceMarket
    @Test
    public void newResourceMarketOnlyOne() {
        final ResourceMarket resourceMarket = factory.newResourceMarket(GERMANY);
        assertEquals(resourceMarket, factory.newResourceMarket(GERMANY));
    }

    // newGame
    @Test
    public void newGameInit() {
        factory.newGame(GERMANY);
    }

    @Test(expected = NullPointerException.class)
    public void newGameInvalidInit() {
        factory.newGame(null);
    }

    @Test
    public void newGameDetails() {
        Game game = factory.newGame(GERMANY);
        assertSame(GERMANY, game.getEdition());
        assertSame(factory, game.getFactory());
    }

    // duplicates newGame
    @Test
    public void newGameOnlyOne() {
        final Game game = factory.newGame(GERMANY);
        assertEquals(game, factory.newGame(GERMANY));
    }

    @Test
    public void differentFactoryDifferentMemory() {
        final Factory fac = new NeutralFactory();
        final Factory fac2 = new NeutralFactory();
        fac.newPlant(1, Plant.Type.Fusion, 1, 1);
        assertEquals(Plant.Type.Fusion, fac.newPlant(1, Plant.Type.Coal, 2, 2).getType());
        assertEquals(Plant.Type.Coal, fac2.newPlant(1, Plant.Type.Coal, 2, 2).getType());
    }
}
