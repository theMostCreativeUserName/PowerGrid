package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.cs.rs.powergrid.datastore.ResourceMarket;
import edu.hm.severin.powergrid.ListBag;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static edu.hm.cs.rs.powergrid.datastore.Resource.Coal;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Garbage;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Oil;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Uranium;
import static org.junit.Assert.assertEquals;

public class SimpleResourceMarketTest {
    /** Internal edition, used to test the implementation outside of edition germany environment. */
    private static class EditionFake implements Edition{
        @Override
        public int getPlayersMinimum() {
            return 0;
        }
        @Override
        public int getPlayersMaximum() {
            return 0;
        }
        @Override
        public int getInitialElectro() {
            return 0;
        }
        @Override
        public int getActualPlants(int levelIndex) {
            return 0;
        }
        @Override
        public int getFuturePlants(int levelIndex) {
            return 0;
        }
        @Override
        public Map<Resource, Integer> getResourceToNumber() {
            Map<Resource,Integer> result = new HashMap<>();
            result.put(Oil,2000);
            result.put(Coal,2000);
            result.put(Uranium,10000);
            return result;
        }
        @Override
        public Map<Resource, List<Integer>> getResourceAvailableToCost() {
            Map<Resource,List<Integer>> result = new HashMap<>();
            result.put(Coal,List.of(1,2,3));
            result.put(Oil,List.of(1,4,16,64));
            result.put(Uranium,List.of(90,91,92,93));
            return result;
        }
        @Override
        public Map<Resource, Integer> getResourcesInitiallyAvailable() {
            Map<Resource,Integer> result = new HashMap<>();
            result.put(Oil,20);
            result.put(Coal,20);
            result.put(Uranium,100);
            return result;
        }
        @Override
        public List<Integer> levelToCityCost() {
            return null;
        }
        @Override
        public Map<Resource, List<List<Integer>>> getResourcePlayersToSupply() {
            return null;
        }
        @Override
        public List<Integer> getPoweredCitiesIncome() {
            return null;
        }
        @Override
        public List<String> getPlayerColors() {
            return null;
        }
        @Override
        public List<Integer> getPlayersPlantsInitiallyRemoved() {
            return null;
        }
        @Override
        public List<Integer> getPlayersPlantsLimit() {
            return null;
        }
        @Override
        public List<Integer> getPlayersLevel2Cities() {
            return null;
        }
        @Override
        public List<Integer> getPlayersEndgameCities() {
            return null;
        }
        @Override
        public List<Integer> getRegionsUsed() {
            return null;
        }
        @Override
        public List<String> getPlantSpecifications() {
            return null;
        }
        @Override
        public List<String> getCitySpecifications() {
            return null;
        }
    }

    private final static Edition germany = new EditionGermany();
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // constructor
    @Test(expected = NullPointerException.class)
    public void initInvalid() {
        factory.newResourceMarket(null);
    }

    // getAvailable
    @Test
    public void getAvailableGermany() {
        final ResourceMarket sut = factory.newResourceMarket(germany);
        final Bag<Resource> have = sut.getAvailable();
        final Bag<Resource> want = new ListBag<>();
        want.add(Coal, 24);
        want.add(Oil, 18);
        want.add(Garbage, 6);
        want.add(Uranium, 2);
        assertEquals(want, have);
    }

    @Test
    public void getAvailableEditionFake() {
        final ResourceMarket sut = factory.newResourceMarket(new EditionFake());
        final Bag<Resource> have = sut.getAvailable();
        final Bag<Resource> want = new ListBag<>();
        want.add(Oil, 20);
        want.add(Coal, 20);
        want.add(Uranium, 100);
        assertEquals(want, have);
    }

    // getSupply
    @Test
    public void getSupplyGermany() {
        final ResourceMarket sut = factory.newResourceMarket(germany);
        final Bag<Resource> have = sut.getSupply();
        final Bag<Resource> want = new ListBag<>();
        want.add(Oil, 6);
        want.add(Garbage, 18);
        want.add(Uranium, 10);
        assertEquals(want, have);
    }

    @Test
    public void getSupplyEditionFake() {
        final ResourceMarket sut = factory.newResourceMarket(new EditionFake());
        final Bag<Resource> have = sut.getSupply();
        final Bag<Resource> want = new ListBag<>();
        want.add(Coal, 1980);
        want.add(Oil, 1980);
        want.add(Uranium, 9900);
        assertEquals(want, have);
    }

    // getPrice
    @Test
    public void getPriceGermany() {
        final ResourceMarket sut = factory.newResourceMarket(germany);
        final int want = new EditionGermany().getResourceAvailableToCost().get(Coal).get(0);
        sut.getAvailable().remove(Coal, 23);
        final int have = sut.getPrice(Coal);
        assertEquals(want, have);
    }

    @Test
    public void getPriceEditionFake() {
        final ResourceMarket sut = factory.newResourceMarket(new EditionFake());
        final int want = new EditionFake().getResourceAvailableToCost().get(Oil).get(0);
        sut.getAvailable().remove(Oil, 19);
        final int have = sut.getPrice(Oil);
        assertEquals(want, have);
    }

    @Test(expected = IllegalArgumentException.class)
    public void getPriceNoResourceGermany() {
        final ResourceMarket sut = factory.newResourceMarket(germany);
        final int want = new EditionGermany().getResourceAvailableToCost().get(Uranium).get(0);
        sut.getAvailable().remove(Uranium, 2);
        final int have = sut.getPrice(Uranium);
        assertEquals(want, have);
    }

    @Test(expected = NullPointerException.class)
    public void getPriceNullEditionFake() {
        final ResourceMarket sut = factory.newResourceMarket(new EditionFake());
        sut.getPrice(null);
    }
}