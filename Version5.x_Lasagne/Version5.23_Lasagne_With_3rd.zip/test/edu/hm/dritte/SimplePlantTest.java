package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.severin.powergrid.ListBag;
import edu.hm.severin.powergrid.datastore.NeutralPlant;
import edu.hm.severin.powergrid.datastore.NeutralPlayer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static edu.hm.cs.rs.powergrid.datastore.Resource.Coal;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Garbage;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Oil;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Uranium;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class SimplePlantTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // constructor and getter
    @Test(expected = IllegalArgumentException.class)
    public void constructorInvalidNumber() {
        factory.newPlant(-1, Plant.Type.Coal, 5, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorInvalidResources() {
        factory.newPlant(14, Plant.Type.Eco, -4, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorNegativeCities() {
        factory.newPlant(14, Plant.Type.Eco, 143, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorTypeNull() {
        factory.newPlant(14, null, 143, 41);
    }

    @Test
    public void getAll1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        assertEquals(1, sut.getNumber());
        assertEquals(Plant.Type.Oil, sut.getType());
        assertEquals(2, sut.getNumberOfResources());
        assertEquals(3, sut.getCities());
    }

    @Test
    public void getAll2() {
        final Plant sut = factory.newPlant(4, Plant.Type.Coal, 5, 6);
        assertEquals(4, sut.getNumber());
        assertEquals(Plant.Type.Coal, sut.getType());
        assertEquals(5, sut.getNumberOfResources());
        assertEquals(6, sut.getCities());
    }

    @Test
    public void getAll3() {
        final Plant sut = factory.newPlant(7, Plant.Type.Garbage, 8, 9);
        assertEquals(7, sut.getNumber());
        assertEquals(Plant.Type.Garbage, sut.getType());
        assertEquals(8, sut.getNumberOfResources());
        assertEquals(9, sut.getCities());
    }

    @Test
    public void getAll4() {
        final Plant sut = factory.newPlant(10, Plant.Type.Fusion, 11, 12);
        assertEquals(10, sut.getNumber());
        assertEquals(Plant.Type.Fusion, sut.getType());
        assertEquals(11, sut.getNumberOfResources());
        assertEquals(12, sut.getCities());
    }

    @Test
    public void getAll5() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        assertEquals(0, sut.getNumber());
        assertEquals(Plant.Type.Oil, sut.getType());
        assertEquals(0, sut.getNumberOfResources());
        assertEquals(1, sut.getCities());
    }

    // hasOperated and setOperated
    @Test
    public void hasOperated() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        assertFalse(sut.hasOperated());
    }

    @Test
    public void hasOperatedTrue() {
        final Plant sut = factory.newPlant(0, Plant.Type.Fusion, 0, 1);
        sut.setOperated(true);
        assertTrue(sut.hasOperated());
    }

    @Test
    public void hasOperatedFalse() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        sut.setOperated(false);
        assertFalse(sut.hasOperated());
    }

    @Test
    public void hasOperatedTrueThenFalse() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        sut.setOperated(true);
        assertTrue(sut.hasOperated());
        sut.setOperated(false);
        assertFalse(sut.hasOperated());
    }

    // getResource
    @Test
    public void plantSingleResource() {
        final Plant sut = factory.newPlant(1, Plant.Type.Oil, 3, 4);
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil));
        assertTrue(have);
    }

    @Test
    public void plantSingleResource2() {
        final Plant sut = factory.newPlant(3, Plant.Type.Uranium, 4, 3);
        final Resource uranium = Uranium;
        final boolean have = sut.getResources().contains(new ListBag<>(uranium, uranium, uranium, uranium));
        assertTrue(have);
    }

    @Test
    public void plantSingleResource3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Uranium, 4, 3);
        assertEquals(1, sut.getResources().size());
    }

    @Test
    public void plantSingleResource4() {
        final Plant sut = factory.newPlant(3, Plant.Type.Uranium, 1, 3);
        assertEquals(1, sut.getResources().size());
    }

    @Test
    public void plantHybridResource1() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 3, 3);
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil));
        assertTrue(have);
    }

    @Test
    public void plantHybridResource2() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 3, 3);
        final boolean have = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal));
        assertTrue(have);
    }

    @Test
    public void plantHybridResource3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 3, 3);
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Coal, Coal));
        assertTrue(have);
    }

    @Test
    public void plantHybridResource4() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 3, 3);
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Coal));
        assertTrue(have);
    }

    @Test
    public void plantHybridResource5() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 4, 3);
        final Resource coal = Coal;
        final boolean have = sut.getResources().contains(new ListBag<>(coal, coal, coal, coal));
        assertTrue(have);
    }

    @Test
    public void plantHybridResource6() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 4, 3);
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil, Oil));
        assertTrue(have);
    }

    @Test
    public void plantHybridResource7() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 2, 3);
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal)));

    }

    @Test
    public void plantNoResource0() {
        final Plant sut = factory.newPlant(3, Plant.Type.Eco, 0, 3);
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void plantNoResource2() {
        final Plant sut = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void plantNoResource3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Level3, 4, 3);
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesCoal0() {
        final Plant sut = factory.newPlant(0, Plant.Type.Coal, 0, 1);
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesCoal1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Coal, 1, 1);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal)));
    }

    @Test
    public void getResourcesCoal2() {
        final Plant sut = factory.newPlant(2, Plant.Type.Coal, 2, 2);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal)));
    }

    @Test
    public void getResourcesCoal3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Coal, 3, 3);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Coal)));
        assertFalse(sut.getResources().contains(new ListBag<>(Coal, Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Coal)));
    }

    @Test
    public void getResourcesGarbage0() {
        final Plant sut = factory.newPlant(0, Plant.Type.Garbage, 0, 1);
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesGarbage1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Garbage, 1, 1);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Garbage)));
    }

    @Test
    public void getResourcesGarbage2() {
        final Plant sut = factory.newPlant(2, Plant.Type.Garbage, 2, 2);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Garbage)));
        assertTrue(sut.getResources().contains(new ListBag<>(Garbage, Garbage)));
    }

    @Test
    public void getResourcesGarbage3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Garbage, 3, 3);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Garbage)));
        assertFalse(sut.getResources().contains(new ListBag<>(Garbage, Garbage)));
        assertTrue(sut.getResources().contains(new ListBag<>(Garbage, Garbage, Garbage)));
    }

    @Test
    public void getResourcesUranium0() {
        final Plant sut = factory.newPlant(0, Plant.Type.Uranium, 0, 1);
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesUranium1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Uranium, 1, 1);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Uranium)));
    }

    @Test
    public void getResourcesUranium2() {
        final Plant sut = factory.newPlant(2, Plant.Type.Uranium, 2, 2);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Uranium)));
        assertTrue(sut.getResources().contains(new ListBag<>(Uranium, Uranium)));
    }

    @Test
    public void getResourcesUranium3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Uranium, 3, 3);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Uranium)));
        assertFalse(sut.getResources().contains(new ListBag<>(Uranium, Uranium)));
        assertTrue(sut.getResources().contains(new ListBag<>(Uranium, Uranium, Uranium)));
    }

    @Test
    public void getResourcesOil0() {
        final Plant sut = factory.newPlant(0, Plant.Type.Oil, 0, 1);
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesOil1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Oil, 1, 1);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil)));
    }

    @Test
    public void getResourcesOil2() {
        final Plant sut = factory.newPlant(2, Plant.Type.Oil, 2, 2);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Oil)));
    }

    @Test
    public void getResourcesOil3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Oil, 3, 3);
        assertEquals(1, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertFalse(sut.getResources().contains(new ListBag<>(Oil)));
        assertFalse(sut.getResources().contains(new ListBag<>(Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Oil, Oil)));
    }

    @Test
    public void getResourcesEco0() {
        final Plant sut = factory.newPlant(0, Plant.Type.Eco, 0, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesEco1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Eco, 1, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesEco2() {
        final Plant sut = factory.newPlant(2, Plant.Type.Eco, 2, 2);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesEco3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Eco, 3, 3);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesEco100() {
        final Plant sut = factory.newPlant(100, Plant.Type.Eco, 100, 100);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesFusion0() {
        final Plant sut = factory.newPlant(0, Plant.Type.Fusion, 0, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesFusion1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Fusion, 1, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesFusion2() {
        final Plant sut = factory.newPlant(2, Plant.Type.Fusion, 2, 2);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesFusion3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Fusion, 3, 3);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesFusion100() {
        final Plant sut = factory.newPlant(100, Plant.Type.Fusion, 100, 100);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesHybrid0() {
        final Plant sut = factory.newPlant(0, Plant.Type.Hybrid, 0, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesHybrid1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Hybrid, 1, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(2, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil)));
    }

    @Test
    public void getResourcesHybrid2() {
        final Plant sut = factory.newPlant(2, Plant.Type.Hybrid, 2, 2);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(3, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Coal)));
    }

    @Test
    public void getResourcesHybrid3() {
        final Plant sut = factory.newPlant(3, Plant.Type.Hybrid, 3, 3);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(4, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Oil, Oil)));
    }

    @Test
    public void getResourcesHybrid4() {
        final Plant sut = factory.newPlant(4, Plant.Type.Hybrid, 4, 4);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(5, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Oil, Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Oil, Oil, Oil)));
    }

    @Test
    public void getResourcesHybrid5() {
        final Plant sut = factory.newPlant(5, Plant.Type.Hybrid, 5, 5);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(6, sut.getResources().size());
        assertFalse(sut.getResources().contains(new ListBag<Resource>()));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Coal, Coal)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Coal, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Coal, Oil, Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Coal, Oil, Oil, Oil, Oil)));
        assertTrue(sut.getResources().contains(new ListBag<>(Oil, Oil, Oil, Oil, Oil)));
    }

    @Test
    public void getResourcesLevel30() {
        final Plant sut = factory.newPlant(0, Plant.Type.Level3, 0, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesLevel31() {
        final Plant sut = factory.newPlant(1, Plant.Type.Level3, 1, 1);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesLevel32() {
        final Plant sut = factory.newPlant(2, Plant.Type.Level3, 2, 2);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

    @Test
    public void getResourcesLevel33() {
        final Plant sut = factory.newPlant(3, Plant.Type.Level3, 3, 3);
        assertFalse(sut.getResources().isEmpty());
        assertEquals(1, sut.getResources().size());
        assertTrue(sut.getResources().contains(new ListBag<Resource>()));
    }

   /* @Test
    public void getResourceTEST(){
        final Plant sut = factory.newPlant(3, Plant.Type.Ultimate, 3, 3);
        Resource Oil = Resource.Oil;
        Resource coal = Resource.Coal;
        Resource uranium = Resource.Uranium;
        Bag<Resource> b1 = new ListBag<>(Arrays.asList(Oil,Oil,Oil));
        Bag<Resource> b6 = new ListBag<>(Arrays.asList(coal,coal,coal));
        Bag<Resource> b9 = new ListBag<>(Arrays.asList(uranium,uranium,uranium));

        Bag<Resource> b7 = new ListBag<>(Arrays.asList(coal,coal,uranium));
        Bag<Resource> b4 = new ListBag<>(Arrays.asList(coal,coal,Oil));
        Bag<Resource> b8 = new ListBag<>(Arrays.asList(uranium,uranium,coal));
        Bag<Resource> b5 = new ListBag<>(Arrays.asList(uranium,uranium,Oil));
        Bag<Resource> b2 = new ListBag<>(Arrays.asList(Oil, Oil, coal));
        Bag<Resource> b3 = new ListBag<>(Arrays.asList(Oil,Oil,uranium));

        Bag<Resource> b10 = new ListBag<>(Arrays.asList(Oil,uranium,coal));

        Set<Bag<Resource>> bag = new HashSet<>(List.of(b1,b2,b3,b4,b5,b6,b7,b8,b9,b10));
        assertEquals(bag.size(),sut.getResources().size());
    }*/

    // equals
    @Test
    public void equals1() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(32, Plant.Type.Coal, 45, 6);
        assertNotEquals(p1, p2);
    }

    @Test
    public void equals2() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(3, Plant.Type.Coal, 45, 6);
        assertEquals(p2, p1);
        assertEquals(p1, p2);
    }

    @Test
    public void equals3() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(3, Plant.Type.Coal, 45, 6);
        assertEquals(p2, p1);
    }

    @Test
    public void equals4() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(8, Plant.Type.Coal, 45, 6);
        assertNotEquals(p2, p1);
    }

    @Test
    public void equals5() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        assertEquals(p1, p1);
    }

    @Test
    public void equals6() {
        Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        Player p2 = new NeutralPlayer("asd", "asdd");
        assertNotEquals(p2, p1);
    }

    @Test
    public void equals7() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(8, Plant.Type.Coal, 45, 6);
        final Plant p3 = factory.newPlant(88, Plant.Type.Coal, 45, 6);
        assertNotEquals(p2, p3);
        assertEquals(p1.equals(p2), p1.equals(p3));
    }

    @Test
    public void equalsNull() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        assertNotEquals(null, p1);
    }

    @Test
    public void equalsNull2() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        assertNotEquals(p1, null);
    }

    @Test
    public void equalsNoFactory2() {
        final Plant p1 = new NeutralPlant(30, Plant.Type.Fusion, 4, 3);
        final Plant p2 = new NeutralPlant(3, Plant.Type.Coal, 45, 6);
        assertNotEquals(p1, p2);
    }

    // hashCode
    @Test
    public void hashCode1() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(32, Plant.Type.Coal, 45, 6);
        assertNotEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    public void hashCode2() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(3, Plant.Type.Coal, 45, 6);
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    // hashCode and equals
    @Test
    public void hashAndEquals() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(3, Plant.Type.Coal, 45, 6);
        assertEquals(p1.hashCode() == p2.hashCode(), p1.equals(p2));
    }

    @Test
    public void hashAndEquals2() {
        final Plant p1 = factory.newPlant(3, Plant.Type.Fusion, 4, 3);
        final Plant p2 = factory.newPlant(33, Plant.Type.Coal, 45, 6);
        assertEquals(p1.hashCode() == p2.hashCode(), p1.equals(p2));
    }


    @Test
    public void equalsTrue() {
        final Plant sut = factory.newPlant(0, Plant.Type.Coal, 2, 1);
        final Plant sut2 = factory.newPlant(0, Plant.Type.Oil, 0, 34);
        assertEquals(sut, sut2);
        assertEquals(sut2, sut);
    }

    @Test
    public void equalsFalse() {
        final Plant sut = factory.newPlant(0, Plant.Type.Coal, 2, 1);
        final Plant sut2 = factory.newPlant(1, Plant.Type.Coal, 2, 1);
        assertNotEquals(sut, sut2);
        assertNotEquals(sut2, sut);
    }

    @Test
    public void equalsOtherClass() {
        final Plant sut = factory.newPlant(5, Plant.Type.Coal, 6, 2);
        final Player sutPlayer = factory.newPlayer("any Secret", "blue");
        assertFalse(sut.equals(sutPlayer));
        assertFalse(sutPlayer.equals(sut));
    }

    // compareTo
    @Test
    public void compareTo() {
        final Plant sut = factory.newPlant(1, Plant.Type.Coal, 3, 5);
        final Plant sut2 = factory.newPlant(1, Plant.Type.Coal, 3, 5);
        assertEquals(0, sut.compareTo(sut2));
        assertEquals(0, sut2.compareTo(sut));
    }

    @Test
    public void compareTo1() {
        final Plant sut = factory.newPlant(1, Plant.Type.Coal, 3, 5);
        final Plant sut2 = factory.newPlant(2, Plant.Type.Coal, 3, 5);
        assertTrue(sut.compareTo(sut2) < 0);
        assertTrue(sut2.compareTo(sut) > 0);
    }

    @Test
    public void compareTo2() {
        final Plant sut = factory.newPlant(15, Plant.Type.Coal, 3, 5);
        final Plant sut2 = factory.newPlant(2, Plant.Type.Coal, 3, 5);
        assertTrue(sut.compareTo(sut2) > 0);
        assertTrue(sut2.compareTo(sut) < 0);
    }

    @Test
    public void compareToWithSort() {
        final Plant sut1 = factory.newPlant(1, Plant.Type.Coal, 3, 5);
        final Plant sut3 = factory.newPlant(3, Plant.Type.Coal, 3, 5);
        final Plant sut5 = factory.newPlant(5, Plant.Type.Coal, 3, 5);
        final Plant sut7 = factory.newPlant(7, Plant.Type.Coal, 3, 5);
        final Plant sut9 = factory.newPlant(9, Plant.Type.Coal, 3, 5);
        final List<Plant> plants = new ArrayList<>(Arrays.asList(sut7, sut9, sut5, sut1, sut3));
        Collections.sort(plants);
        assertEquals(1, plants.get(0).getNumber());
        assertEquals(3, plants.get(1).getNumber());
        assertEquals(5, plants.get(2).getNumber());
        assertEquals(7, plants.get(3).getNumber());
        assertEquals(9, plants.get(4).getNumber());
    }
}
