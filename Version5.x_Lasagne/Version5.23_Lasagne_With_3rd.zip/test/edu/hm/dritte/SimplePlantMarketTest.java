package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.PlantMarket;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class SimplePlantMarketTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    @Test
    public void plantMarketNoFactory() {
        final PlantMarket plantMarket = factory.newPlantMarket(new EditionGermany());

        assertEquals(0, plantMarket.getActual().size());
        assertEquals(0, plantMarket.getFuture().size());
        assertEquals(42, plantMarket.getHidden().size());
        assertEquals(42, plantMarket.getNumberHidden());
    }

    @Test
    public void plantMarketNoFactory1() {
        final PlantMarket plantMarket = factory.newPlantMarket(new EditionGermany());

        plantMarket.getActual().add(factory.newPlant(2, Plant.Type.Coal, 3, 4));
        assertEquals(1, plantMarket.getActual().size());

        plantMarket.getFuture().add(factory.newPlant(5, Plant.Type.Garbage, 32, 5));
        assertEquals(1, plantMarket.getFuture().size());

        plantMarket.getHidden().add(factory.newPlant(7, Plant.Type.Oil, 35, 1));
        assertEquals(43, plantMarket.getHidden().size());
        assertEquals(43, plantMarket.getNumberHidden());
    }

    @Test
    public void findPlantNoFactory() {
        final PlantMarket plantMarket = factory.newPlantMarket(new EditionGermany());

        final Plant plant1 = factory.newPlant(2, Plant.Type.Coal, 3, 4);
        final Plant plant2 = factory.newPlant(5, Plant.Type.Garbage, 32, 5);
        final Plant plant3 = factory.newPlant(7, Plant.Type.Oil, 35, 1);
        plantMarket.getActual().add(plant1);
        plantMarket.getFuture().add(plant2);
        plantMarket.getHidden().add(plant3);

        assertSame(plant1, plantMarket.findPlant(2));
        assertSame(plant2, plantMarket.findPlant(5));
        assertSame(plant3, plantMarket.findPlant(7));
    }

    @Test
    public void removePlantNoFactory() {
        final PlantMarket plantMarket = factory.newPlantMarket(new EditionGermany());

        final Plant plant1 = factory.newPlant(2, Plant.Type.Coal, 3, 4);
        final Plant plant2 = factory.newPlant(5, Plant.Type.Garbage, 32, 5);
        final Plant plant3 = factory.newPlant(7, Plant.Type.Oil, 35, 1);
        plantMarket.getActual().add(plant1);
        plantMarket.getFuture().add(plant2);
        plantMarket.getHidden().clear();
        plantMarket.getHidden().add(plant3);

        assertNull(plantMarket.removePlant(89));

        assertSame(plant1, plantMarket.removePlant(2));
        assertNull(plantMarket.findPlant(2));

        assertSame(plant2, plantMarket.removePlant(5));
        assertNull(plantMarket.findPlant(5));

        assertSame(plant3, plantMarket.removePlant(7));
        assertNull(plantMarket.findPlant(7));
    }

}
