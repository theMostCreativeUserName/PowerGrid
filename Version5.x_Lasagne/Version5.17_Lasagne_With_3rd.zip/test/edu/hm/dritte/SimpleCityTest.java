package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.datastore.City;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.severin.powergrid.datastore.NeutralBoard;
import edu.hm.severin.powergrid.datastore.NeutralCity;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

public class SimpleCityTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // constructor, getName and getRegion
    @Test(expected = NullPointerException.class)
    public void ConstructorNameNull() {
        factory.newCity(null, 1);
    }

    @Test(expected = NullPointerException.class)
    public void ConstructorNameNull2() {
        factory.newCity(null, 15);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorNameBlank() {
        factory.newCity("", 13);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorNameBlank2() {
        factory.newCity("", 123);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorNameBlank3() {
        factory.newCity(" ", 3);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorNameBlank4() {
        factory.newCity("  ", 1223);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorNameBlank5() {
        factory.newCity("\n", 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorRegionInvalid() {
        factory.newCity("TestName", 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorRegionInvalid1() {
        factory.newCity("TestName", -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorRegionInvalid2() {
        factory.newCity("TestName", -2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorRegionInvalid3() {
        factory.newCity("TestName", Integer.MIN_VALUE);
    }

    @Test
    public void ConstructorValid() {
        final String cityName = "TestName";
        final int cityRegion = 1;
        final City sut = factory.newCity(cityName, cityRegion);
        assertEquals(cityName, sut.getName());
        assertEquals(cityRegion, sut.getRegion());
    }

    @Test
    public void ConstructorValid1() {
        final String cityName = "longer test name";
        final int cityRegion = 13;
        final City sut = factory.newCity(cityName, cityRegion);
        assertEquals(cityName, sut.getName());
        assertEquals(cityRegion, sut.getRegion());
    }

    @Test
    public void ConstructorValid2() {
        final String cityName = "Osn\nabr\u00FCck";
        final int cityRegion = Integer.MAX_VALUE;
        final City sut = factory.newCity(cityName, cityRegion);
        assertEquals(cityName, sut.getName());
        assertEquals(cityRegion, sut.getRegion());
    }

    // connect and getConnections
    @Test(expected = IllegalStateException.class)
    public void connectAfterClose() {
        final City sut = factory.newCity("randomName", 11);
        final City sut2 = factory.newCity("other name", 1);
        final City sut3 = factory.newCity("mine", 5);
        sut.connect(sut3, 4);
        sut.close();
        sut.connect(sut2, 15);
    }

    @Test(expected = IllegalStateException.class)
    public void connectAfterClose2() {
        final City sut = factory.newCity("randomName", 11);
        final City sut2 = factory.newCity("other name", 1);
        sut.close();
        sut2.close();
        sut.connect(sut2, 115);
    }

    @Test
    public void connectAfterClose3() {
        final City sut = factory.newCity("randomName", 11);
        final City sut2 = factory.newCity("other name", 1);
        final City sutTo = factory.newCity("other name 2", 2);
        sut2.connect(sutTo, 1);
        sut2.close();
        sut.connect(sut2, 115);
        sut.close();
        assertEquals(1, sut.getConnections().size());
    }

    @Test(expected = IllegalArgumentException.class)
    public void connectInvalidCost() {
        final City sut = factory.newCity("randomName", 11);
        final City sut2 = factory.newCity("other name", 1);
        sut.connect(sut2, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void connectInvalidCost2() {
        final City sut = factory.newCity("randomName", 11);
        final City sut2 = factory.newCity("other name", 1);
        sut.connect(sut2, -2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void connectInvalidCost3() {
        final City sut = factory.newCity("randomName", 11);
        final City sut2 = factory.newCity("other name", 1);
        sut.connect(sut2, Integer.MIN_VALUE);
    }

    @Test(expected = NullPointerException.class)
    public void connectTargetNull() {
        final City sut = factory.newCity("randomName", 11);
        sut.connect(null, 13);
    }

    @Test(expected = IllegalArgumentException.class)
    public void connectItself() {
        final City sut = factory.newCity("abdfd", 11);
        sut.connect(sut, 1942);
    }

    @Test(expected = IllegalArgumentException.class)
    public void connectItself2() {
        final City sut = factory.newCity("abdfd", 11);
        final City sut2 = factory.newCity("abdfd", 3532);
        sut.connect(sut2, 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void connectTwice() {
        final City sut = factory.newCity("25", 11);
        final City sut2 = factory.newCity("ad53", 3532);
        sut.connect(sut2, 1);
        sut.connect(sut2, 51);
    }

    @Test(expected = IllegalArgumentException.class)
    public void connectTwiceManual() {
        final City sut = factory.newCity("adf", 11);
        final City sut2 = factory.newCity("asffge", 3532);
        sut.getConnections().put(sut2, 5123);
        sut.connect(sut2, 51);
    }

    @Test
    public void connectValid() {
        final City sut = factory.newCity("test", 11);
        final City sut2 = factory.newCity("test name", 1);
        sut.connect(sut2, 15);
        assertEquals(1, sut.getConnections().size());
        assertTrue(sut.getConnections().containsKey(sut2));
    }

    @Test
    public void connectValid2() {
        final City sut = factory.newCity("test", 11);
        final City sut2 = factory.newCity("adf name", 1);
        final City sut3 = factory.newCity("test asdfb", 3);
        final City sut4 = factory.newCity("asdf asdfb", 15);
        sut.connect(sut2, 15);
        sut.connect(sut3, 156);
        assertEquals(2, sut.getConnections().size());
        assertTrue(sut.getConnections().containsKey(sut2));
        assertTrue(sut.getConnections().containsKey(sut3));
        assertFalse(sut.getConnections().containsKey(sut4));
    }

    // close
    @Test(expected = IllegalStateException.class)
    public void closeTwice() {
        final City sut = factory.newCity("test name 123", 74);
        final City sut2 = factory.newCity("abc", 8592);
        sut.connect(sut2, 19);
        sut2.connect(sut, 48);
        sut.close();
        sut.close();
    }

    @Test(expected = IllegalStateException.class)
    public void closeWithNoConnections() {
        final City sut = factory.newCity("test", 12);
        sut.close();
    }

    @Test(expected = UnsupportedOperationException.class)
    public void closeOnceCheckImmutable() {
        final City sut = factory.newCity("from", 12);
        final City sutTo = factory.newCity("to", 11);
        sut.connect(sutTo, 14);
        sut.close();

        sut.getConnections().put(factory.newCity("abc", 15), 158);
    }

    @Test
    public void closeOnceCheckImmutable2() {
        final City sut = factory.newCity("test name asfd", 12);
        final City sut2 = factory.newCity("abb", 41);
        sut.connect(sut2, 178);
        final Map<City, Integer> connections = sut.getConnections();
        sut.close();

        connections.put(factory.newCity("m889", 781), 881);
        assertEquals(2, sut.getConnections().size());
    }

    // equals
    @Test
    public void equalsItself() {
        final City sut = factory.newCity("cdadf", 15);
        assertEquals(sut, sut);
    }

    @Test
    public void equalsNullNot() {
        final City sut = factory.newCity("abc", 115);
        assertNotEquals(sut, null);
        assertNotEquals(null, sut);
    }

    @Test
    public void equalsOtherClassNot() {
        final City sut = factory.newCity("blabla", 15);
        final String sut2 = "yes i am a city...";
        assertNotEquals(sut, sut2);
        assertNotEquals(sut2, sut);
    }

    @Test
    public void equalsTrue() {
        final City sut = factory.newCity("blabla", 15);
        final City sut2 = factory.newCity("blabla", 15);
        assertEquals(sut, sut2);
        assertEquals(sut2, sut);
    }

    @Test
    public void equalsTrue2() {
        final City sut = factory.newCity("test", 125);
        final City sut2 = factory.newCity("test", 1455);
        assertEquals(sut, sut2);
        assertEquals(sut2, sut);
    }

    @Test
    public void equalsTrue3() {
        final City sut = factory.newCity("abc", 125);
        final City sut2 = factory.newCity("abc", 1455);
        final City sut3 = factory.newCity("abc", 1582);
        assertEquals(sut, sut2);
        assertEquals(sut, sut3);
        assertEquals(sut2, sut);
        assertEquals(sut2, sut3);
        assertEquals(sut3, sut);
        assertEquals(sut3, sut2);
    }

    @Test
    public void equalsFalse() {
        final City sut = factory.newCity("abc", 1);
        final City sut2 = factory.newCity("abc2", 1);
        assertNotEquals(sut, sut2);
    }

    // hashCode
    @Test
    public void hashCode1() {
        final String cityName = "this is a name";
        final City sut = factory.newCity(cityName, 14);
        final City sut2 = factory.newCity(cityName, 1512);
        assertEquals(sut2.hashCode(), sut.hashCode());
    }

    @Test
    public void hashCodeNotEqual() {
        final City sut = factory.newCity("cityName", 15);
        final City sut2 = factory.newCity("other name", 15);
        assertNotEquals(sut.hashCode(), sut2.hashCode());
    }

    // compareTo
    @Test
    public void compareTo() {
        final City sut = factory.newCity("abc", 15);
        final City sut2 = factory.newCity("abc", 17);
        assertEquals(0, sut.compareTo(sut2));
        assertEquals(0, sut2.compareTo(sut));
    }

    @Test
    public void compareTo1() {
        final City sut = factory.newCity("abc", 1);
        final City sut2 = factory.newCity("ABC", 1);
        assertEquals(0, sut.compareTo(sut2));
        assertEquals(0, sut2.compareTo(sut));
    }

    @Test
    public void compareTo2() {
        final City sut = factory.newCity("a", 1);
        final City sut2 = factory.newCity("z", 1);
        assertTrue(sut.compareTo(sut2) < 0);
        assertTrue(sut2.compareTo(sut) > 0);
    }

    @Test
    public void compareTo3() {
        final City sut = factory.newCity("a", 1);
        final City sut2 = factory.newCity("B", 1);
        assertTrue(sut.compareTo(sut2) < 0);
        assertTrue(sut2.compareTo(sut) > 0);
    }

    @Test
    public void compareToWithSort() {
        final City sut1 = factory.newCity("Zypern", 5);
        final City sut2 = factory.newCity("Dortmund", 8);
        final City sut3 = factory.newCity("Bauern", 9);
        final City sut4 = factory.newCity("aachen", 4);
        final City sut5 = factory.newCity("Kassel", 15);
        final List<City> cities = new ArrayList<>(Arrays.asList(sut4, sut5, sut3, sut1, sut2));
        Collections.sort(cities);
        assertEquals("aachen", cities.get(0).getName());
        assertEquals("Bauern", cities.get(1).getName());
        assertEquals("Dortmund", cities.get(2).getName());
        assertEquals("Kassel", cities.get(3).getName());
        assertEquals("Zypern", cities.get(4).getName());
    }
}
