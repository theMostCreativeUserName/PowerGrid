package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Auction;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

public class SimpleGameTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // constructor
    @Test
    public void validConstructor() {
        factory.newGame(new EditionGermany());
    }

    @Test(expected = NullPointerException.class)
    public void invalidConstructor() {
        factory.newGame(null);
    }

    // values
    @Test
    public void validDefaultValues() {
        final Game game = factory.newGame(new EditionGermany());

        assertEquals(EditionGermany.class, game.getEdition().getClass());
        assertEquals(0, game.getRound());
        assertEquals(Phase.Opening, game.getPhase());
        assertEquals(new ArrayList<>(), game.getPlayers());
        assertEquals(0, game.getLevel());
        assertNull(game.findPlayer("abc"));
        assertNotNull(game.getFactory());
        assertEquals(0, game.getNumMoves());
        assertNull(game.getAuction());
        //assertNotNull(game.getResourceMarket());
        //assertNotNull(game.getPlantMarket());
        assertNotNull(game.getBoard());
    }

    // setRound
    @Test(expected = IllegalArgumentException.class)
    public void setRoundInvalid() {
        final Game sut = factory.newGame(new EditionGermany());
        assertEquals(0, sut.getRound());
        sut.setRound(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setRoundInvalid1() {
        final Game sut = factory.newGame(new EditionGermany());
        assertEquals(0, sut.getRound());
        sut.setRound(-2);
    }

    @Test
    public void setRoundValid() {
        final Game sut = factory.newGame(new EditionGermany());
        assertEquals(0, sut.getRound());
        sut.setRound(1);
        assertEquals(1, sut.getRound());
        sut.setRound(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, sut.getRound());
        sut.setRound(0);
        assertEquals(0, sut.getRound());
    }

    // setPhase
    @Test(expected = IllegalArgumentException.class)
    public void setPhaseInvalidNull() {
        final Game sut = factory.newGame(new EditionGermany());
        sut.setPhase(null);
    }

    @Test
    public void setPhaseValid() {
        final Game sut = factory.newGame(new EditionGermany());
        assertEquals(Phase.Opening, sut.getPhase());
        sut.setPhase(Phase.Building);
        assertEquals(Phase.Building, sut.getPhase());
        sut.setPhase(Phase.PlantBuying);
        assertEquals(Phase.PlantBuying, sut.getPhase());
    }

    // setLevel
    @Test(expected = IllegalArgumentException.class)
    public void setLevelInvalid() {
        final Game sut = factory.newGame(new EditionGermany());
        sut.setLevel(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setLevelInvalid1() {
        final Game sut = factory.newGame(new EditionGermany());
        sut.setLevel(-2);
    }

    @Test
    public void setLevelAllValid() {
        final Game sut = factory.newGame(new EditionGermany());
        assertEquals(0, sut.getLevel());
        sut.setLevel(0);
        assertEquals(0, sut.getLevel());
        sut.setLevel(1);
        assertEquals(1, sut.getLevel());
        sut.setLevel(2);
        assertEquals(2, sut.getLevel());
        sut.setLevel(0);
        assertEquals(0, sut.getLevel());
    }

    @Test
    public void setLevelValid() {
        final Game sut = factory.newGame(new EditionGermany());
        sut.setLevel(3);
        assertEquals(3, sut.getLevel());
    }

    @Test
    public void setLevelValid2() {
        final Game sut = factory.newGame(new EditionGermany());
        sut.setLevel(4);
        assertEquals(4, sut.getLevel());
    }

    // setNumMoves
    @Test(expected = IllegalArgumentException.class)
    public void setNumMovesInvalid() {
        final Game sut = factory.newGame(new EditionGermany());
        assertEquals(0, sut.getNumMoves());
        sut.setNumMoves(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setNumMovesInvalid1() {
        final Game sut = factory.newGame(new EditionGermany());
        sut.setNumMoves(-2);
    }

    @Test
    public void setNumMovesValid() {
        final Game sut = factory.newGame(new EditionGermany());
        assertEquals(0, sut.getNumMoves());
        sut.setNumMoves(1);
        assertEquals(1, sut.getNumMoves());
        sut.setNumMoves(5);
        assertEquals(5, sut.getNumMoves());
        sut.setNumMoves(100);
        assertEquals(100, sut.getNumMoves());
        sut.setNumMoves(0);
        assertEquals(0, sut.getNumMoves());
    }



    // getPlantMarket
    @Test
    public void getPlantMarket() {
        final Game sut = factory.newGame(new EditionGermany());
        assertNotNull(sut.getPlantMarket());
    }

    // getResourceMarket
    @Test
    public void getResourceMarket() {
        final Game sut = factory.newGame(new EditionGermany());
        assertNotNull(sut.getResourceMarket());
    }

    // getAuction
    @Test
    public void getAuction() {
        final Game sut = factory.newGame(new EditionGermany());
        assertNull(sut.getAuction());
    }

    @Test
    public void getAuction1() {
        final Game sut = factory.newGame(new EditionGermany());
        final Plant plant = factory.newPlant(5, Plant.Type.Coal, 4, 6);
        final Player player1 = factory.newPlayer("secret1", "secret1");
        final Player player2 = factory.newPlayer("secret2", "secret2");
        final Player player3 = factory.newPlayer("secret3", "secret3");
        final List<Player> players = List.of(player1, player3, player2);

        final Auction auction = factory.newAuction(plant, players);
        sut.setAuction(auction);
        assertNotNull(sut.getAuction());
        assertSame(auction, sut.getAuction());
    }

    // findPlayer
    @Test
    public void findPlayer() {
        final Game sut = factory.newGame(new EditionGermany());

        final Player player1 = factory.newPlayer("secret1", "secret1");
        final Player player2 = factory.newPlayer("secret2", "secret2");
        final Player player3 = factory.newPlayer("secret3", "secret3");

        sut.getPlayers().add(player1);
        sut.getPlayers().add(player2);
        sut.getPlayers().add(player3);

        assertSame(player1, sut.findPlayer("secret1"));
        assertSame(player2, sut.findPlayer("secret2"));
        assertSame(player3, sut.findPlayer("secret3"));
        assertNull(sut.findPlayer("any secret"));
    }
}
