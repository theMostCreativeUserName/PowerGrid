package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.datastore.Auction;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class SimpleAuctionTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // constructor
    @Test(expected = NullPointerException.class)
    public void ConstructorPlantNull() {
        factory.newPlant(1, Plant.Type.Oil, 2, 3);
        final Player player = factory.newPlayer("123456", "123456");
        final List<Player> players = new ArrayList<>();
        players.add(player);
        factory.newAuction(null, players);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorPlayersNull() {
        final Plant plant = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        factory.newAuction(plant, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void ConstructorPlayersEmpty() {
        final Plant plant = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        factory.newAuction(plant, new ArrayList<>());
    }

    // getPlant
    @Test
    public void getPlant() {
        final Plant plant = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        final Player player1 = factory.newPlayer("123456", "123456");
        final Player player2 = factory.newPlayer("654321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        assertEquals(plant, sut.getPlant());
    }

    // setPlayer
    @Test
    public void setPlayer() {
        final Plant plant = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        final Player player1 = factory.newPlayer("123456", "123456");
        final Player player2 = factory.newPlayer("654321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        sut.setPlayer(player2);
        assertEquals(player2, sut.getPlayer());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setPlayerNull() {
        final Plant plant = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        final Player player1 = factory.newPlayer("123456", "123456");
        final Player player2 = factory.newPlayer("654321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        sut.setPlayer(null);
    }

    // setAmount
    @Test
    public void setAmount() {
        final Plant plant = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        final Player player1 = factory.newPlayer("123456", "123456");
        final Player player2 = factory.newPlayer("654321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        final int want = 15;
        sut.setAmount(want);
        assertEquals(want, sut.getAmount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setAmountNegative() {
        final Plant plant = factory.newPlant(1, Plant.Type.Oil, 2, 3);
        final Player player1 = factory.newPlayer("123456", "123456");
        final Player player2 = factory.newPlayer("654321", "654321");
        final List<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);

        final Auction sut = factory.newAuction(plant, players);
        sut.setAmount(-5);
    }
}
