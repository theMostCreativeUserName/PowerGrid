package edu.hm.severin.powergrid.datastore;

import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Resource;


import java.util.Set;

/**
 * creates the Plants of the game.
 *
 * @author Severin, Pietsch
 */

// PMD has problem "Data Classes are simple data holders". Cant be fixed.
public class NeutralPlant implements Plant {

    /**
     * number of plant.
     */
    private final int number;
    /**
     * type of plant.
     */
    private final Plant.Type type;
    /**
     * number of resources used by plant.
     */
    private final int numberOfResources;
    /**
     * number of cities that can be provided.
     */
    private final int cities;
    /**
     * is plant operating?
     */
    private boolean operated;
    /**
     * resource thar can be used by plant.
     */
    private final Set<Bag<Resource>> usableResources;

    /**
     * creates new Neutral Plant.
     *
     * @param number    identifying number
     * @param type      type of plant
     * @param resources Number of Resources used in one turn
     * @param cities    the plant provides to
     */

    public NeutralPlant(final int number, final Type type, final int resources, final int cities) {
        if (number < 0) throw new IllegalArgumentException("number of plant cannot be negative");
        if (cities <= 0) throw new IllegalArgumentException("plant provides at least one city");
        if (resources < 0) throw new IllegalArgumentException("plant uses at least one resource");
        if (type == null) throw new IllegalArgumentException();

        this.number = number;
        this.type = type;
        this.numberOfResources = resources;
        this.cities = cities;
        this.usableResources = getUsableResources();
    }

    /**
     * identifying number.
     *
     * @return number. not negative
     */
    @Override
    public int getNumber() {
        return number;
    }

    /**
     * number of cities that can be provided.
     *
     * @return cities
     */
    @Override
    public int getCities() {
        return cities;
    }

    /**
     * Number of resources.
     *
     * @return resources
     */
    @Override
    public int getNumberOfResources() {
        return numberOfResources;
    }

    /**
     * type of the plant.
     *
     * @return type
     */
    @Override
    public Type getType() {
        return type;
    }

    /**
     * tests if plant has provided energy.
     *
     * @return true, if plant produced energy
     */
    @Override
    public boolean hasOperated() {
        return operated;
    }

    /**
     * sets if plant has produced energy.
     *
     * @param operated true if plant produced energy
     */
    @Override
    public void setOperated(boolean operated) {
        this.operated = operated;
    }

    /**
     * set of resources, that this plant can use.
     * if plant uses no resources at all set is empty.
     *
     * @return different resources. not null, not empty.
     * sets and elements are immutable.
     */
    @Override
    public Set<Bag<Resource>> getResources() {
        return this.usableResources;
    }

    /**
     * creates the set of bags for usableResources.
     * @return null in this version
     */
    private Set<Bag<Resource>> getUsableResources() {
        return null;
    }

}
