package edu.hm.severin.powergrid.datastore;

import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.datastore.Board;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Auction;
import edu.hm.cs.rs.powergrid.datastore.ResourceMarket;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.PlantMarket;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.City;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * creates Factory.
 *
 * @author Severin, Pietsch
 */
public class NeutralFactory implements Factory {

    /**
     * list of city names.
     */
    private final Map<String, City> nameOfCity = new HashMap<>();

    /**
     * plant map.
     */
    private final Map<Integer, Plant> numberOfPlant = new HashMap<>();

    /**
     * player map.
     */
    private final Map<String, Player> colorOfPlayer = new HashMap<>();

    /**
     * generated board.
     */
    private Board board;

    /**
     * new Player.
     *
     * @param secret secret of player
     * @param color  color of player
     * @return null, at the moment
     */
    @Override
    public Player newPlayer(final String secret, final String color) {
        final Player result;
        if(colorOfPlayer.containsKey(color))
            result = colorOfPlayer.get(color);
        else {
            result = new NeutralPlayer(secret, color);
            colorOfPlayer.put(color, result);
        }
        return result;
    }

    /**
     * new City.
     *
     * @param name Name. Not Null, not empty.
     * @param area Area. Bigger 0.
     * @return new NeutralCity
     */
    @Override
    public City newCity(final String name, final int area) {
        final City result;
        if(nameOfCity.containsKey(name))
            result = nameOfCity.get(name);
        else {
            result = new NeutralCity(name, area);
            nameOfCity.put(name, result);
        }
        return result;
    }

    /**
     * new Plant.
     *
     * @param number    number of plant, not negative
     * @param type      plant type, not null
     * @param resources number of resources used by plant, not 0
     * @param cities    number of cities provided by plant, is bigger than 0
     * @return null at the moment
     */

    @Override
    public Plant newPlant(final int number, final Plant.Type type, final int resources, final int cities) {
        final Plant result;
        if(numberOfPlant.containsKey(number))
            return numberOfPlant.get(number);
        else {
            result = new NeutralPlant(number, type, resources, cities);
            numberOfPlant.put(number, result);
        }
        return result;
    }

    /**
     * new PlantMarket.
     *
     * @param edition edition of this session
     * @return null at the moment
     */
    @Override
    public PlantMarket newPlantMarket(final Edition edition) {
        return null;
    }

    /**
     * new ResourceMarket.
     *
     * @param edition edition of this session
     * @return null at the moment
     */
    @Override
    public ResourceMarket newResourceMarket(final Edition edition) {
        return null;
    }

    /**
     * new Board.
     *
     * @param edition edition of this session
     * @return new NeutralBoard
     */
    @Override
    public Board newBoard(final Edition edition) {
        if (board == null) {
            board = new NeutralBoard(edition);
        }
        return board;
    }

    /**
     * new Auction.
     *
     * @param plant   plant to be auctioned, not null
     * @param players players participating, not null
     *                order of players is their bidding order
     * @return null at the moment
     */
    @Override
    public Auction newAuction(Plant plant, List<Player> players) {
        return null;
    }

    /**
     * new Game.
     *
     * @param edition edition of the game
     * @return null at the moment
     */
    @Override
    public Game newGame(final Edition edition) {
        return null;
    }
}
