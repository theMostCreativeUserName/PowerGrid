package edu.hm.cs.rs.powergrid.datastore;

import edu.hm.cs.rs.powergrid.EditionGermany;
import static org.junit.Assert.assertEquals;

import edu.hm.cs.rs.powergrid.datastore.mutable.OpenBoard;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenCity;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Minimaler Test der ersten Datastore-Klassen.
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-09
 */
public class Smoke1Test {
    /** Verhindert Endlosscheilfen. */
    @Rule public final Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /** FQCN der konkreten Factoryklasse. */
    private final String factoryFQCN;

    /** Factory. */
    private final OpenFactory factory;

    /** Initialisiert die Factory . */
    public Smoke1Test() throws IOException {
        factoryFQCN = "edu.hm.severin.powergrid.datastore.NeutralFactory";
        factory = OpenFactory.newFactory(factoryFQCN);
    }

    @Test public void newCity() {
        // arrange
        final OpenCity sut = factory.newCity("Entenhausen", 1);
        // act
        // assert
        assertEquals("new city has given name", "Entenhausen", sut.getName());
        assertEquals("new city is in given region", 1, sut.getRegion());
    }

    @Test public void newBoard() {
        // arrange
        final EditionGermany edition = new EditionGermany();
        final OpenBoard sut = factory.newBoard(edition);
        // act
        sut.close();
        // assert
        assertEquals("board holds all specified cities",
                (long)edition.getCitySpecifications().size(),
                sut.getCities().size());
    }

}