package edu.hm.severin.powergrid.logic;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import edu.hm.severin.powergrid.logic.move.HotMoves;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;


//Fake Rules
public class FakeRulesTestClass extends StandardRules{


    //FakeMove
    static class FakeMove implements HotMove {


        private final OpenGame game;
        private final Optional<OpenPlayer> player;

        public FakeMove(){
            this.game = null;
            this.player = null;
        }

        public FakeMove(OpenGame game, Optional<OpenPlayer> player) {
            this.game = game;
            this.player = player;
        }

        @Override
        public Optional<Problem> run(boolean real) {
            if (game.getPhase() != Phase.PlayerOrdering)
                return Optional.of(Problem.Expired);

            if (real)
                game.setPhase(Phase.Terminated);
            return Optional.empty();
        }

        @Override
        public OpenGame getGame() {
            return null;
        }

        @Override
        public Set<HotMove> collect(OpenGame game, Optional<OpenPlayer> player) {
            final HotMove move = new FakeMove(game, player);
            Set<HotMove> result;
            if (move.run(false).isEmpty())
                result = Set.of(move);
            else
                result = Set.of();
            return result;
        }

        @Override
        public MoveType getType() {
            return MoveType.Build1stCity;
        }
    }

    //FakeMove 2
    static class FakeMove2 implements HotMove {


        private final OpenGame game;
        private final Optional<OpenPlayer> player;

        public FakeMove2(){
            this.game = null;
            this.player = null;
        }

        public FakeMove2(OpenGame game, Optional<OpenPlayer> player) {
            this.game = game;
            this.player = player;
        }



        @Override
        public Optional<Problem> run(boolean real) {
            if (game.getPhase() != Phase.PlayerOrdering)
                return Optional.of(Problem.Expired);
            if (game.getOpenPlayers().size() != 3)
                return Optional.of(Problem.Expired);
            if (real)
                game.setPhase(Phase.Terminated);
            return Optional.empty();
        }

        @Override
        public OpenGame getGame() {
            return null;
        }

        @Override
        public Set<HotMove> collect(OpenGame game, Optional<OpenPlayer> player) {
            final HotMove move = new FakeMove2(game, player);
            Set<HotMove> result;
            if (move.run(false).isEmpty())
                result = Set.of(move);
            else
                result = Set.of();
            return result;
        }

        @Override
        public MoveType getType() {
            return MoveType.Build1stCity;
        }
    }

    //FakeRules
    /**
     * C-tor.
     *
     * @param game this game
     */
    public FakeRulesTestClass(OpenGame game) {
        super(game);
    }

    @Override
    public Set<Move> getPrototypes() {
        Set<Move> allMoves = new HashSet<>();
        allMoves.add(HotMoves.getPrototypes().stream().filter(x -> x.getType() == MoveType.CommenceGame).findFirst().get());
        allMoves.add(new FakeMove());
        allMoves.add(new FakeMove2());
        return allMoves;
    }
}

