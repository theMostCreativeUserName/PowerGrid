package edu.hm.cs.rs.powergrid; public interface Observer {}
