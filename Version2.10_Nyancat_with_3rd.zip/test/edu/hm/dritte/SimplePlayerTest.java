package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.datastore.City;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class SimplePlayerTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    // constructor and getter
    @Test
    public void constructorValid() {
        final String color = "random color";
        final String secret = "psst";
        final Player sut = factory.newPlayer(secret, color);
        assertEquals(color, sut.getColor());
        assertEquals(secret, sut.getSecret());
    }

    @Test(expected = NullPointerException.class)
    public void constructorSecretNull() {
        factory.newPlayer(null, "weird color");
    }

    @Test
    public void constructorSecretEmpty() {
        factory.newPlayer("", "brown color");
    }

    @Test(expected = NullPointerException.class)
    public void constructorColorNull() {
        factory.newPlayer("psssssst", null);
    }

    @Test
    public void constructorColorEmpty() {
        factory.newPlayer("hello there", "");
    }

    @Test(expected = NullPointerException.class)
    public void constructorSecretColorNull() {
        factory.newPlayer(null, null);
    }

    @Test
    public void constructorSecretColorEmpty() {
        factory.newPlayer("", "");
    }

    // getSecret and hasSecret
    @Test
    public void getSecretOnce() {
        final String secret = "green";
        final Player sut = factory.newPlayer(secret, "yellow");
        assertEquals(secret, sut.getSecret());
    }

    @Test
    public void getSecretTwice() {
        final Player sut = factory.newPlayer("blue", "green");
        assertNotNull(sut.getSecret());
        assertNull(sut.getSecret());
    }

    @Test
    public void hasSecretTrue() {
        final String secret = "abc";
        final Player sut = factory.newPlayer(secret, "red");
        assertTrue(sut.hasSecret(secret));
    }

    @Test
    public void hasSecretFalse() {
        final String secret = ":)";
        final Player sut = factory.newPlayer(secret, "");
        assertFalse(sut.hasSecret("Not" + secret));
    }

    // getElectro and setElectro
    @Test
    public void getElectro() {
        final Player sut = factory.newPlayer("asjdf82u83jf2j", "light green");
        assertEquals(0, sut.getElectro());
    }

    @Test
    public void setElectro() {
        final int want = 42;
        final Player sut = factory.newPlayer("asjdf82u83jf2j", "light green");
        sut.setElectro(want);
        assertEquals(want, sut.getElectro());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setElectroNegative() {
        final int want = -42;
        final Player sut = factory.newPlayer("getSUTSecret(), getSUTColor()", "z");
        sut.setElectro(want);
    }

    @Test
    public void setElectro0() {
        final int want = 0;
        final Player sut = factory.newPlayer("this is annoying", "very annoying");
        sut.setElectro(want);
        assertEquals(want, sut.getElectro());
    }

    @Test
    public void setElectroMaxInt() {
        final int want = Integer.MAX_VALUE;
        final Player sut = factory.newPlayer("does anybody really read this?", "i guess not...");
        sut.setElectro(want);
        assertEquals(want, sut.getElectro());
    }

    // setPassed and hasPassed
    @Test
    public void getPassed() {
        final Player sut = factory.newPlayer(":)", ":(");
        assertFalse(sut.hasPassed());
    }

    @Test
    public void setPassedTrue() {
        final Player sut = factory.newPlayer("abc", "cba");
        sut.setPassed(true);
        assertTrue(sut.hasPassed());
    }

    @Test
    public void setPassedFalse() {
        final Player sut = factory.newPlayer(" ", "     ");
        sut.setPassed(false);
        assertFalse(sut.hasPassed());
    }

    @Test
    public void setPassedTwice() {
        final Player sut = factory.newPlayer("", "");
        assertFalse(sut.hasPassed());
        sut.setPassed(true);
        assertTrue(sut.hasPassed());
        sut.setPassed(false);
        assertFalse(sut.hasPassed());
    }

    // getCities
    @Test
    public void getCitiesEmpty() {
        final Player sut = factory.newPlayer("i", "o");
        assertTrue(sut.getCities().isEmpty());
    }

    @Test
    public void getCitiesWithCity() {
        final Player sut = factory.newPlayer("hmm", "...");
        final City city = factory.newCity("a name", 5);
        sut.getCities().add(city);
        assertEquals(1, sut.getCities().size());
        assertTrue(sut.getCities().contains(city));
    }

    // getPlants
    @Test
    public void getPlantsEmpty() {
        final Player sut = factory.newPlayer("784,", "88234");
        assertTrue(sut.getPlants().isEmpty());
    }

    @Test
    public void getPlantsWithPlants() {
        final Player sut = factory.newPlayer("tu", "ul");
        final Plant plant = factory.newPlant(1, Plant.Type.Garbage, 5, 5);
        sut.getPlants().add(plant);
        assertEquals(1, sut.getPlants().size());
        assertTrue(sut.getPlants().contains(plant));
    }

    // equals

    @Test
    public void nullEqualsPlayer() {
        final Player sut = factory.newPlayer("random secret2", "green");
        assertNotEquals(null, sut);
    }

    @Test
    public void bagEqualsDiffClass() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final City city = factory.newCity("asd", 3);
        assertNotEquals(sut, city);
    }

    @Test
    public void PlayerEqualsThis() {
        final Player sut = factory.newPlayer("random secret2", "green");
        assertEquals(sut, sut);
    }

    @Test
    public void playerEqualsTransitivity() {
        final Player sut1 = factory.newPlayer("random secret1", "green");
        final Player sut2 = factory.newPlayer("random secretas", "blue");
        final Player sut3 = factory.newPlayer("random 3", "red");
        assertNotEquals(sut1, sut2);
        assertNotEquals(sut2, sut3);
    }

    @Test
    public void playerEqualsTransitivity2() {
        final Player sut1 = factory.newPlayer("random secret1", "purlple");
        final Player sut2 = factory.newPlayer("random secretas", "hurple");
        final Player sut3 = factory.newPlayer("random 3", "curple");
        assertNotEquals(sut1, sut2);
        assertNotEquals(sut2, sut3);
    }

    @Test
    public void PlayerEqualsNull() {
        final Player sut = factory.newPlayer("random secret2", "green");
        assertNotEquals(sut, null);
    }

    @Test
    public void equalsFalse() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final Player sut2 = factory.newPlayer("random secret2", "greeen");
        assertNotEquals(sut, sut2);
    }

    @Test
    public void equals1() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final Player other = factory.newPlayer("random secret2", "greeen");
        assertNotEquals(sut, other);
    }

    @Test
    public void equals2() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final Player other = factory.newPlayer("random secret2", "green");
        assertEquals(sut, other);
    }

    @Test
    public void equals3() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final Player other = factory.newPlayer("a", "green");
        assertEquals(sut, other);
    }

    @Test
    public void equals4() {
        final Player sut = factory.newPlayer("color", "red");
        final Player other = factory.newPlayer("asd", "red");
        assertEquals(sut.equals(other), other.equals(sut));
    }

    @Test
    public void equalsNoFactory() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final Player sut2 = factory.newPlayer("random secret2", "green");
        assertEquals(sut, sut2);
        assertEquals(sut2, sut);
    }

    @Test
    public void equalsNoFactory1() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final Player sut2 = factory.newPlayer("abv", "green");
        assertEquals(sut, sut2);
        assertEquals(sut2, sut);
    }

    @Test
    public void equalsNoFactory2() {
        final Player sut = factory.newPlayer("random secret2", "green");
        final Player sut2 = factory.newPlayer("random", "blue");
        assertNotEquals(sut, sut2);
        assertNotEquals(sut2, sut);
    }

    // hashCode
    @Test
    public void hashCode1() {
        final Player sut = factory.newPlayer("color", "red");
        final Player other = factory.newPlayer("asd", "blue");
        assertNotEquals(sut.hashCode(), other.hashCode());
    }

    @Test
    public void hashCode2() {
        final Player sut = factory.newPlayer("color", "red");
        final Player other = factory.newPlayer("asd", "red");
        assertEquals(sut.hashCode(), other.hashCode());
    }

    // hasCode and equals
    @Test
    public void hashCodeEquals() {
        final Player sut = factory.newPlayer("color", "red");
        final Player other = factory.newPlayer("asd", "red");
        assertEquals(sut.equals(other), sut.hashCode() == other.hashCode());
    }

    @Test
    public void hashCodeEquals2() {
        final Player sut = factory.newPlayer("color", "asd");
        final Player other = factory.newPlayer("asd", "dsa");
        assertNotEquals(sut.equals(other), sut.hashCode() == sut.hashCode());
    }


}
