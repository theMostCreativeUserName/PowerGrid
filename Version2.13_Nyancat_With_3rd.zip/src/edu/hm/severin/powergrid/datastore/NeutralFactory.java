package edu.hm.severin.powergrid.datastore;

import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.datastore.Board;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.cs.rs.powergrid.datastore.Auction;
import edu.hm.cs.rs.powergrid.datastore.ResourceMarket;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.PlantMarket;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.City;

import java.util.List;

/**
 * creates Factory.
 *
 * @author Severin, Pietsch
 */
// checkstyle wants this class to be defined as abstract: Error [AbstractClassName]
// but this goes against the rules
public class NeutralFactory implements Factory {

    /**
     * new Player.
     *
     * @param secret secret of player
     * @param color  color of player
     * @return null, at the moment
     */
    @Override
    public Player newPlayer(final String secret, final String color) {
        return new NeutralPlayer(secret, color);
    }

    /**
     * new City.
     *
     * @param name Name. Not Null, not empty.
     * @param area Area. Bigger 0.
     * @return new NeutralCity
     */
    @Override
    public City newCity(final String name, final int area) {
        return new NeutralCity(name, area);
    }

    /**
     * new Plant.
     *
     * @param number    number of plant, not negative
     * @param type      plant type, not null
     * @param resources number of resources used by plant, not 0
     * @param cities    number of cities provided by plant, is bigger than 0
     * @return null at the moment
     */

    @Override
    public Plant newPlant(final int number, final Plant.Type type, final int resources, final int cities) {

        return new NeutralPlant(number, type, resources, cities);
    }

    /**
     * new PlantMarket.
     *
     * @param edition edition of this session
     * @return null at the moment
     */
    @Override
    public PlantMarket newPlantMarket(final Edition edition) {
        return null;
    }

    /**
     * new ResourceMarket.
     *
     * @param edition edition of this session
     * @return null at the moment
     */
    @Override
    public ResourceMarket newResourceMarket(final Edition edition) {
        return null;
    }

    /**
     * new Board.
     *
     * @param edition edition of this session
     * @return new NeutralBoard
     */
    @Override
    public Board newBoard(final Edition edition) {
        return new NeutralBoard(edition);
    }

    /**
     * new Auction.
     *
     * @param plant   plant to be auctioned, not null
     * @param players players participating, not null
     *                order of players is their bidding order
     * @return null at the moment
     */
    @Override
    public Auction newAuction(Plant plant, List<Player> players) {
        return null;
    }

    /**
     * new Game.
     *
     * @param edition edition of the game
     * @return null at the moment
     */
    @Override
    public Game newGame(final Edition edition) {
        return null;
    }
}
