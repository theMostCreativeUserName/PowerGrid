package edu.hm.cs.rs.powergrid.datastore; public interface Plant {interface Type {}}
