package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Erste Tests fuer eine Rules-Implementierung.
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-30
 */

public class OperatePlantTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;

    /**
     * Fluchtwert fuer kein Geheimnis.
     */
    private final String NO_SECRET = "";

    /**
     * Fuehrt ein Runnable mehrmals aus.
     */
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    /**
     * Initialisiert Factory und Spielregeln.
     */
    public OperatePlantTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }

    @Test
    public void testOperatePlant() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 1);
    }

    @Test
    public void testOperatePlant2() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Hybrid, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Oil);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 2);
    }

    @Test
    public void testOperatePlant3() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        OpenPlant plant3 = factory.newPlant(202, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant3);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 2);
    }

    @Test
    public void testOperatePlant4() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        OpenPlant plant3 = factory.newPlant(202, Plant.Type.Oil, 2, 12);
        player.getOpenPlants().add(plant3);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Oil);
        player.getOpenResources().add(Resource.Oil);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 2);
    }

    @Test
    public void testOperateFire() {
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        plant.setOperated(false);
        OpenPlant plant3 = factory.newPlant(203, Plant.Type.Coal, 2, 12);
        plant3.setOperated(false);
        player.getOpenPlants().add(plant);
        player.getOpenPlants().add(plant3);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertTrue(problem.isEmpty());
        assertSame(player.getOpenResources().count(Resource.Coal), 3);
        assertSame(opengame.getResourceMarket().getOpenSupply().count(Resource.Coal), 2);

    }

    @Test
    public void testOperateFire2() {
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);

        //Player3
        OpenPlayer player3 = factory.newPlayer("Warum?", "Darum");
        player3.setPassed(true);
        opengame.getOpenPlayers().add(player3);
        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        player3.setPassed(false);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NotYourTurn);
    }

    @Test
    public void testOperateFire3() {
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        player.getOpenPlants().add(factory.newPlant(301, Plant.Type.Coal, 20 , 30));
        player.getOpenPlants().remove(plant);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NoPlants);
    }

    @Test
    public void testOperateFire5() {
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        plant.setOperated(true);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.PlantHasOperated);
    }

    @Test
    public void testOperateFire6() {
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        player.setPassed(true);
        player2.setPassed(true);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NotYourTurn);
    }

    @Test
    public void testOperateFire7() {
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenResources().add(Resource.Oil);
        player2.getOpenResources().add(Resource.Oil);
        player2.getOpenResources().add(Resource.Oil);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertTrue(plant.hasOperated());
    }

    @Test (expected = IllegalStateException.class)
    public void testOperateFireException() {
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantOperation);
        OpenFactory factory = opengame.getFactory();


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setPassed(false);
        OpenPlant plant = factory.newPlant(200, Plant.Type.Coal, 2, 12);
        player.getOpenPlants().add(plant);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);
        player.getOpenResources().add(Resource.Coal);


        //Player2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setPassed(false);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.OperatePlant).collect(Collectors.toList());
        HotMove move = (HotMove)moves.get(0);
        move.collect(opengame, Optional.of(factory.newPlayer("Irgendwas", "Mir egal")));
    }

}
