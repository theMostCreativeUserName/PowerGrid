package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.*;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

/**
 * Erste Tests fuer eine Rules-Implementierung.
 *
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-30
 */

public class EndAuctionsTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;

    /**
     * Fluchtwert fuer kein Geheimnis.
     */
    private final String NO_SECRET = "";

    /**
     * Fuehrt ein Runnable mehrmals aus.
     */
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    /**
     * Initialisiert Factory und Spielregeln.
     */
    public EndAuctionsTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }

    @Test
    public void TestEndAuctions() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantBuying);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(true);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player2.setPassed(true);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = List.of(player);
        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.EndAuctions).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 1);
    }

    @Test
    public void testEndAuctionsFireRound1AuctionNull() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantBuying);

        opengame.setRound(1);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(true);
        player.getOpenPlants().add(factory.newPlant(601, Plant.Type.Coal, 10, 10 ));

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(2);
        player2.setPassed(true);
        player2.getOpenPlants().add(factory.newPlant(602, Plant.Type.Coal, 10, 10 ));

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(true);
        player3.getOpenPlants().add(factory.newPlant(603, Plant.Type.Coal, 10, 10 ));

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        OpenPlant plant = factory.newPlant(805, Plant.Type.Oil, 10, 10);
        opengame.getPlantMarket().getOpenActual().add(plant);
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(801, Plant.Type.Oil, 10, 10));
        //Auction
        List<OpenPlayer> fakedPlayer = List.of(player3, player2, player);
        opengame.setAuction(null);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.EndAuctions).collect(Collectors.toList());
        Optional<Problem> problem = sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
      assertTrue(problem.isEmpty());
      assertFalse(player.hasPassed());
      assertFalse(player2.hasPassed());
      assertFalse(player3.hasPassed());
      assertSame(opengame.getPlantMarket().getOpenActual().size(), 1);
      assertTrue(opengame.getPlantMarket().getOpenActual().contains(plant));
      assertSame(opengame.getPhase(), Phase.ResourceBuying);
      assertSame(game.getAuction(), null);
      assertEquals(opengame.getOpenPlayers(), fakedPlayer);
    }

    @Test
    public void testEndAuctionsFireRoundNotOneAndAuctionNotNull() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantBuying);

        opengame.setRound(4);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(true);
        player.getOpenPlants().add(factory.newPlant(601, Plant.Type.Coal, 10, 10 ));

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(2);
        player2.setPassed(true);
        player2.getOpenPlants().add(factory.newPlant(602, Plant.Type.Coal, 10, 10 ));

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(true);
        player3.getOpenPlants().add(factory.newPlant(603, Plant.Type.Coal, 10, 10 ));

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        OpenPlant plant = factory.newPlant(805, Plant.Type.Oil, 10, 10);
        opengame.getPlantMarket().getOpenActual().add(plant);
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(801, Plant.Type.Oil, 10, 10));
        //Auction

        opengame.setAuction(factory.newAuction(plant, List.of(player, player2, player3)));


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.EndAuctions).collect(Collectors.toList());
        Optional<Problem> problem = sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertTrue(problem.isEmpty());
        assertEquals(opengame.getAuction(), null);

    }


    @Test(expected = IllegalStateException.class)
    public void testCloseAuctionException() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantBuying);

        opengame.setRound(4);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(true);
        player.getOpenPlants().add(factory.newPlant(601, Plant.Type.Coal, 10, 10 ));

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(2);
        player2.setPassed(true);
        player2.getOpenPlants().add(factory.newPlant(602, Plant.Type.Coal, 10, 10 ));

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(true);
        player3.getOpenPlants().add(factory.newPlant(603, Plant.Type.Coal, 10, 10 ));

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        OpenPlant plant = factory.newPlant(805, Plant.Type.Oil, 10, 10);
        opengame.getPlantMarket().getOpenActual().add(plant);
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(801, Plant.Type.Oil, 10, 10));
        //Auction

        opengame.setAuction(factory.newAuction(plant, List.of(player, player2, player3)));


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.EndAuctions).collect(Collectors.toList());
        HotMove move = (HotMove) moves.get(0);
        move.collect(opengame, Optional.of(factory.newPlayer("Irgendwas", "Mir egal")));
    }


}
