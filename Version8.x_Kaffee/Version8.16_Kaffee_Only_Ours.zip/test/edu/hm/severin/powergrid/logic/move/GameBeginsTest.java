package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import edu.hm.severin.powergrid.datastore.NeutralFactory;
import edu.hm.severin.powergrid.logic.StandardRules;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.lang.reflect.Constructor;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertTrue;

public class GameBeginsTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;
    private final NeutralFactory factory;

    public GameBeginsTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
        factory = new NeutralFactory();
    }

    public GameBegins getGameBegins() throws ReflectiveOperationException {
        OpenPlayer player = factory.newPlayer("blubiblubbyblub", "yayColors");
        Constructor<GameBegins> cTor = GameBegins.class
                .getDeclaredConstructor(OpenGame.class, OpenPlayer.class);
        cTor.setAccessible(true);
        return cTor.newInstance(game, player);
    }

    @Test
    public void notEnoughPlayers() {
        OpenGame openGame = (OpenGame) game;
        openGame.setPhase(Phase.Opening);
        OpenPlayer player = factory.newPlayer("very special secret", "red");
        openGame.getOpenPlayers().add(player);
        Set<Move> s = sut.getMoves(Optional.of("very special secret"));
        assertEquals(0, s.size());
    }

    @Test
    public void noPlayers() {
        OpenGame openGame = (OpenGame) game;
        openGame.setPhase(Phase.Opening);
        Set<Move> s = sut.getMoves(Optional.empty());
        assertEquals(1, s.size());
        assertEquals(MoveType.JoinPlayer, s.iterator().next().getType());
    }

    @Test
    public void notMinPlayers() {

        OpenGame openGame = (OpenGame) game;
        int min = openGame.getEdition().getPlayersMinimum();
        openGame.setPhase(Phase.Opening);
        OpenPlayer player = factory.newPlayer("very special secret", "red");
        OpenPlayer player2 = factory.newPlayer("help", "why?");
        openGame.getOpenPlayers().add(player);
        openGame.getOpenPlayers().add(player2);
        Set<Move> s = sut.getMoves(Optional.of("very special secret"));
        assertEquals(1, s.size());
        assertEquals(MoveType.CommenceGame, s.iterator().next().getType());
        assertFalse(s.iterator().next().hasPriority());
    }

    @Test
    public void maxPlayers() {

        OpenGame openGame = (OpenGame) game;
        int max = openGame.getEdition().getPlayersMaximum();
        for (int i = 0; i < max; i++) {
            OpenPlayer player = factory.newPlayer(i + "secret", i + "color");
            openGame.getOpenPlayers().add(player);
        }
        openGame.setPhase(Phase.Opening);
        Set<Move> s = sut.getMoves(Optional.of("1secret"));
        assertEquals(1, s.size());
        assertEquals(MoveType.CommenceGame, s.iterator().next().getType());
        assertTrue(s.iterator().next().hasPriority());

        sut.fire(Optional.of("1secret"), s.iterator().next());
        assertEquals(Phase.PlayerOrdering, openGame.getPhase());


    }

    @Test(expected = IllegalStateException.class)
    public void testNoGame() throws ReflectiveOperationException {

        GameBegins gameMove = getGameBegins();

        OpenPlayer player = factory.newPlayer("Most Secret Secret", "very interesting color");
        OpenPlayer player1 = factory.newPlayer("mmmm", "even more interesting color");
        OpenGame openGame = (OpenGame) game;
        openGame.getOpenPlayers().add(player);
        openGame.getOpenPlayers().add(player1);
        gameMove.collect(openGame, Optional.of(player));
    }

    @Test(expected = IllegalStateException.class)
    public void testSomePlayers() {
        OpenGame openGame = (OpenGame) game;
        OpenPlayer p1 = factory.newPlayer("secret1", "color1");
        OpenPlayer p2 = factory.newPlayer("secret2", "color2");
        OpenPlayer p3 = factory.newPlayer("secret3", "color3");
        openGame.getOpenPlayers().add(p1);
        openGame.getOpenPlayers().add(p2);
        openGame.getOpenPlayers().add(p3);
        openGame.setLevel(4);
        Set<Move> move = sut.getMoves(Optional.of("secret1"));
        sut.fire(Optional.of("secret1"), move.iterator().next());
        assertEquals(0, openGame.getLevel());
        assertEquals(1, openGame.getRound());
        assertEquals(50, p1.getElectro());
        assertEquals(50, p2.getElectro());
        assertEquals(50, p3.getElectro());
        assertEquals(null, openGame.getBoard().findCity("Leipzig"));
        assertTrue(openGame.getBoard().findCity("Berlin") != null);
        openGame.getBoard().close();
    }

    @Test
    public void testRunPlayerNotConatined() {
        OpenGame openGame = (OpenGame) game;
        OpenPlayer p1 = factory.newPlayer("secret1", "color1");
        OpenPlayer p2 = factory.newPlayer("secret2", "color2");
        OpenPlayer p3 = factory.newPlayer("secret3", "color3");
        openGame.getOpenPlayers().add(p1);
        openGame.getOpenPlayers().add(p2);
        Set<Move> move = sut.getMoves(Optional.of("secret3"));
        assertTrue(move.isEmpty());
    }

    @Test
    public void testRunPlayerNotConatined2() throws ReflectiveOperationException {
        OpenGame openGame = (OpenGame) game;
        OpenPlayer player = factory.newPlayer("blubiblubbyblub", "yayColors");
        // constructor
        Constructor<GameBegins> cTor = GameBegins.class
                .getDeclaredConstructor(OpenGame.class, OpenPlayer.class);
        cTor.setAccessible(true);
        GameBegins gb = cTor.newInstance(openGame, player);
        OpenPlayer p1 = factory.newPlayer("secret1", "color1");
        OpenPlayer p2 = factory.newPlayer("secret2", "color2");
        openGame.getOpenPlayers().add(p1);
        openGame.getOpenPlayers().add(p2);
        Optional<Problem> problem = gb.run(false);
        assertEquals(Problem.NotNow, problem.get());
    }

    @Test
    public void testAutofire() {
        class UsefulRules extends StandardRules {
            OpenGame g;

            public UsefulRules(OpenGame game) {
                super(game);
                this.g = game;
            }


            class VeryUsefulMove implements HotMove {
                final OpenGame game;

                public VeryUsefulMove(OpenGame game) {
                    this.game = game;
                }

                public VeryUsefulMove() {
                    this.game = null;
                }

                @Override
                public Optional<Problem> run(boolean real) {
                    game.setPhase(Phase.Terminated);
                    return Optional.empty();
                }

                @Override
                public OpenGame getGame() {
                    return game;
                }

                @Override
                public Set<HotMove> collect(OpenGame game, Optional<OpenPlayer> player) {


                    if (this.game != null)
                        throw new IllegalStateException("this is not a prototype");
                    final HotMove move = new VeryUsefulMove(game);
                    Set<HotMove> result;
                    result = Set.of(move);

                    return result;
                }

                @Override
                public MoveType getType() {
                    return MoveType.BuyNoResource;
                }
            }


            @Override
            public Set<Move> getPrototypes() {
                Set<Move> result = new HashSet<>();
                GameBegins gameB = new GameBegins();
                VeryUsefulMove useful = new VeryUsefulMove();
                result.add(gameB);
                result.add(useful);
                return result;
            }
        }

        OpenGame openGame = (OpenGame) game;
        openGame.setPhase(Phase.Opening);

        OpenPlayer p1 = factory.newPlayer("great", "at least");
        OpenPlayer p2 = factory.newPlayer("this", "works");
        openGame.getOpenPlayers().add(p1);
        openGame.getOpenPlayers().add(p2);

        UsefulRules rules = new UsefulRules(openGame);
        Set<Move> move = rules.getMoves(Optional.of("this"));
        Move gb = move.stream().filter(m -> m.getType() == MoveType.CommenceGame).findFirst().get();
        rules.fire(Optional.of("this"), gb);


        assertEquals(Phase.Terminated, openGame.getPhase());

    }

}
