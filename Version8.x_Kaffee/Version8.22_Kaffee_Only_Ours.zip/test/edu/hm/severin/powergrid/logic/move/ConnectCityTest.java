package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.*;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

/**
 * Erste Tests fuer eine Rules-Implementierung.
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-30
 */

public class ConnectCityTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;

    /**
     * Fluchtwert fuer kein Geheimnis.
     */
    private final String NO_SECRET = "";

    /**
     * Fuehrt ein Runnable mehrmals aus.
     */
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    /**
     * Initialisiert Factory und Spielregeln.
     */
    public ConnectCityTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }

    @Test
    public void testConnectCity() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city3.getOpenConnections().put(city, 5);
        city4.getOpenConnections().put(city, 5);

        city.getOpenConnections().put(city2, 5);
        city.getOpenConnections().put(city3, 5);
        city.getOpenConnections().put(city4, 5);
        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 3);
    }

    @Test
    public void testConnectCityProperties() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);


        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        Move move = moves.get(0);
        assertSame(move.getProperties().getProperty("type"), MoveType.ConnectCity.toString());
        assertSame(move.getProperties().getProperty("player"), player.getColor() );
        assertSame(move.getProperties().getProperty("city"), game.getBoard().findCity("Bis wir").getName() );
    }

    @Test
    public void testConnectCityFire() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        player3.setElectro(100);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player3);
        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertTrue(problem.isEmpty());
        assertTrue(player.getOpenCities().contains(city2));
        assertSame(player.getElectro(), 85);

    }

    @Test
    public void testConnectCityFire2() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        player3.setPassed(true);
        player.setPassed(true);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NotYourTurn);
    }

    @Test
    public void testConnectCityFire3() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        player.setPassed(true);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NotYourTurn);
    }

    @Test
    public void testConnectCityFire4() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        player.getOpenCities().add(city2);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.CityAlreadyConnected);
    }

    @Test
    public void testConnectCityFire5() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        player2.getOpenCities().add(city2);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.CityTaken);
    }

    @Test
    public void testConnectCityFire6() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        city.getOpenConnections().clear();
        city2.getOpenConnections().clear();
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NoCities);
    }

    @Test
    public void testConnectCityFire7() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        player.setElectro(1);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NoCash);
    }

    @Test
    public void testConnectCityFire8() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        player3.setElectro(666);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(15);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertTrue(problem.isEmpty());
        assertSame(player.getElectro(), 0);
        assertTrue(player.getOpenCities().contains(city2));
    }

    @Test
    public void testConnectCityFire9() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        OpenPlant plant3 = factory.newPlant(202, Plant.Type.Oil, 3, 12);
        player.getOpenPlants().add(plant3);
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        opengame.setPhase(Phase.ResourceBuying);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NotNow);
    }

    @Test
    public void testConnectCityFire10() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        OpenPlant plant3 = factory.newPlant(202, Plant.Type.Oil, 3, 12);
        player.getOpenPlants().add(plant3);
        player.getOpenCities().add(city);
        player.setElectro(100);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        player.getOpenCities().clear();
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));

        // assert
        assertSame(problem.get(), Problem.NoCities);
    }


    @Test (expected = IllegalStateException.class)
    public void testConnectCityFireException() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        //Städte und Board
        OpenCity city = factory.newCity("Ja-ne", 123);
        OpenCity city2 = factory.newCity("Bis wir", 123);
        OpenCity city3 = factory.newCity("in den ganzen ", 123);
        OpenCity city4 = factory.newCity("Städten ertrinken", 123);

        city2.getOpenConnections().put(city, 5);
        city.getOpenConnections().put(city2, 5);

        opengame.getBoard().getOpenCities().clear();
        opengame.getBoard().getOpenCities().add(city);
        opengame.getBoard().getOpenCities().add(city2);
        opengame.getBoard().getOpenCities().add(city3);
        opengame.getBoard().getOpenCities().add(city4);

        //Player3
        OpenPlayer player3 = factory.newPlayer("NOOOOOP", "Farbe");
        player3.setPassed(false);
        opengame.getOpenPlayers().add(player3);


        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(city);
        player.setElectro(15);
        player.setPassed(false);


        //Player 2
        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        OpenPlant plant2 = factory.newPlant(201, Plant.Type.Oil, 3, 12);
        player2.getOpenPlants().add(plant2);
        player2.setElectro(200);
        player2.setPassed(true);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.ConnectCity).collect(Collectors.toList());
        HotMove move = (HotMove)moves.get(0);
        move.collect(opengame, Optional.of(factory.newPlayer("Irgendwas", "Mir egal")));
    }
}
