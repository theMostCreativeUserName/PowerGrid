package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

/**
 * Erste Tests fuer eine Rules-Implementierung.
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-30
 */

public class StartAuctionTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;

    /**
     * Fluchtwert fuer kein Geheimnis.
     */
    private final String NO_SECRET = "";

    /**
     * Fuehrt ein Runnable mehrmals aus.
     */
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    /**
     * Initialisiert Factory und Spielregeln.
     */
    public StartAuctionTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }

    @Test
    public void testStartAuction() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(100);

        //Offener Markt
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(401, Plant.Type.Coal, 20, 20));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(402, Plant.Type.Coal, 20, 20));


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 2);
    }

    @Test
    public void testStartAuction2() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(401);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(100);

        //Offener Markt
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(401, Plant.Type.Coal, 20, 20));


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 1);
    }

    @Test
    public void testStartAuctionPrototypes() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(401);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(100);

        //Offener Markt
        OpenPlant plant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(plant);


        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        Move move = moves.get(0);
        assertSame(move.getProperties().getProperty("type"), MoveType.StartAuction.toString());
        assertSame(move.getProperties().getProperty("player"), player.getColor() );
        assertEquals(move.getProperties().getProperty("plant"), String.valueOf(plant.getNumber()));
    }

    @Test
    public void testStartAuctionFire() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        List<Player> fakePlayers = List.of(player2, player3, player);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert

        assertTrue(problem.isEmpty());
        assertSame(openPlant, game.getAuction().getPlant());
        assertEquals(openPlant.getNumber(), game.getAuction().getAmount());
        assertSame(player, game.getAuction().getPlayer());
        assertEquals(fakePlayers, game.getAuction().getPlayers());
        assertSame(game.getPhase(), Phase.PlantAuction);
    }

    @Test
    public void testStartAuctionFire2() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        List<Player> fakePlayers = List.of(player2, player3, player);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        opengame.setPhase(Phase.PlantOperation);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.NotNow);
    }

    @Test
    public void testStartAuctionFire3() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        List<Player> fakePlayers = List.of(player2, player3, player);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        opengame.getOpenPlayers().clear();
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.NotYourTurn);
    }

    @Test
    public void testStartAuctionFire4() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        List<Player> fakePlayers = List.of(player2, player3, player);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        player.setPassed(true);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.NotYourTurn);
    }

    @Test
    public void testStartAuctionFire5() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        List<Player> fakePlayers = List.of(player2, player3, player);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        opengame.getPlantMarket().getOpenActual().clear();
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.PlantNotAvailable);
    }

    @Test
    public void testStartAuctionFire6() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        List<Player> fakePlayers = List.of(player2, player3, player);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        player.setElectro(10);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.NoCash);
    }

    @Test
    public void testStartAuctionFire7() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(true);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        List<Player> fakePlayers = List.of(player3, player2);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Nooo"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Nooo"), moves.get(0));
        // assert
        assertTrue(problem.isEmpty());
        assertEquals(fakePlayers, game.getAuction().getPlayers());

    }

    @Test (expected = IllegalStateException.class)
    public void testStartAuctionFireException() {
        //Game
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.PlantBuying);
        OpenFactory factory = opengame.getFactory();

        //Player1
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.getOpenCities().add(factory.newCity("Testhausen", 666));
        player.setPassed(false);
        player.setElectro(500);

        //Player2
        OpenPlayer player2 = factory.newPlayer("Nooo", "bulb");
        player2.setPassed(false);
        player2.setElectro(500);

        //Player2
        OpenPlayer player3 = factory.newPlayer("BU", "gelb");
        player3.setPassed(false);
        player3.setElectro(500);

        //Offener Markt
        OpenPlant openPlant = factory.newPlant(401, Plant.Type.Coal, 20, 20);
        opengame.getPlantMarket().getOpenActual().add(openPlant);



        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.StartAuction).collect(Collectors.toList());
        HotMove move = (HotMove)moves.get(0);
        move.collect(opengame, Optional.of(player));
    }
}
