package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import edu.hm.severin.powergrid.datastore.NeutralFactory;
import edu.hm.severin.powergrid.logic.StandardRules;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.lang.reflect.Constructor;
import java.util.*;
import java.util.stream.Collectors;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.*;

public class GameBeginsTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;
    private final NeutralFactory factory;

    public GameBeginsTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        System.setProperty("powergrid.randomsource", "edu.hm.severin.powergrid.logic.SortingRandom");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
        factory = new NeutralFactory();
    }

    public GameBegins getGameBegins() throws ReflectiveOperationException {
        OpenPlayer player = factory.newPlayer("blubiblubbyblub", "yayColors");
        Constructor<GameBegins> cTor = GameBegins.class
                .getDeclaredConstructor(OpenGame.class, OpenPlayer.class);
        cTor.setAccessible(true);
        return cTor.newInstance(game, player);
    }

    @Test
    public void notEnoughPlayers() {
        OpenGame openGame = (OpenGame) game;
        openGame.setPhase(Phase.Opening);
        OpenPlayer player = factory.newPlayer("very special secret", "red");
        openGame.getOpenPlayers().add(player);
        Set<Move> s = sut.getMoves(Optional.of("very special secret"));
        assertEquals(0, s.size());
    }

    @Test
    public void noPlayers() {
        OpenGame openGame = (OpenGame) game;
        openGame.setPhase(Phase.Opening);
        Set<Move> s = sut.getMoves(Optional.empty());
        assertEquals(1, s.size());
        assertEquals(MoveType.JoinPlayer, s.iterator().next().getType());
    }

    @Test
    public void notMinPlayers() {

        OpenGame openGame = (OpenGame) game;
        int min = openGame.getEdition().getPlayersMinimum();
        openGame.setPhase(Phase.Opening);
        OpenPlayer player = factory.newPlayer("very special secret", "red");
        OpenPlayer player2 = factory.newPlayer("help", "why?");
        openGame.getOpenPlayers().add(player);
        openGame.getOpenPlayers().add(player2);
        Set<Move> s = sut.getMoves(Optional.of("very special secret"));
        assertEquals(1, s.size());
        assertEquals(MoveType.CommenceGame, s.iterator().next().getType());
        assertFalse(s.iterator().next().hasPriority());
    }

    @Test
    public void maxPlayers() {

        OpenGame openGame = (OpenGame) game;
        int max = openGame.getEdition().getPlayersMaximum();
        for (int i = 0; i < max; i++) {
            OpenPlayer player = factory.newPlayer(i + "secret", i + "color");
            openGame.getOpenPlayers().add(player);
        }
        openGame.setPhase(Phase.Opening);
        Set<Move> s = sut.getMoves(Optional.of("1secret"));
        assertEquals(1, s.size());
        assertEquals(MoveType.CommenceGame, s.iterator().next().getType());
        assertTrue(s.iterator().next().hasPriority());

        sut.fire(Optional.of("1secret"), s.iterator().next());
        assertEquals(Phase.PlantBuying, openGame.getPhase());


    }

    @Test(expected = IllegalStateException.class)
    public void testNoGame() throws ReflectiveOperationException {

        GameBegins gameMove = getGameBegins();

        OpenPlayer player = factory.newPlayer("Most Secret Secret", "very interesting color");
        OpenPlayer player1 = factory.newPlayer("mmmm", "even more interesting color");
        OpenGame openGame = (OpenGame) game;
        openGame.getOpenPlayers().add(player);
        openGame.getOpenPlayers().add(player1);
        gameMove.collect(openGame, Optional.of(player));
    }

    @Test(expected = IllegalStateException.class)
    public void testSomePlayers() {
        OpenGame openGame = (OpenGame) game;
        OpenPlayer p1 = factory.newPlayer("secret1", "color1");
        OpenPlayer p2 = factory.newPlayer("secret2", "color2");
        OpenPlayer p3 = factory.newPlayer("secret3", "color3");
        openGame.getOpenPlayers().add(p1);
        openGame.getOpenPlayers().add(p2);
        openGame.getOpenPlayers().add(p3);
        openGame.setLevel(4);
        Set<Move> move = sut.getMoves(Optional.of("secret1"));
        sut.fire(Optional.of("secret1"), move.iterator().next());
        assertEquals(0, openGame.getLevel());
        assertEquals(1, openGame.getRound());
        assertEquals(50, p1.getElectro());
        assertEquals(50, p2.getElectro());
        assertEquals(50, p3.getElectro());
        assertEquals(null, openGame.getBoard().findCity("Leipzig"));
        assertTrue(openGame.getBoard().findCity("Berlin") != null);
        openGame.getBoard().close();
    }

    @Test
    public void testRunPlayerNotConatined() {
        OpenGame openGame = (OpenGame) game;
        OpenPlayer p1 = factory.newPlayer("secret1", "color1");
        OpenPlayer p2 = factory.newPlayer("secret2", "color2");
        OpenPlayer p3 = factory.newPlayer("secret3", "color3");
        openGame.getOpenPlayers().add(p1);
        openGame.getOpenPlayers().add(p2);
        Set<Move> move = sut.getMoves(Optional.of("secret3"));
        assertTrue(move.isEmpty());
    }

    @Test
    public void testRunPlayerNotConatined2() throws ReflectiveOperationException {
        OpenGame openGame = (OpenGame) game;
        OpenPlayer player = factory.newPlayer("blubiblubbyblub", "yayColors");
        // constructor
        Constructor<GameBegins> cTor = GameBegins.class
                .getDeclaredConstructor(OpenGame.class, OpenPlayer.class);
        cTor.setAccessible(true);
        GameBegins gb = cTor.newInstance(openGame, player);
        OpenPlayer p1 = factory.newPlayer("secret1", "color1");
        OpenPlayer p2 = factory.newPlayer("secret2", "color2");
        openGame.getOpenPlayers().add(p1);
        openGame.getOpenPlayers().add(p2);
        Optional<Problem> problem = gb.run(false);
        assertEquals(Problem.NotYourTurn, problem.get());
    }

    @Test
    public void GameBeginsFire() {
        //Grundzeug
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();

        //Game
        opengame.setPhase(Phase.Opening);
        opengame.getOpenPlayers().add(factory.newPlayer("Nein", "Noop"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal", "Immer noch nicht"));

        OpenPlant plant = factory.newPlant(2, Plant.Type.Coal, 2, 2);
        opengame.getPlantMarket().getOpenHidden().add(0, plant);

        //Orginale PlantMarketlist
        int i = 0;
        List<OpenPlant> allplants = new ArrayList<>();
        while (i < 11) {
            OpenPlant ii = opengame.getPlantMarket().findPlant(i);
            if (ii != null) {
                allplants.add(ii);
            }
            i++;
        }
        OpenPlant randomPlant = opengame.getPlantMarket().findPlant(20);
        opengame.getPlantMarket().getOpenHidden().add(3,randomPlant);
        OpenPlant plant13 = opengame.getPlantMarket().findPlant(13);
        opengame.getPlantMarket().removePlant(13);
        opengame.getPlantMarket().getOpenHidden().add(16, plant13);




        final Set<Move> haveMove = sut.getMoves(Optional.of("Nein"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CommenceGame).collect(Collectors.toList());
        Optional<Problem> problem = sut.fire(Optional.of("Hihi"), moves.get(0));

        assertTrue(problem.isEmpty());
        assertTrue(opengame.getPlantMarket().getOpenActual().contains(allplants.get(0)));
        assertTrue(opengame.getPlantMarket().getOpenActual().contains(allplants.get(1)));
        assertTrue(opengame.getPlantMarket().getOpenActual().contains(allplants.get(2)));
        assertTrue(opengame.getPlantMarket().getOpenActual().contains(allplants.get(3)));
        assertFalse(opengame.getPlantMarket().getOpenActual().contains(allplants.get(4)));
        assertTrue(opengame.getPlantMarket().getOpenFuture().contains(allplants.get(4)));
        assertTrue(opengame.getPlantMarket().getOpenFuture().contains(allplants.get(5)));
        assertTrue(opengame.getPlantMarket().getOpenFuture().contains(allplants.get(6)));
        assertTrue(opengame.getPlantMarket().getOpenFuture().contains(allplants.get(7)));
        assertFalse(opengame.getPlantMarket().getOpenFuture().contains(allplants.get(8)));
        assertEquals(opengame.getPlantMarket().getOpenHidden().get(0), plant13);
        assertSame(opengame.getPlantMarket().getOpenActual().size(), 4);
        assertSame(opengame.getPlantMarket().getOpenFuture().size(), 4);
        assertEquals(opengame.getPlantMarket().getOpenHidden().get(1).getNumber(), 19);
        assertEquals(opengame.getPlantMarket().getOpenHidden().get(2).getNumber(), 20);
    }

    @Test
    public void GameBeginsPrototypes() {
        //Grundzeug
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();

        //Game
        opengame.setPhase(Phase.Opening);
        OpenPlayer player = factory.newPlayer("Nein", "Noop");
        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal", "Immer noch nicht"));

        OpenPlant plant = factory.newPlant(2, Plant.Type.Coal, 2, 2);
        opengame.getPlantMarket().getOpenHidden().add(0, plant);

        //Orginale PlantMarketlist
        int i = 0;
        List<OpenPlant> allplants = new ArrayList<>();
        while (i < 11) {
            OpenPlant ii = opengame.getPlantMarket().findPlant(i);
            if (ii != null) {
                allplants.add(ii);
            }
            i++;
        }
        OpenPlant randomPlant = opengame.getPlantMarket().findPlant(20);
        opengame.getPlantMarket().getOpenHidden().add(3,randomPlant);
        OpenPlant plant13 = opengame.getPlantMarket().findPlant(13);
        opengame.getPlantMarket().removePlant(13);
        opengame.getPlantMarket().getOpenHidden().add(16, plant13);




        final Set<Move> haveMove = sut.getMoves(Optional.of("Nein"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CommenceGame).collect(Collectors.toList());
        Move move = moves.get(0);
        assertSame(move.getProperties().getProperty("type"), MoveType.CommenceGame.toString());
        assertSame(move.getProperties().getProperty("player"), player.getColor() );
    }

    // x.18
    @Test
    public void GameBeginsFire2(){
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();

        //Game
        opengame.setPhase(Phase.Opening);
        opengame.getOpenPlayers().add(factory.newPlayer("Nein", "Noop"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal", "Immer noch nicht"));


        final Set<Move> haveMove = sut.getMoves(Optional.of("Nein"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CommenceGame).collect(Collectors.toList());
        assertFalse(moves.get(0).hasPriority());
    }

    @Test
    public void GameBeginsGetTypePrototype(){
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();

        assertFalse(new GameBegins().hasPriority());
    }

    @Test
    public void GameBeginsGetTypePrototype2(){
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();

        opengame.setPhase(Phase.Opening);
        opengame.getOpenPlayers().add(factory.newPlayer("Nein", "Noop"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal2", "Immer noch nicht2"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal3", "Immer noch nicht3"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal4", "Immer noch nicht4"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal5", "Immer noch nicht5"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal6", "Immer noch nicht6"));

        assertFalse(new GameBegins().hasPriority());
    }

    @Test
    public void GameBeginsFire3(){
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();

        opengame.setPhase(Phase.Opening);
        opengame.getOpenPlayers().add(factory.newPlayer("Nein", "Noop"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal2", "Immer noch nicht2"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal3", "Immer noch nicht3"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal4", "Immer noch nicht4"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal5", "Immer noch nicht5"));
        opengame.getOpenPlayers().add(factory.newPlayer("Mir egal6", "Immer noch nicht6"));

        final Set<Move> haveMove = sut.getMoves(Optional.of("Nein"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CommenceGame).collect(Collectors.toList());
        assertTrue(moves.get(0).hasPriority());
    }

}
