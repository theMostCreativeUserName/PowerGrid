package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.logic.Move;

import java.util.Properties;

/**
 * Class for moves, implements all methods for Properties.
 */
public abstract class AbstractProperties implements Move {
    /**
     * Properties for the move.
     */
    private final Properties properties = new Properties();

    @Override
    public Properties getProperties() {
        return properties;
    }

    /**
     * set the property in the properties.
     * @param name key for the properties
     * @param value value for the key
     */
    public void setProperty(String name, String value) {
        properties.setProperty(name, value);
    }
}
