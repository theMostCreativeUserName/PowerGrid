package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.*;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

/**
 * Erste Tests fuer eine Rules-Implementierung.
 *
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-30
 */

public class CloseAuctionTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;

    /**
     * Fluchtwert fuer kein Geheimnis.
     */
    private final String NO_SECRET = "";

    /**
     * Fuehrt ein Runnable mehrmals aus.
     */
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    /**
     * Initialisiert Factory und Spielregeln.
     */
    public CloseAuctionTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }

    @Test
    public void testCloseAuction() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player2.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = List.of(player);
        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.CloseAuction).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 1);
    }

    @Test
    public void testCloseAuctionProperties() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player2.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = List.of(player);
        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.CloseAuction).collect(Collectors.toList());
        Move move = moves.get(0);
        // assert
        assertSame(move.getProperties().getProperty("type"), MoveType.CloseAuction.toString());
        assertEquals("CloseAuction{}",move.toString());
    }

    @Test
    public void testCloseAuctionFire() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(2);
        player2.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);


        OpenPlant plant = factory.newPlant(400, Plant.Type.Coal, 2, 3);
        opengame.getPlantMarket().getOpenActual().add(plant);
        OpenAuction auction = factory.newAuction(plant, players);
        auction.setPlayer(player);
        auction.setAmount(150);
        opengame.setAuction(auction);

        player2.getOpenPlants().add(factory.newPlant(555, Plant.Type.Coal, 10 , 10));


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CloseAuction).collect(Collectors.toList());
        Optional<Problem> problem = sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertTrue(problem.isEmpty());
        assertFalse(opengame.getPlantMarket().getOpenActual().contains(plant));
        assertSame(50, player.getElectro());
        assertTrue(player.hasPassed());
        assertSame(Phase.PlantBuying, opengame.getPhase());
        assertTrue(player.getOpenPlants().contains(plant));
    }

    @Test
    public void testCloseAuctionFire2() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player2.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);


        OpenPlant plant = factory.newPlant(400, Plant.Type.Coal, 2, 3);
        opengame.getPlantMarket().getOpenActual().add(plant);
        OpenAuction auction = factory.newAuction(plant, players);
        auction.setPlayer(player);
        auction.setAmount(150);
        opengame.setAuction(auction);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CloseAuction).collect(Collectors.toList());
        auction.getOpenPlayers().add(player2);
        Optional<Problem> problem = sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.AuctionRunning);
    }

    @Test
    public void testCloseAuctionFire3() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(2000);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.getOpenPlants().add(factory.newPlant(888, Plant.Type.Oil, 10, 10));
        player2.setElectro(2000);
        player2.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(2000);
        player3.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);


        OpenPlant plant = factory.newPlant(400, Plant.Type.Coal, 2, 3);
        opengame.getPlantMarket().getOpenActual().add(plant);
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(501, Plant.Type.Oil, 15, 20));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(503, Plant.Type.Oil, 15, 20));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(504, Plant.Type.Oil, 15, 20));
        OpenAuction auction = factory.newAuction(plant, players);
        auction.setPlayer(player);
        auction.setAmount(150);
        opengame.setAuction(auction);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CloseAuction).collect(Collectors.toList());
        Optional<Problem> problem = sut.fire(Optional.of("Hihi"), moves.get(0));

        final Set<Move> haveMove2 = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves2 = haveMove2.stream().filter(Move -> Move.getType() == MoveType.CloseAuction).collect(Collectors.toList());
        // assert
        assertTrue(problem.isEmpty());
        assertTrue(player.hasPassed());
        assertSame(moves2.size(), 0);
    }

    @Test(expected = IllegalStateException.class)
    public void testCloseAuctionException() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);


        OpenPlant plant = factory.newPlant(400, Plant.Type.Coal, 2, 3);
        opengame.getPlantMarket().getOpenActual().add(plant);
        OpenAuction auction = factory.newAuction(plant, players);
        auction.setPlayer(player);
        auction.setAmount(150);
        opengame.setAuction(auction);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.CloseAuction).collect(Collectors.toList());
        HotMove move = (HotMove) moves.get(0);
        move.collect(opengame, Optional.of(factory.newPlayer("Irgendwas", "Mir egal")));
    }


}
