package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;


import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * refills resourceMarket and starts a new turn.
 *
 * @author Pietsch
 */
class TurnOver extends AbstractProperties implements HotMove {

    /**
     * Prototype Constructor.
     */
    TurnOver() {
        super(MoveType.TurnOver, null);
    }

    /**
     * Non-Prototype Constructor.
     *
     * @param game this game.
     */
    private TurnOver(OpenGame game) {
        super(MoveType.TurnOver, game);
    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (getGame().getPhase() != Phase.Bureaucracy)
            return Optional.of(Problem.NotNow);

        if (real) {
            editResourceMarket();
            editPlantMarket();
            final int currentRound = getGame().getRound();
            getGame().setRound(currentRound + 1);
            getGame().setPhase(Phase.PlayerOrdering);
        }
        setProperty("type", getType().toString());
        return Optional.empty();
    }

    /**
     * Doing all editing work for PlantMarket.
     */
    private void editPlantMarket() {
        final List<Integer> allNumbers = getGame().getPlantMarket()
                .getOpenActual()
                .stream()
                .map(OpenPlant::getNumber)
                .collect(Collectors.toList());
        if (getGame().getLevel() == 2) {
            final Optional<Integer> smallestNumber = allNumbers.stream().min(Integer::compareTo);
            smallestNumber.ifPresent(integer -> getGame().getPlantMarket().removePlant(integer));

        } else {
            final Optional<Integer> biggestNumber = getGame().getPlantMarket().getOpenFuture().stream().map(Plant::getNumber).max(Integer::compareTo);
            if (biggestNumber.isPresent()) {
                final OpenPlant plant = getGame().getPlantMarket().findPlant(biggestNumber.get());
                getGame().getPlantMarket().removePlant(biggestNumber.get());
                getGame().getPlantMarket().getOpenHidden().add(plant);
            }
        }
    }

    /**
     * Doing all editing work for ResourceMarket.
     */
    private void editResourceMarket() {
        final Bag<Resource> available = getGame().getResourceMarket().getOpenAvailable();
        final Bag<Resource> supply = getGame().getResourceMarket().getOpenSupply();
        final Map<Resource, List<List<Integer>>> resourceSupply = getGame().getEdition().getResourcePlayersToSupply();
        for (Map.Entry<Resource, List<List<Integer>>> resource : resourceSupply.entrySet()) {
            final List<List<Integer>> list = resource.getValue();
            final int amount = list.get(getGame().getOpenPlayers().size()).get(getGame().getLevel());
            for (int editAmount = 0; editAmount < amount; editAmount++) {
                if (supply.count(resource.getKey()) > 0)
                    available.add(resource.getKey());
                supply.remove(resource.getKey());
            }
        }
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> player) {
        final HotMove move = new TurnOver(openGame);
        return collectSpecificMove(move);
    }
}
