package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Class for moves, implements all methods for Properties.
 */
public abstract class AbstractProperties extends HotMoves implements Move {

    /**
     * Properties for the move.
     */
    private final Properties properties = new Properties();

    /**
     * MoveType of Move.
     */
    private final MoveType moveType;

    /**
     * Game of the move.
     */
    private final OpenGame game;

    /**
     * Constructor of abstract class.
     * @param moveType moveType of the concrete move
     * @param game game of the concrete game
     */
    public AbstractProperties(MoveType moveType, OpenGame game) {
        this.game = game;
        this.moveType = moveType;
    }


    @Override
    public Properties getProperties() {
        return properties;
    }

    /**
     * set the property in the properties.
     *
     * @param name  key for the properties
     * @param value value for the key
     */
    public void setProperty(String name, String value) {
        properties.setProperty(name, value);
    }

    /**
     * Getter for Type of Move.
     *
     * @return MoveType of Move
     */
    public MoveType getType() {
        return moveType;
    }

    /**
     * Getter for game.
     *
     * @return opengame from Move
     */
    public OpenGame getGame() {
        return Objects.requireNonNull(game);
    }

    OpenGame getGameCollect(){
        return game;
    }

    /**
     * proves the Phase of the game.
     * checks if player is last or first, of the not-yet passed players.
     *
     * @param phase            Phase game should be in
     * @param player           player to fire the move
     * @param lastPlayerWanted true, if last player is wanted
     *                         false, if first player is wanted
     * @return optional problem
     */
    Optional<Problem> phaseAndPlayer(Phase phase, OpenPlayer player, boolean lastPlayerWanted) {
        if (game.getPhase() != phase)
            return Optional.of(Problem.NotNow);
        final List<OpenPlayer> allRemainingPlayer = game.getOpenPlayers().stream()
                .filter(openPlayer -> !openPlayer.hasPassed())
                .sequential()
                .collect(Collectors.toList());
        if (allRemainingPlayer.isEmpty())
            return Optional.of(Problem.NotYourTurn);

        final OpenPlayer playerOfList;
        if (lastPlayerWanted) {
            playerOfList = allRemainingPlayer.get(allRemainingPlayer.size() - 1);
        } else {
            playerOfList = allRemainingPlayer.get(0);
        }
        if (!playerOfList.equals(player))
            return Optional.of(Problem.NotYourTurn);
        return Optional.empty();
    }

    /**
     * proves if phase is correct and all players passed.
     *
     * @param phase Phase of this game
     * @return optional problem
     */
    Optional<Problem> phaseAndAllPlayerPassed(Phase phase) {
        if (game.getPhase() != phase)
            return Optional.of(Problem.NotNow);
        final List<Boolean> playersNotPassed = game.getOpenPlayers().stream()
                .map(Player::hasPassed)
                .collect(Collectors.toList());
        if (playersNotPassed.contains(false))
            return Optional.of(Problem.PlayersRemaining);
        return Optional.empty();
    }

    /**
     * collects a specific, simple move.
     *
     * @param move Move to be collected
     * @return if no problems occurred, Set with the move
     * else empty Set
     */
    Set<HotMove> collectSpecificMove(HotMove move) {
        if (this.game != null)
            throw new IllegalStateException("this is not a prototype");
        //final HotMove move = new BuyNoResource(openGame, openPlayer);
        Set<HotMove> result;
        if (move.run(false).isEmpty())
            result = Set.of(move);
        else
            result = Set.of();
        return result;
    }

    @Override
    public String toString() {
        return asText();
    }
}
