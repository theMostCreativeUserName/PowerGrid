package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.RandomSource;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;


import java.util.List;
import java.util.Set;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * orders players.
 *
 * @author Severin
 */
public class OrderPlayers extends AbstractProperties implements HotMove {

    OrderPlayers() {
        super(MoveType.OrderPlayers, null);
    }

    private OrderPlayers(OpenGame game) {
        super(MoveType.OrderPlayers, game);
    }

    /**
     * sorts the list of players.
     *
     * @param real false, um den Zug nur zu testen (keine Aenderung am Datastore) oder
     *             true, um ihn wirklich auszufueheren (aender das Datastore).
     */
    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (getGame().getPhase() != Phase.PlayerOrdering) return Optional.of(Problem.NotNow);
        if (real) {
            // none has plants
            final List<OpenPlayer> players = getGame().getOpenPlayers();
            final int playersPlantNumber = players.stream()
                    .mapToInt(openPlayer -> openPlayer.getOpenPlants().size()).sum();

            if (playersPlantNumber == 0) {
                RandomSource.make().shufflePlayers(players);
                //order players
            } else {
                final List<OpenPlayer> list = players
                        .stream()
                        .sorted(OpenPlayer::compareTo)
                        .collect(Collectors.toList());

                getGame().getOpenPlayers().clear();
                getGame().getOpenPlayers().addAll(list);
                getGame().getOpenPlayers().forEach(openPlayer -> openPlayer.setPassed(false));

            }
            getGame().setPhase(Phase.PlantBuying);
        }
        setProperty("type", getType().toString());
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> player) {
        final HotMove move = new OrderPlayers(openGame);
        return collectSpecificMove(move);
    }
}
