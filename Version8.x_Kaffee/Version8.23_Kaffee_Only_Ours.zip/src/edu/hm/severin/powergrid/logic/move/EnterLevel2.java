package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * enter level 2.
 */
public class EnterLevel2 extends AbstractProperties implements HotMove {

    /**
     * Prototype Constructor.
     */
    EnterLevel2() {
        super(MoveType.EnterLevel2, null);
    }

    /**
     * Non-Prototype Constructor.
     * @param game this game
     */
    private EnterLevel2(OpenGame game) {
        super(MoveType.EnterLevel2, game);
    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (getGame().getPhase() != Phase.Bureaucracy)
            return Optional.of(Problem.NotNow);
        if (getGame().getLevel() != 0)
            return Optional.of(Problem.WrongLevel);

        final Integer highestAmountOfCities = getGame().getOpenPlayers().stream().map(openPlayer -> openPlayer.getOpenCities().size()).max(Integer::compare).get();
        final int neededCities = getGame().getEdition().getPlayersLevel2Cities().get(getGame().getOpenPlayers().size());
        if (highestAmountOfCities < neededCities)
            return Optional.of(Problem.NoCities);

        if (real) {
            getGame().setLevel(1);
            final int numberOfSmallestPlant = getGame().getPlantMarket().getOpenActual().stream().map(Plant::getNumber).min(Integer::compareTo).get();
            getGame().getPlantMarket().removePlant(numberOfSmallestPlant);
        }
        setProperty("type", getType().toString());
        return Optional.empty();
    }

    /**
     * collects if move could be run.
     *
     * @param openGame actual game
     * @param player  actual player
     * @return this move, if it could be run
     */
    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> player) {

        final HotMove move = new EnterLevel2(openGame);
        return collectSpecificMove(move);
    }
}
