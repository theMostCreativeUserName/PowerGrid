package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.RandomSource;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * starts the game.
 *
 * @author Auerbach
 */
class GameBegins extends AbstractProperties implements HotMove {

    /**
     * the player of this move.
     **/
    private final OpenPlayer player;

    /**
     * Prototype-Ctor.
     */
    GameBegins() {
        super(MoveType.CommenceGame, null);
        player = null;
    }

    /**
     * Non-Prototype-Ctor.
     *
     * @param game   game for the move
     * @param player player for the move
     */
    GameBegins(OpenGame game, OpenPlayer player) {
        super(MoveType.CommenceGame, game);
        this.player = player;
    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (getGame().getPhase() != Phase.Opening) return Optional.of(Problem.NotNow);

        if (!getGame().getOpenPlayers().contains(player)) return Optional.of(Problem.NotYourTurn);
        if (getGame().getPlayers().size() < getGame().getEdition().getPlayersMinimum()) return Optional.of(Problem.TooFewPlayers);

        if (real) {
            getGame().setLevel(0);
            getGame().setRound(1);
            getGame().setPhase(Phase.PlayerOrdering);

            initPlantMarket();
            getGame().getBoard().closeRegions(getGame().getEdition().getRegionsUsed().get(getGame().getOpenPlayers().size()));
            getGame().getOpenPlayers()
                    .forEach(openPlayer -> openPlayer.setElectro(getGame().getEdition().getInitialElectro()));
            getGame().getBoard().close();
        }
        setProperty("type", getType().toString());
        setProperty("player", player.getColor());
        return Optional.empty();
    }

    /**
     * initializes Plant Market.
     */
    public void initPlantMarket() {
        final int minNumberPlant = getGame().getPlantMarket().getOpenHidden().get(0).getNumber();
        int currentPlantNumber = minNumberPlant;
        final int actualSize = getGame().getEdition().getActualPlants(getGame().getLevel());

        while (currentPlantNumber < minNumberPlant + actualSize){
            final OpenPlant plant = getGame().getPlantMarket().findPlant(currentPlantNumber);
            getGame().getPlantMarket().removePlant(currentPlantNumber);
            getGame().getPlantMarket().getOpenActual().add(plant);
            currentPlantNumber++;
        }
        final int totalSize = getGame().getEdition().getFuturePlants(getGame().getLevel()) + currentPlantNumber;

        while (currentPlantNumber < totalSize) {
            final OpenPlant plant = getGame().getPlantMarket().findPlant(currentPlantNumber);
            getGame().getPlantMarket().removePlant(currentPlantNumber);
            getGame().getPlantMarket().getOpenFuture().add(plant);
            currentPlantNumber++;
        }
        final OpenPlant plant13 = getGame().getPlantMarket().findPlant(13);
        getGame().getPlantMarket().getOpenHidden().remove(plant13);

        // remove plants from hidden, predefined by rules, and mix
        RandomSource.make().shufflePlants(getGame().getPlantMarket().getOpenHidden());
        final List<OpenPlant> plantsToRemove = getGame().getPlantMarket().getOpenHidden()
                .subList(0, getGame().getEdition().getPlayersPlantsInitiallyRemoved().get(getGame().getOpenPlayers().size()));
        getGame().getPlantMarket().getOpenHidden().removeAll(plantsToRemove);

        //add plant 13 on top of hidden
        getGame().getPlantMarket().getOpenHidden().add(0, plant13);

        // Level 3 under hidden
        final OpenPlant level3 = getGame().getFactory().newPlant(0, Plant.Type.Level3, 1, 1);
        getGame().getPlantMarket().getOpenHidden().add(level3);
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {

        final HotMove move = new GameBegins(openGame, openPlayer.get());
        return collectSpecificMove(move);
    }

    @Override
    public boolean hasPriority() {
        boolean priority = false;
        if (getGameCollect() != null && getGame().getEdition().getPlayersMaximum() == getGame().getOpenPlayers().size()){
            priority = true;}

        return priority;
    }
}
