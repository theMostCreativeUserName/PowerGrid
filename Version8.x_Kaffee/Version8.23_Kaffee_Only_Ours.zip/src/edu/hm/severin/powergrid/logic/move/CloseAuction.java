package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.Optional;
import java.util.Set;

/**
 * close auction and sell plant to the highest bidder.
 *
 * @author Auerbach
 */
public class CloseAuction extends AbstractProperties implements HotMove {

    /**
     * constructor of prototype.
     */
    CloseAuction(){
        super(MoveType.CloseAuction, null);
    }

    /**
     * constructor of non-prototype.
     * @param openGame game of the move
     */
    private CloseAuction(OpenGame openGame){
        super(MoveType.CloseAuction, openGame);
    }

    @Override
    public Optional<Problem> run(boolean real) {

        if (getGame().getPhase() != Phase.PlantAuction)
            return Optional.of(Problem.NotNow);
        if(getGame().getAuction().getOpenPlayers().size()>1)
            return Optional.of(Problem.AuctionRunning);
        if(real){
            final OpenPlant plant = getGame().getAuction().getPlant();
            getGame().getPlantMarket().getOpenActual().remove(plant);
            getGame().getAuction().getPlayer().getOpenPlants().add(plant);
            final int newAmountElectro = getGame().getAuction().getPlayer().getElectro()-getGame().getAuction().getAmount();
            getGame().getAuction().getPlayer().setElectro(newAmountElectro);
            getGame().getAuction().getPlayer().setPassed(true);
            getGame().setPhase(Phase.PlantBuying);
        }
        setProperty("type", getType().toString());
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> player) {
        final HotMove move = new CloseAuction(openGame);
        return collectSpecificMove(move);
    }
}
