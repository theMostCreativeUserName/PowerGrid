package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;


/**
 * player connects cities and end their turn.
 * @author Pietsch
 */
class EndBuilding extends AbstractProperties implements HotMove {

    /**
     * Prototype Constructor.
     */
   EndBuilding() {
       super(MoveType.EndBuilding, null);
   }

    /**
     * Non-Prototype Constructor.
     * @param game this game
     */
   private EndBuilding(OpenGame game) {
       super(MoveType.EndBuilding, game);
   }

   @Override
   public Optional<Problem> run(boolean real) {
       Objects.requireNonNull(getGame());

       if(phaseAndAllPlayerPassed(Phase.Building).isPresent())
           return phaseAndAllPlayerPassed(Phase.Building);

       if (real) {
           final List<OpenPlayer> players = getGame().getOpenPlayers();
           getGame().setPhase(Phase.PlantOperation);
           players.forEach(openPlayer -> openPlayer.setPassed(false));
       }
       setProperty("type", getType().toString());
       return Optional.empty();
   }

   @Override
   public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> player) {
       final HotMove move = new EndBuilding(openGame);
       return collectSpecificMove(move);
   }
}
