package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenCity;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * a player builds their first city.
 *
 * @author Pietsch
 */
class Build1stCity extends AbstractProperties implements HotMove{


    /**
     * Used Player if present.
     */
    private final Optional<OpenPlayer> player;

    /**
     * Used City.
     */
    private final OpenCity city;

    /**
     * Prototyp Constructor.
     */
    Build1stCity() {
        super(MoveType.Build1stCity, null);
        player = null;
        city = null;
    }

    /**
     * Non-Prototyp Constructor.
     * @param city citiy to be build.
     * @param game this game
     * @param player player who connects the city
     */
    private Build1stCity(OpenGame game, Optional<OpenPlayer> player, OpenCity city) {
        super(MoveType.Build1stCity, game);
        this.player = player;
        this.city = city;
    }


    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (phaseAndPlayer(Phase.Building, player.get(),true).isPresent())
            return phaseAndPlayer(Phase.Building, player.get(), true);

        if (allRequirements().isPresent())
            return allRequirements();

        if (real) {
            final int cost = getGame().getEdition().levelToCityCost().get(getGame().getLevel());
            final int currentAmount = player.get().getElectro();
            player.get().setElectro(currentAmount - cost);
            player.get().getOpenCities().add(city);
        }
        setProperty("type", getType().toString());
        setProperty("player", player.get().getColor());
        setProperty("city", city.getName());
        return Optional.empty();
    }

    /**
     * Check all, excluded game and city.
     * @return problem
     */
    private Optional<Problem> allRequirements() {
        if (player.get().getOpenCities().size() != 0)
            return Optional.of(Problem.HasCities);
        if (getGame().getOpenPlayers().stream().map(openPlayer -> openPlayer.getOpenCities().stream().anyMatch(openCity -> openCity.equals(city))).findAny().orElse(false))
            return Optional.of(Problem.CityTaken);
        final int cost = getGame().getEdition().levelToCityCost().get(getGame().getLevel());
        if (cost > player.get().getElectro())
            return Optional.of(Problem.NoCash);
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {
        if (this.getGameCollect() != null)
            throw new IllegalStateException("This ist not a prototype");
        return openGame.getBoard()
                .getOpenCities()
                .stream()
                .map(openCity -> new Build1stCity(openGame, openPlayer, openCity))
                .filter(move -> move.test().isEmpty())
                .collect(Collectors.toSet());
    }

}
