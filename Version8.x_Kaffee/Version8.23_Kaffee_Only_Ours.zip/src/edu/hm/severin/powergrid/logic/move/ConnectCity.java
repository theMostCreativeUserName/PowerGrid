package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenCity;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * a player connect a city.
 *
 * @author Pietsch
 */
class ConnectCity extends AbstractProperties implements HotMove {

    /**
     * Used Player if present.
     */
    private final Optional<OpenPlayer> player;

    /**
     * Used City.
     */
    private final OpenCity city;

    /**
     * Prototyp Constructor.
     */
    ConnectCity() {
        super(MoveType.ConnectCity, null);
        player = null;
        city = null;
    }

    /**
     * Non-Prototyp Constructor.
     *
     * @param city   citiy to be build.
     * @param game   this game
     * @param player player who connects the city
     */
    private ConnectCity(OpenGame game, Optional<OpenPlayer> player, OpenCity city) {
        super(MoveType.ConnectCity, game);
        this.player = player;
        this.city = city;
    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (allRequirements().isPresent())
            return allRequirements();

        final List<Integer> costConnectionList = player.get()
                .getOpenCities()
                .stream()
                .map(openCity -> openCity.getOpenConnections().get(city))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        if (costConnectionList.isEmpty())
            return Optional.of(Problem.NoCities);
        final int connectionCost = costConnectionList.stream().min(Integer::compareTo).get();
        final int cost = getGame().getEdition().levelToCityCost().get(getGame().getLevel()) + connectionCost;
        if (cost > player.get().getElectro())
            return Optional.of(Problem.NoCash);

        if (real) {
            player.get().getOpenCities().add(city);
            final int currentAmount = player.get().getElectro();
            player.get().setElectro(currentAmount - cost);

        }
        setProperty("type", getType().toString());
        setProperty("player", player.get().getColor());
        setProperty("city", city.getName());
        return Optional.empty();
    }

    /**
     * Check all, excluded game and city.
     *
     * @return problem
     */
    private Optional<Problem> allRequirements() {
        if (player.get().getOpenCities().contains(city))
            return Optional.of(Problem.CityAlreadyConnected);
        final boolean takenCity = getGame().getOpenPlayers().stream().anyMatch(openPlayer -> openPlayer.getOpenCities().stream().anyMatch(openCity -> openCity.equals(city)));
        if (takenCity)
            return Optional.of(Problem.CityTaken);
        if (phaseAndPlayer(Phase.Building, player.get(),true).isPresent())
            return phaseAndPlayer(Phase.Building, player.get(),true);
        return Optional.empty();
    }


    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {
        if (this.getGameCollect() != null)
            throw new IllegalStateException("This ist not a prototype");
        return openGame.getBoard().getOpenCities()
                .stream()
                .map(openCity -> new ConnectCity(openGame, openPlayer, openCity))
                .filter(move -> move.test().isEmpty())
                .collect(Collectors.toSet());
    }
}
