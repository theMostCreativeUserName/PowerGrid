package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Close auction.
 *
 * @author Auerbach
 * */

public class EndAuctions extends AbstractProperties implements HotMove {

    /**
     * prototype constructor.
     */
    EndAuctions(){
        super(MoveType.EndAuctions, null);
    }

    /**
     * non-prototype constructor.
     * @param game game of the move
     */
    private EndAuctions(OpenGame game){

        super(MoveType.EndAuctions, game);
    }

    @Override
    public Optional<Problem> run(boolean real) {
        if(phaseAndAllPlayerPassed(Phase.PlantBuying).isPresent())
            return phaseAndAllPlayerPassed(Phase.PlantBuying);

        if(real){
            if (getGame().getRound() == 1){
                final List<OpenPlayer> sortedPlayerList = getGame().getOpenPlayers()
                        .stream()
                        .sorted(OpenPlayer::compareTo)
                        .collect(Collectors.toList());
                getGame().getOpenPlayers().clear();
                getGame().getOpenPlayers().addAll(sortedPlayerList);

            }
            if (getGame().getAuction() == null){
                final int numberOfSmallestPlant = getGame().getPlantMarket()
                        .getOpenActual()
                        .stream()
                        .map(Plant::getNumber)
                        .min(Integer::compareTo)
                        .orElse(-2);
                getGame().getPlantMarket().removePlant(numberOfSmallestPlant);
            }
            getGame().getOpenPlayers().forEach(openPlayer -> openPlayer.setPassed(false));
            getGame().setPhase(Phase.ResourceBuying);
            getGame().setAuction(null);
        }
        setProperty("type", getType().toString());
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> player) {
        final HotMove move = new EndAuctions(openGame);
        return collectSpecificMove(move);
    }
}
