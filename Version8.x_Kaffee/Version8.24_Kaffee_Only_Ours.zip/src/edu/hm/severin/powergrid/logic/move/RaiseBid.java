package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenAuction;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;


/**
 * player connects cities and end their turn.
 *
 * @author Pietsch
 */
class RaiseBid extends AbstractProperties implements HotMove {

    /**
     * player.
     */
    private final Optional<OpenPlayer> player;

    /**
     * Prototype Constructor.
     */
    RaiseBid() {
        super(MoveType.RaiseBid, null);
        player = null;
    }

    /**
     * Non-Prototype Constructor.
     *
     * @param game   this game
     * @param player optional of player for game
     */
    private RaiseBid(OpenGame game, Optional<OpenPlayer> player) {
        super(MoveType.RaiseBid, game);
        this.player = player;
    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (getGame().getPhase() != Phase.PlantAuction)
            return Optional.of(Problem.NotNow);

        if (allTestWithAuction().isPresent())
            return allTestWithAuction();
        if (real) {
            editAuction();
        }
        setProperty("type", getType().toString());
        setProperty("player", player.get().getColor());
        return Optional.empty();
    }

    /**
     * Editing the Auction.
     */
    private void editAuction() {
        final OpenAuction auction = getGame().getAuction();
        auction.setAmount(auction.getAmount() + 1);
        final OpenPlayer currentPlayer = player.get();
        auction.setPlayer(currentPlayer);
        auction.getOpenPlayers().remove(currentPlayer);
        auction.getOpenPlayers().add(currentPlayer);
    }

    /**
     * Testing all with auction.
     *
     * @return Optional of problem if exist else empty
     */
    private Optional<Problem> allTestWithAuction() {
        if (getGame().getAuction() == null)
            return Optional.of(Problem.NotRunning);
        if (!getGame().getAuction().getOpenPlayers().get(0).equals(player.get()))
            return Optional.of(Problem.NotYourTurn);
        if (getGame().getAuction().getPlayer().equals(player.get()))
            return Optional.of(Problem.TopBidder);
        if (player.get().getElectro() <= getGame().getAuction().getAmount())
            return Optional.of(Problem.NoCash);
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {
        final HotMove move = new RaiseBid(openGame, openPlayer);
        return collectSpecificMove(move);
    }
}
