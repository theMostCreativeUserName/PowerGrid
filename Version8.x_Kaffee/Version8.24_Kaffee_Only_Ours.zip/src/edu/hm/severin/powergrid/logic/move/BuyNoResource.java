package edu.hm.severin.powergrid.logic.move;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

/**
 * Move: Player bought no Resource.
 */
class BuyNoResource extends AbstractProperties implements HotMove {

    /**
     * Used optional of player.
     */
    private final Optional<OpenPlayer> player;

    /**
     * Prototype Constructor.
     */
    BuyNoResource() {
        super(MoveType.BuyNoResource, null);
        this.player = null;
    }

    /**
     * Non-Prototype Constructor.
     *
     * @param game   this game.
     * @param player optional of player.
     */
    private BuyNoResource(OpenGame game, Optional<OpenPlayer> player) {
        super(MoveType.BuyNoResource, game);
        this.player = player;
    }


    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (phaseAndPlayer(Phase.ResourceBuying, player.get(),true).isPresent())
            return phaseAndPlayer(Phase.ResourceBuying, player.get(), true);

        if (real) {
            //player passes turn without doing anything
            player.get().setPassed(true);
        }
        setProperty("type", getType().toString());
        setProperty("player", player.get().getColor());
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {
        final HotMove move = new BuyNoResource(openGame, openPlayer);
        return collectSpecificMove(move);

    }
}
