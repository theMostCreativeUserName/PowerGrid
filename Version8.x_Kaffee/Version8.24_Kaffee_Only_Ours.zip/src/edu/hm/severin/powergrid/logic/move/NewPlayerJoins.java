package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.RandomSource;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * creates a new player for the Game-Session.
 * @author Severin
 */
class NewPlayerJoins extends AbstractProperties implements HotMove {

    /**
     * Prototype - CTor.
     */
     NewPlayerJoins() {
         super(MoveType.JoinPlayer, null);
    }

    /**
     * Non-Prototype - CTor.
     * @param game game of the move
     */
    private NewPlayerJoins(OpenGame game) {
        super(MoveType.JoinPlayer, game);
    }

    /**
     * creates a new player.
     *
     * @param real false, to test the move
     *             true, to fire the move
     */
    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        // test if possible
        // if real, if Phase correct, if mayNumb not reached
        if (getGame().getPhase() != Phase.Opening) return Optional.of(Problem.NotNow);
        if (getGame().getPlayers().size() >= getGame().getEdition().getPlayersMaximum()) return Optional.of(Problem.MaxPlayers);
        if (real) {
            //player color
            final String newColor = getGame().getEdition().getPlayerColors().get(getGame().getPlayers().size());
            // secret for player
            final String newSecret = RandomSource.make().babbled(newColor);
            //create Player
            final OpenPlayer player = getGame().getFactory().newPlayer(newSecret, newColor);
            // insert in Game
            getGame().getOpenPlayers().add(player);
            //game.getPlayers().add(player);
        }
        setProperty("type", getType().toString());
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> player) {
        if (player.isPresent()) return Set.of();
        final HotMove move = new NewPlayerJoins(openGame);
        return collectSpecificMove(move);
    }
}
