package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;


/**
 * player bought no plant.
 *
 * @author Pietsch
 */
class PassAuction extends AbstractProperties implements HotMove {

    /**
     * player.
     */
    private final Optional<OpenPlayer> player;

    /**
     * Prototype Constructor.
     */
    PassAuction() {
        super(MoveType.PassAuction, null);
        player = null;
    }

    /**
     * Non-Prototype Constructor.
     *
     * @param game   this game
     * @param player optional of player for move
     */
    private PassAuction(OpenGame game, Optional<OpenPlayer> player) {
        super(MoveType.PassAuction, game);
        this.player = player;
    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());

        if (phaseAndPlayer(Phase.PlantBuying, player.get(), false).isPresent())
            return phaseAndPlayer(Phase.PlantBuying, player.get(), false);
        if (player.get().getOpenPlants().size() == 0)
            return Optional.of(Problem.NoPlants);

        if (real) {
            player.get().setPassed(true);
        }
        setProperty("type", getType().toString());
        setProperty("player", player.get().getColor());
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {
        final HotMove move = new PassAuction(openGame, openPlayer);
        return collectSpecificMove(move);
    }
}
