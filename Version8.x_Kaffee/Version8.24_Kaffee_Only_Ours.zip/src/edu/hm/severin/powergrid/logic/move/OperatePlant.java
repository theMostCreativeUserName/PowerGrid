package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.HashSet;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * a player operate a Plant.
 *
 * @author Pietsch
 */
class OperatePlant extends AbstractProperties implements HotMove {

    /**
     * Used Player if present.
     */
    private final Optional<OpenPlayer> player;

    /**
     * Plant for Operate.
     */
    private final OpenPlant plant;

    /**
     * Bag of Resources for Operate.
     */
    private final Bag<Resource> resource;

    /**
     * Prototype Constructor.
     */
    OperatePlant() {
        super(MoveType.OperatePlant, null);
        player = null;
        plant = null;
        resource = null;
    }

    /**
     * Non-Prototype Constructor.
     *
     * @param game     this game
     * @param player   player who connects the city
     * @param plant    Plant to Check
     * @param resource resource to buy
     */
    private OperatePlant(OpenGame game, Optional<OpenPlayer> player, OpenPlant plant, Bag<Resource> resource) {
        super(MoveType.OperatePlant, game);
        this.player = player;
        this.plant = plant;
        this.resource = resource;

    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());
        if (allRequirements().isPresent())
            return allRequirements();

        if (real) {
            plant.setOperated(true);
            player.get().getOpenResources().remove(resource);
            getGame().getResourceMarket().getOpenSupply().addAll(resource);
        }
        setProperty("type", getType().toString());
        setProperty("player", player.get().getColor());
        setProperty("plant", String.valueOf(plant.getNumber()));
        final String resourceElements = resource.toString();
        setProperty("resources", resourceElements.substring(resourceElements.indexOf('['),resourceElements.indexOf(']')+1) );
        return Optional.empty();
    }

    /**
     * Check all, excluded phase and storage.
     *
     * @return optional of problem
     */
    private Optional<Problem> allRequirements() {

        if(phaseAndPlayer(Phase.PlantOperation,player.get(),false).isPresent())
            return phaseAndPlayer(Phase.PlantOperation, player.get(),false);
        if (!player.get().getOpenPlants().contains(plant))
            return Optional.of(Problem.NoPlants);
        if (plant.hasOperated())
            return Optional.of(Problem.PlantHasOperated);
        if (!player.get().getOpenResources().contains(resource))
            return Optional.of(Problem.NoResource);

        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {
        if (this.getGameCollect() != null)
            throw new IllegalStateException("This ist not a prototype");
        final Set<OperatePlant> moves = new HashSet<>();
        for (OpenPlant openPlant : openPlayer.get().getOpenPlants()) {
            if (openPlant.getResources().size() == 1)
                moves.add(new OperatePlant(openGame, openPlayer, openPlant, openPlant.getResources().iterator().next()));
            else
                moves.addAll(openPlant.getResources()
                        .stream()
                        .map(bagOfResource -> new OperatePlant(openGame, openPlayer, openPlant, bagOfResource))
                        .collect(Collectors.toSet()));
        }
        return moves.stream().filter(move -> move.test().isEmpty())
                .collect(Collectors.toSet());
    }
}
