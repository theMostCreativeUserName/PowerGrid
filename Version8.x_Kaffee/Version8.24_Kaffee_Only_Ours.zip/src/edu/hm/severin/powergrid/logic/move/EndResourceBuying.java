package edu.hm.severin.powergrid.logic.move;


import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * a player connects no city.
 *
 * @author Pietsch
 */
class EndResourceBuying extends AbstractProperties implements HotMove {

    /**
     * Prototype Constructor.
     */
    EndResourceBuying() {
        super(MoveType.EndResourceBuying, null);
    }

    /**
     * Non-Prototype Constructor.
     *
     * @param game   this game.
     */
    private EndResourceBuying(OpenGame game) {
        super(MoveType.EndResourceBuying, game);
    }

    @Override
    public Optional<Problem> run(boolean real) {
        Objects.requireNonNull(getGame());

        if(phaseAndAllPlayerPassed(Phase.ResourceBuying).isPresent())
            return phaseAndAllPlayerPassed(Phase.ResourceBuying);

        if (real) {
            getGame().setPhase(Phase.Building);
            getGame().getOpenPlayers().forEach(openPlayer -> openPlayer.setPassed(false));
        }
        setProperty("type", getType().toString());
        return Optional.empty();
    }

    @Override
    public Set<HotMove> collect(OpenGame openGame, Optional<OpenPlayer> openPlayer) {

        final HotMove move = new EndResourceBuying(openGame);
        return collectSpecificMove(move);
    }
}
