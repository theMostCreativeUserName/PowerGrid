package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

public class EnterLevel3PTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); //max sec for test

    private final Game game;
    private final Rules sut;
    private final String NO_SECRET = "";
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    public EnterLevel3PTest(){
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }
    @Test
    public void TestEnterLevel3Properties(){
        //arrange

        //game
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);
        opengame.setLevel(1);

        //Player
        OpenPlayer player1 = factory.newPlayer("Jej Level", "red");
        OpenPlayer player2 = factory.newPlayer("Noch mehr Level", "blue");
        opengame.getOpenPlayers().add(player1);
        opengame.getOpenPlayers().add(player2);

        //Markt
        OpenPlant level3Plant = factory.newPlant(333, Plant.Type.Level3, 200, 200);
        opengame.getPlantMarket().getOpenActual().add(level3Plant);

        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(403, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(402, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(408, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(404, Plant.Type.Coal, 30 ,30 ));
        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Jej Level"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.EnterLevel3).collect(Collectors.toList());
        Move move = moves.get(0);
        assertSame(move.getProperties().getProperty("type"), MoveType.EnterLevel3.toString());
        assertEquals("EnterLevel3{}", move.toString());
    }

    @Test
    public void TestEnterLevel3Fire(){
        //arrange

        //game
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);
        opengame.setLevel(1);

        //Player
        OpenPlayer player1 = factory.newPlayer("Jej Level", "red");
        OpenPlayer player2 = factory.newPlayer("Noch mehr Level", "blue");
        opengame.getOpenPlayers().add(player1);
        opengame.getOpenPlayers().add(player2);

        //Markt
        OpenPlant level3Plant = factory.newPlant(333, Plant.Type.Level3, 200, 200);
        opengame.getPlantMarket().getOpenActual().add(level3Plant);
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(403, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(555, Plant.Type.Eco, 1, 1));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(556, Plant.Type.Eco, 1, 1));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(562, Plant.Type.Eco, 1, 1));

        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(557, Plant.Type.Eco, 1, 1));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(558, Plant.Type.Eco, 1, 1));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(559, Plant.Type.Eco, 1, 1));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(560, Plant.Type.Eco, 1, 1));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(561, Plant.Type.Eco, 1, 1));

        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(402, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(408, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(404, Plant.Type.Coal, 30 ,30 ));
        List<OpenPlant> copyOfHidden = List.copyOf(opengame.getPlantMarket().getOpenHidden());
        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Jej Level"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.EnterLevel3).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Jej Level"), moves.get(0));

        //assert
        assertSame(game.getLevel(), 2);
        assertSame(opengame.getPlantMarket().findPlant(333), null);
        assertFalse(opengame.getPlantMarket().getOpenHidden().equals(copyOfHidden));

    }

    @Test
    public void TestEnterLevel3Fire2(){
        //arrange

        //game
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);
        opengame.setLevel(1);

        //Player
        OpenPlayer player1 = factory.newPlayer("Jej Level", "red");
        OpenPlayer player2 = factory.newPlayer("Noch mehr Level", "blue");
        opengame.getOpenPlayers().add(player1);
        opengame.getOpenPlayers().add(player2);

        //Markt
        OpenPlant level3Plant = factory.newPlant(666, Plant.Type.Level3, 200, 200);


        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(409, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(411, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenActual().add(level3Plant);
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(403, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(413, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(415, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenActual().add(factory.newPlant(416, Plant.Type.Coal, 30 ,30 ));

        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(444, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(445, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(446, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(447, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenFuture().add(factory.newPlant(448, Plant.Type.Coal, 30 ,30 ));

        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(402, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(408, Plant.Type.Coal, 30 ,30 ));
        opengame.getPlantMarket().getOpenHidden().add(factory.newPlant(404, Plant.Type.Coal, 30 ,30 ));
        List<OpenPlant> copyOfHidden = List.copyOf(opengame.getPlantMarket().getOpenHidden());

        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Jej Level"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.EnterLevel3).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Jej Level"), moves.get(0));

        //assert
        assertSame(game.getLevel(), 2);
        assertSame(opengame.getPlantMarket().findPlant(666), null);
        assertSame(opengame.getPlantMarket().findPlant(403), null);
        assertFalse(opengame.getPlantMarket().getOpenActual().contains(level3Plant));
        assertSame(opengame.getPlantMarket().getOpenActual().size(), 4);
        assertFalse(opengame.getPlantMarket().getOpenHidden().equals(copyOfHidden));

    }


}

