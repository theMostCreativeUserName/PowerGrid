package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenAuction;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

/**
 * Erste Tests fuer eine Rules-Implementierung.
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @version last modified 2020-04-30
 */

public class LeaveAuctionTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /**
     * Spielstand.
     */
    private final Game game;

    /**
     * Spielregeln.
     */
    private final Rules sut;

    /**
     * Fluchtwert fuer kein Geheimnis.
     */
    private final String NO_SECRET = "";

    /**
     * Fuehrt ein Runnable mehrmals aus.
     */
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    /**
     * Initialisiert Factory und Spielregeln.
     */
    public LeaveAuctionTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }

    @Test
    public void testLeaveAuction() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player2.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = List.of(player, player2, player3);
        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.LeaveAuction).collect(Collectors.toList());
        // assert
        assertSame(moves.size(), 1);
    }

    @Test
    public void testLeaveAuctionProperties() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player2.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player3.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = List.of(player, player2, player3);
        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);


        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().sequential().filter(Move -> Move.getType() == MoveType.LeaveAuction).collect(Collectors.toList());
        Move move = moves.get(0);
        assertSame(move.getProperties().getProperty("type"), MoveType.LeaveAuction.toString());
        assertSame(move.getProperties().getProperty("player"), player.getColor() );
        assertEquals("LeaveAuction{player=red}", move.toString());
    }

    @Test
    public void testLeaveAuctionFire() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);
        players.add(player2);
        players.add(player3);

        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);
        auction.setAmount(110);

        List<Player> fakedPlayers = List.of(player2, player3);
        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.LeaveAuction).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertTrue(problem.isEmpty());
        assertEquals(fakedPlayers, game.getAuction().getPlayers());
    }

    @Test
    public void testLeaveAuctionFire2() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);
        players.add(player2);
        players.add(player3);

        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);
        auction.setAmount(110);

        List<Player> fakedPlayers = List.of(player2, player3);
        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.LeaveAuction).collect(Collectors.toList());
        opengame.setPhase(Phase.Building);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.NotNow);
    }

    @Test
    public void testLeaveAuctionFire3() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);
        players.add(player2);
        players.add(player3);

        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);
        auction.setAmount(110);

        List<Player> fakedPlayers = List.of(player2, player3);
        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.LeaveAuction).collect(Collectors.toList());
        auction.getOpenPlayers().remove(player);
        auction.getOpenPlayers().add(player);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.NotYourTurn);
    }

    @Test
    public void testLeaveAuctionFire4() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);
        player.setPassed(false);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);
        player.setPassed(false);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);
        player.setPassed(false);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = new ArrayList<>();
        players.add(player);
        players.add(player2);
        players.add(player3);

        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);
        auction.setAmount(110);

        List<Player> fakedPlayers = List.of(player2, player3);
        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.LeaveAuction).collect(Collectors.toList());
        opengame.getAuction().setPlayer(player);
        Optional<Problem> problem =  sut.fire(Optional.of("Hihi"), moves.get(0));
        // assert
        assertSame(problem.get(), Problem.TopBidder);
    }

    @Test (expected = IllegalStateException.class)
    public void testLeaveAuctionException() {
        // arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        opengame.setPhase(Phase.Building);
        OpenFactory factory = opengame.getFactory();

        opengame.setPhase(Phase.PlantAuction);

        //Player
        OpenPlayer player = factory.newPlayer("Hihi", "red");
        player.setElectro(200);

        OpenPlayer player2 = factory.newPlayer("NOOOOO", "blue");
        player2.setElectro(200);

        OpenPlayer player3 = factory.newPlayer("Rainbow", "pink");
        player3.setElectro(200);

        opengame.getOpenPlayers().add(player);
        opengame.getOpenPlayers().add(player2);
        opengame.getOpenPlayers().add(player3);

        //Auction
        List<OpenPlayer> players = List.of(player, player2, player3);
        OpenAuction auction = factory.newAuction(factory.newPlant(30, Plant.Type.Coal, 2, 3), players);
        opengame.setAuction(auction);
        auction.setPlayer(player2);
        auction.setAmount(110);

        // act
        final Set<Move> haveMove = sut.getMoves(Optional.of("Hihi"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.LeaveAuction).collect(Collectors.toList());
        HotMove move = (HotMove)moves.get(0);
        move.collect(opengame, Optional.of(factory.newPlayer("Irgendwas", "Mir egal")));
    }


}
