package edu.hm.severin.powergrid.logic.move;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.*;
import edu.hm.cs.rs.powergrid.logic.Move;
import edu.hm.cs.rs.powergrid.logic.MoveType;
import edu.hm.cs.rs.powergrid.logic.Problem;
import edu.hm.cs.rs.powergrid.logic.Rules;
import edu.hm.cs.rs.powergrid.logic.move.HotMove;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.lang.reflect.Constructor;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.*;

public class SupplyElectricityTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); //max sec for test

    private final Game game;
    private final Rules sut;
    private final String NO_SECRET = "";
    private static BiConsumer<Integer, Runnable> times = (n, runnable) -> IntStream.range(0, n).forEach(__ -> runnable.run());

    public SupplyElectricityTest(){
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        System.setProperty("powergrid.rules", "edu.hm.severin.powergrid.logic.StandardRules");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());
        sut = Rules.newRules(openGame);
        game = openGame;
    }

    //Keine Ahnung wie dieses Zeug funktioniert O_O, naja kann nur Kaputt gehen ;)

    public SupplyElectricity getSut() throws ReflectiveOperationException {
        Constructor<SupplyElectricity> cTor = SupplyElectricity.class
                .getDeclaredConstructor(OpenGame.class);
        cTor.setAccessible(true);
        return cTor.newInstance(game);
    }

    public SupplyElectricity getSutProto() throws ReflectiveOperationException {
        Constructor<SupplyElectricity> cTor = SupplyElectricity.class
                .getDeclaredConstructor();
        cTor.setAccessible(true);
        return cTor.newInstance();
    }

    @Test
    public void SupplyElectricityCollect1(){
        //arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);

        //Player1
        OpenPlayer player = factory.newPlayer("ReadyPlayerOne", "red");
        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 2, 2);
        plant.setOperated(true);
        OpenCity city = factory.newCity("LOLHausen", 666);
        player.setElectro(420);
        player.setPassed(true);
        opengame.getOpenPlayers().add(player);
        player.getOpenPlants().add(plant);
        player.getOpenCities().add(city);

        //Player2
        OpenPlayer player2 = factory.newPlayer("ReadyPlayerTwo", "blue");
        OpenPlant plant2 = factory.newPlant(303, Plant.Type.Coal, 2, 2);
        plant2.setOperated(true);
        OpenCity city2 = factory.newCity("LOLHausen2", 666);
        player2.setElectro(520);
        player2.setPassed(true);
        opengame.getOpenPlayers().add(player2);
        player2.getOpenPlants().add(plant2);
        player2.getOpenCities().add(city2);

        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("ReadyPlayerOne"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.SupplyElectricity).collect(Collectors.toList());

        //assert
       assertSame(moves.size(), 1);
    }

    @Test
    public void SupplyElectricityProperties(){
        //arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);

        //Player1
        OpenPlayer player = factory.newPlayer("ReadyPlayerOne", "red");
        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 2, 2);
        plant.setOperated(true);
        OpenCity city = factory.newCity("LOLHausen", 666);
        player.setElectro(420);
        player.setPassed(true);
        opengame.getOpenPlayers().add(player);
        player.getOpenPlants().add(plant);
        player.getOpenCities().add(city);

        //Player2
        OpenPlayer player2 = factory.newPlayer("ReadyPlayerTwo", "blue");
        OpenPlant plant2 = factory.newPlant(303, Plant.Type.Coal, 2, 2);
        plant2.setOperated(true);
        OpenCity city2 = factory.newCity("LOLHausen2", 666);
        player2.setElectro(520);
        player2.setPassed(true);
        opengame.getOpenPlayers().add(player2);
        player2.getOpenPlants().add(plant2);
        player2.getOpenCities().add(city2);

        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("ReadyPlayerOne"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.SupplyElectricity).collect(Collectors.toList());
        Move move = moves.get(0);
        assertSame(move.getProperties().getProperty("type"), MoveType.SupplyElectricity.toString());
        assertEquals("SupplyElectricity{}", move.toString());
    }

    @Test
    public void SupplyElectricityFire(){
        //arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);
        opengame.getPlantMarket().getOpenHidden().clear();

        //init full plantMarket
        OpenPlant p1 = factory.newPlant(101, Plant.Type.Coal, 2,3);
        OpenPlant p2 = factory.newPlant(102, Plant.Type.Coal, 2,3);
        OpenPlant p3 = factory.newPlant(103, Plant.Type.Coal, 2,3);
        OpenPlant p4 = factory.newPlant(104, Plant.Type.Coal, 2,3);
        opengame.getPlantMarket().getOpenActual().add(p1);
        opengame.getPlantMarket().getOpenActual().add(p2);
        opengame.getPlantMarket().getOpenActual().add(p3);
        opengame.getPlantMarket().getOpenActual().add(p4);

        //Player1
        OpenPlayer player = factory.newPlayer("ReadyPlayerOne", "red");
        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 2, 2);
        plant.setOperated(true);
        OpenCity city = factory.newCity("LOLHausen", 666);
        player.setElectro(420);
        player.setPassed(true);
        opengame.getOpenPlayers().add(player);
        player.getOpenPlants().add(plant);
        player.getOpenCities().add(city);

        //Player2
        OpenPlayer player2 = factory.newPlayer("ReadyPlayerTwo", "blue");
        OpenPlant plant2 = factory.newPlant(303, Plant.Type.Coal, 2, 2);
        plant2.setOperated(true);
        OpenCity city2 = factory.newCity("LOLHausen2", 666);
        player2.setElectro(520);
        player2.setPassed(true);
        opengame.getOpenPlayers().add(player2);
        player2.getOpenPlants().add(plant2);
        player2.getOpenCities().add(city2);

        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("ReadyPlayerOne"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.SupplyElectricity).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("ReadyPlayerOne"), moves.get(0));

        assertTrue(problem.isEmpty());
        assertFalse(player.hasPassed());
        assertFalse(player2.hasPassed());
        assertSame(opengame.getPhase(), Phase.PlantBuying); //Bureaucracy moves are priored or can automove
        assertFalse(plant.hasOperated());
        assertFalse(plant2.hasOperated());
        assertEquals(player.getElectro(), 442);
        assertEquals(player2.getElectro(), 542);
    }

    @Test
    public void SupplyElectricityFire2(){
        //arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);
        opengame.getPlantMarket().getOpenHidden().clear();

        //init full plantMarket
        OpenPlant p1 = factory.newPlant(101, Plant.Type.Coal, 2,3);
        OpenPlant p2 = factory.newPlant(102, Plant.Type.Coal, 2,3);
        OpenPlant p3 = factory.newPlant(103, Plant.Type.Coal, 2,3);
        OpenPlant p4 = factory.newPlant(104, Plant.Type.Coal, 2,3);
        opengame.getPlantMarket().getOpenActual().add(p1);
        opengame.getPlantMarket().getOpenActual().add(p2);
        opengame.getPlantMarket().getOpenActual().add(p3);
        opengame.getPlantMarket().getOpenActual().add(p4);

        //Player1
        OpenPlayer player = factory.newPlayer("ReadyPlayerOne", "red");
        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 2, 2);
        plant.setOperated(true);
        OpenCity city = factory.newCity("LOLHausen", 666);
        player.setElectro(420);
        player.setPassed(true);
        opengame.getOpenPlayers().add(player);
        player.getOpenPlants().add(plant);
        player.getOpenCities().add(city);

        //Player2
        OpenPlayer player2 = factory.newPlayer("ReadyPlayerTwo", "blue");
        OpenPlant plant2 = factory.newPlant(303, Plant.Type.Coal, 2, 2);
        plant2.setOperated(true);
        OpenCity city2 = factory.newCity("LOLHausen2", 666);
        OpenCity city3 = factory.newCity("LOLHausen3", 666);
        player2.setElectro(520);
        player2.setPassed(true);
        opengame.getOpenPlayers().add(player2);
        player2.getOpenPlants().add(plant2);
        player2.getOpenCities().add(city2);
        player2.getOpenCities().add(city3);

        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("ReadyPlayerOne"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.SupplyElectricity).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("ReadyPlayerOne"), moves.get(0));

        assertTrue(problem.isEmpty());
        assertFalse(player.hasPassed());
        assertFalse(player2.hasPassed());
        assertSame(opengame.getPhase(), Phase.PlantBuying); //Bureaucracy moves are priored or can automove
        assertFalse(plant.hasOperated());
        assertFalse(plant2.hasOperated());
        assertEquals(player.getElectro(), 442);
        assertEquals(player2.getElectro(), 553);
    }

    @Test
    public void SupplyElectricityFire3(){
        //arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);
        opengame.getPlantMarket().getOpenHidden().clear();

        //init full plantMarket
        OpenPlant p1 = factory.newPlant(101, Plant.Type.Coal, 2,3);
        OpenPlant p2 = factory.newPlant(102, Plant.Type.Coal, 2,3);
        OpenPlant p3 = factory.newPlant(103, Plant.Type.Coal, 2,3);
        OpenPlant p4 = factory.newPlant(104, Plant.Type.Coal, 2,3);
        opengame.getPlantMarket().getOpenActual().add(p1);
        opengame.getPlantMarket().getOpenActual().add(p2);
        opengame.getPlantMarket().getOpenActual().add(p3);
        opengame.getPlantMarket().getOpenActual().add(p4);

        //Player1
        OpenPlayer player = factory.newPlayer("ReadyPlayerOne", "red");
        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 2, 2);
        plant.setOperated(true);
        OpenCity city = factory.newCity("LOLHausen", 666);
        player.setElectro(420);
        player.setPassed(true);
        opengame.getOpenPlayers().add(player);
        player.getOpenPlants().add(plant);
        player.getOpenCities().add(city);

        //Player2
        OpenPlayer player2 = factory.newPlayer("ReadyPlayerTwo", "blue");
        OpenPlant plant2 = factory.newPlant(303, Plant.Type.Coal, 2, 2);
        plant2.setOperated(true);
        OpenCity city2 = factory.newCity("LOLHausen2", 666);
        OpenCity city3 = factory.newCity("LOLHausen3", 666);
        OpenCity city4 = factory.newCity("LOLHausen4", 666);
        player2.setElectro(520);
        player2.setPassed(true);
        opengame.getOpenPlayers().add(player2);
        player2.getOpenPlants().add(plant2);
        player2.getOpenCities().add(city2);
        player2.getOpenCities().add(city3);
        player2.getOpenCities().add(city4);

        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("ReadyPlayerOne"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.SupplyElectricity).collect(Collectors.toList());
        Optional<Problem> problem =  sut.fire(Optional.of("ReadyPlayerOne"), moves.get(0));

        assertTrue(problem.isEmpty());
        assertFalse(player.hasPassed());
        assertFalse(player2.hasPassed());
        assertSame(opengame.getPhase(), Phase.PlantBuying); //Bureaucracy moves are priored or can automove
        assertFalse(plant.hasOperated());
        assertFalse(plant2.hasOperated());
        assertEquals(player.getElectro(), 442);
        assertEquals(player2.getElectro(), 553);
    }

    @Test
    public void SupplyElectricityFireWithThisWiredThings() throws ReflectiveOperationException {
        //arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);

        //init full plantMarket
        OpenPlant p1 = factory.newPlant(101, Plant.Type.Coal, 2,3);
        OpenPlant p2 = factory.newPlant(102, Plant.Type.Coal, 2,3);
        OpenPlant p3 = factory.newPlant(103, Plant.Type.Coal, 2,3);
        OpenPlant p4 = factory.newPlant(104, Plant.Type.Coal, 2,3);
        opengame.getPlantMarket().getOpenActual().add(p1);
        opengame.getPlantMarket().getOpenActual().add(p2);
        opengame.getPlantMarket().getOpenActual().add(p3);
        opengame.getPlantMarket().getOpenActual().add(p4);

        //Player1
        OpenPlayer player = factory.newPlayer("ReadyPlayerOne", "red");
        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 2, 2);
        plant.setOperated(true);
        OpenCity city = factory.newCity("LOLHausen", 666);
        player.setElectro(420);
        player.setPassed(true);
        opengame.getOpenPlayers().add(player);
        player.getOpenPlants().add(plant);
        player.getOpenCities().add(city);

        //Player2
        OpenPlayer player2 = factory.newPlayer("ReadyPlayerTwo", "blue");
        OpenPlant plant2 = factory.newPlant(303, Plant.Type.Coal, 2, 2);
        plant2.setOperated(true);
        OpenCity city2 = factory.newCity("LOLHausen2", 666);
        OpenCity city3 = factory.newCity("LOLHausen3", 666);
        OpenCity city4 = factory.newCity("LOLHausen4", 666);
        player2.setElectro(520);
        player2.setPassed(true);
        opengame.getOpenPlayers().add(player2);
        player2.getOpenPlants().add(plant2);
        player2.getOpenCities().add(city2);
        player2.getOpenCities().add(city3);
        player2.getOpenCities().add(city4);

        //act
        SupplyElectricity sut = getSutProto();
        Set<HotMove> haveMove = sut.collect(opengame, Optional.of(player2));
        List<HotMove> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.SupplyElectricity).collect(Collectors.toList());
        Optional<Problem> problem = moves.get(0).run(true);

        assertTrue(problem.isEmpty());
        assertFalse(player.hasPassed());
        assertFalse(player2.hasPassed());
        assertSame(opengame.getPhase(), Phase.Bureaucracy); //Bureaucracy moves are priored or can automove
        assertFalse(plant.hasOperated());
        assertFalse(plant2.hasOperated());
        assertEquals(player.getElectro(), 442);
        assertEquals(player2.getElectro(), 553);
    }

    @Test (expected = IllegalStateException.class)
    public void SupplyElectricityFireException(){
        //arrange
        OpenGame opengame = (OpenGame) sut.getGame();
        OpenFactory factory = opengame.getFactory();
        opengame.setPhase(Phase.PlantOperation);

        //Player1
        OpenPlayer player = factory.newPlayer("ReadyPlayerOne", "red");
        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 2, 2);
        plant.setOperated(true);
        OpenCity city = factory.newCity("LOLHausen", 666);
        player.setElectro(420);
        player.setPassed(true);
        opengame.getOpenPlayers().add(player);
        player.getOpenPlants().add(plant);
        player.getOpenCities().add(city);

        //Player2
        OpenPlayer player2 = factory.newPlayer("ReadyPlayerTwo", "blue");
        OpenPlant plant2 = factory.newPlant(303, Plant.Type.Coal, 2, 2);
        plant2.setOperated(true);
        OpenCity city2 = factory.newCity("LOLHausen2", 666);
        OpenCity city3 = factory.newCity("LOLHausen3", 666);
        OpenCity city4 = factory.newCity("LOLHausen4", 666);
        player2.setElectro(520);
        player2.setPassed(true);
        opengame.getOpenPlayers().add(player2);
        player2.getOpenPlants().add(plant2);
        player2.getOpenCities().add(city2);
        player2.getOpenCities().add(city3);
        player2.getOpenCities().add(city4);

        //act
        final Set<Move> haveMove = sut.getMoves(Optional.of("ReadyPlayerOne"));
        List<Move> moves = haveMove.stream().filter(Move -> Move.getType() == MoveType.SupplyElectricity).collect(Collectors.toList());
        HotMove move = (HotMove)moves.get(0);
        move.collect(opengame, Optional.of(factory.newPlayer("Irgendwas", "Mir egal")));
    }

}

