package edu.hm.severin.powergrid.logic;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenGame;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import edu.hm.severin.powergrid.datastore.NeutralFactory;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;

public class SortingRandomTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test


    private final NeutralFactory factory;

    public SortingRandomTest() {
        // TODO: Fuegen Sie hier Ihre eigenen FQCNs ein.
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        final OpenGame openGame = OpenFactory.newFactory().newGame(new EditionGermany());

        factory = new NeutralFactory();
    }
    @Test
    public void makeSecret(){
        SortingRandom random = new SortingRandom();
        assertEquals("redX", random.babbled("red"));
    }
    @Test
    public void sortPlants(){
        SortingRandom random = new SortingRandom();
        OpenPlant plant = factory.newPlant(202, Plant.Type.Coal,2,2);
        OpenPlant plant2 = factory.newPlant(200, Plant.Type.Coal,2,2);
        OpenPlant plant3 = factory.newPlant(230, Plant.Type.Coal,2,2);
        List<OpenPlant> lp = new ArrayList<>();
        lp.add(plant);
        lp.add(plant2);
        lp.add(plant3);
        String before = lp.toString();
        random.shufflePlants(lp);
        String after = lp.toString();
        assertFalse(before.equals(after));
        assertEquals(plant2,lp.get(0));
        assertEquals(plant,lp.get(1));
        assertEquals(plant3,lp.get(2));

    }
    @Test
    public void sortPlayers(){
        SortingRandom random = new SortingRandom();
        OpenPlayer p = factory.newPlayer("just drown", "aa");
        OpenPlayer p1 = factory.newPlayer("in all", "xa");
        OpenPlayer p2 = factory.newPlayer("the tests", "h");
        OpenPlayer p3 = factory.newPlayer("of this thing", "ab");
        List<OpenPlayer> lp = new ArrayList<>();
        lp.add(p);
        lp.add(p1);
        lp.add(p2);
        lp.add(p3);
        String before = lp.toString();
        random.shufflePlayers(lp);
        String after = lp.toString();

        assertFalse(before.equals(after));
        assertEquals(p, lp.get(0));
        assertEquals(p3, lp.get(1));
        assertEquals(p2, lp.get(2));
        assertEquals(p1, lp.get(3));
    }
}
