package edu.hm.severin.powergrid.datastore;

import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.*;
import edu.hm.cs.rs.powergrid.datastore.mutable.*;
import edu.hm.severin.powergrid.ListBag;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.*;

/** Test the non OpenData store.
 * They have no setter, and all list or sets are immutable
 */
public class NonOpenDatastoreTest {

    @Rule
    public final Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    /** Factory. */
    private final OpenFactory factory;

    /** Initialisiert die Factory. */
    public NonOpenDatastoreTest() throws IOException {
        // TODO: Ersetzen Sie den Wert durch den FQCN Ihrer Factory-Implementierung
        System.setProperty("powergrid.factory", "edu.hm.severin.powergrid.datastore.NeutralFactory");
        factory = OpenFactory.newFactory();
    }

    /** Edition. */
    private Edition edition = new EditionGermany();


    //x. 17

    //Auction
    @Test
    public void AuctionGetPlayerPlayersAmountPlant(){
        OpenPlant plant = factory.newPlant(10, Plant.Type.Oil, 2, 2);
        OpenPlayer player = factory.newPlayer("HO", "No");
        Auction auction = factory.newAuction(plant, List.of(player));

        List <Player> wantPlayers = List.of((Player) player);
        int wantAmount = 10;

        assertEquals(player, auction.getPlayer());
        assertEquals(plant, auction.getPlant());
        assertEquals(wantPlayers, auction.getPlayers());
        assertSame(wantAmount, auction.getAmount());
    }

    @Test (expected = UnsupportedOperationException.class)
    public void AuctionGetPlayersAdd(){
        OpenPlant plant = factory.newPlant(10, Plant.Type.Oil, 2, 2);
        OpenPlayer player = factory.newPlayer("HO", "No");
        Auction auction = factory.newAuction(plant, List.of(player));

        auction.getPlayers().add(factory.newPlayer("Hi", "Bye"));

    }

    //Board
    @Test (expected = UnsupportedOperationException.class)
    public void BoardGetCitiesAdd(){
        Board board = factory.newBoard(edition);
        board.getCities().add(factory.newCity("Lolhausen", 666));
    }

    @Test
    public void BoardFindCity(){
        OpenBoard openBoard = factory.newBoard(edition);
        openBoard.getOpenCities().clear();
        OpenCity city = factory.newCity("Lolhausen", 666);
        openBoard.getOpenCities().add(city);

        Board board = (Board)openBoard;

        assertEquals(city, board.findCity("Lolhausen"));
    }

    //City
    @Test
    public void CityGetNameRegionConnections(){
        OpenCity openCity = factory.newCity("Texthausen", 345);
        City city = (City) openCity;
        City city2 = factory.newCity("Lolhausen", 4);
        openCity.connect(city2, 5);

        Map<City, Integer> mapOfConnection;
        mapOfConnection = Map.of(city2, 5);

        assertEquals(city.getName(), "Texthausen");
        assertEquals(city.getRegion(), 345);
        assertEquals(city.getConnections(), mapOfConnection );
    }

    @Test (expected = UnsupportedOperationException.class)
    public void CityGetConnectionsAdd(){
        City city = factory.newCity("Testhausen", 5);
        City city2 = factory.newCity("Lolhausen", 4);
        city.getConnections().put(city2, 10);
    }

    @Test (expected = IllegalStateException.class)
    public void CityCloseAndConnectAfter(){
        OpenCity openCity = factory.newCity("Texthausen", 345);
        City city = (City) openCity;
        City city2 = factory.newCity("Lolhausen", 4);
        City city3 = factory.newCity("Mainhausen", 4);
        openCity.connect(city3, 5);
        city.close();
        openCity.connect(city2, 10);
    }

    //Plant
    @Test
    public void PlantGetAll(){
        Plant plant = factory.newPlant(12, Plant.Type.Oil, 3, 3);

        Bag<Resource> bagOfResource = new ListBag<Resource>().add(Resource.Oil, 3);
        Set<Bag<Resource>> setOfBagsOfResources = Set.of(bagOfResource);

        assertEquals(plant.getNumber(), 12);
        assertEquals(plant.getCities(), 3);
        assertEquals(plant.getType(), Plant.Type.Oil);
        assertFalse(plant.hasOperated());
        assertEquals(plant.getResources(), setOfBagsOfResources);
    }
    @Test (expected = UnsupportedOperationException.class)
    public void PlantGetResources(){
        Plant plant = factory.newPlant(12, Plant.Type.Oil, 3, 3);
        Bag<Resource> bag = new ListBag<>();
        bag.add(Resource.Oil, 4);
        plant.getResources().add(bag);
    }

    //PlantMarket
    @Test (expected = UnsupportedOperationException.class)
    public void PlantMarketGetActualAdd(){
        PlantMarket plantMarket = factory.newPlantMarket(edition);
        plantMarket.getActual().add(factory.newPlant(200, Plant.Type.Oil, 20 , 20));
    }

    @Test (expected = UnsupportedOperationException.class)
    public void PlantMarketGetFutureAdd(){
        PlantMarket plantMarket = factory.newPlantMarket(edition);
        plantMarket.getFuture().add(factory.newPlant(200, Plant.Type.Oil, 20 , 20));
    }

    @Test
    public void PlantMarketGetNumberHiddenAndFindPlant(){
        OpenPlantMarket openPlantMarket = factory.newPlantMarket(edition);
        openPlantMarket.getOpenHidden().clear();

        OpenPlant plant = factory.newPlant(301, Plant.Type.Coal, 10, 10);
        openPlantMarket.getOpenHidden().add(plant);

        PlantMarket plantMarket = (PlantMarket) openPlantMarket;
        assertEquals(plantMarket.getNumberHidden(), 1);
        assertEquals(plantMarket.findPlant(301), plant);
    }

    //ResourceMarket
    @Test
    public void ResourceMarketGetBothAndGetPrice(){
        ResourceMarket resourceMarket = factory.newResourceMarket(edition);

        assertSame(resourceMarket.getSupply().size(), 34);
        assertSame(resourceMarket.getAvailable().size(), 50);
        assertSame(resourceMarket.getPrice(Resource.Oil), 3);
    }

    @Test (expected = UnsupportedOperationException.class)
    public void ResourceMarketGetAvailableAdd(){
        ResourceMarket resourceMarket = factory.newResourceMarket(edition);
        resourceMarket.getAvailable().add(Resource.Oil);
    }

    @Test (expected = UnsupportedOperationException.class)
    public void ResourceMarketGetSupplyAdd(){
        ResourceMarket resourceMarket = factory.newResourceMarket(edition);
        resourceMarket.getSupply().add(Resource.Oil);
    }

    //Player
    @Test
    public void PlayerAllGetter(){
        OpenPlayer openPlayer = factory.newPlayer("secret", "farbe");
        openPlayer.getOpenCities().add(factory.newCity("Testhausen", 666));
        openPlayer.setPassed(true);
        openPlayer.setElectro(111);
        openPlayer.getOpenPlants().add(factory.newPlant(20, Plant.Type.Coal, 12, 12));
        openPlayer.getOpenResources().add(Resource.Oil, 2);

        Player player = (Player) openPlayer;

        assertSame(player.getColor(), "farbe");
        assertSame(player.getElectro(), 111);
        assertSame(player.getSecret(), "secret");
        assertSame(player.getCities().size(), 1);
        assertSame(player.getResources().size(), 2);
        assertSame(player.getPlants().size(), 1);
    }

    @Test (expected = UnsupportedOperationException.class)
    public void PlayerGetCitiesAdd(){
        Player player = factory.newPlayer("secret", "farbe");
        player.getCities().add(factory.newCity("string", 1));
    }

    @Test (expected = UnsupportedOperationException.class)
    public void PlayerGetPlantsAdd(){
        Player player = factory.newPlayer("secret", "farbe");
        player.getPlants().add(factory.newPlant(201, Plant.Type.Coal, 34, 56));
    }

    @Test (expected = UnsupportedOperationException.class)
    public void PlayerGetResourcesAdd(){
        Player player = factory.newPlayer("secret", "farbe");
        player.getResources().add(Resource.Oil);
    }

    //Game
    @Test
    public void GameAllGetter(){
        OpenGame openGame = factory.newGame(edition);

        //Alle Vorrausetzungen
        openGame.setRound(20);
        openGame.setPhase(Phase.PlantOperation);
        openGame.setLevel(12);
        openGame.setNumMoves(11);
        OpenPlayer player = factory.newPlayer("secret", "nichts");
        openGame.getOpenPlayers().add(player);
        OpenAuction auction = factory.newAuction(factory.newPlant(333, Plant.Type.Coal, 12, 12), List.of(player));
        openGame.setAuction(auction);

        //Alle Referenzen von der Factory
        Board board = factory.newBoard(edition);
        PlantMarket plantMarket = factory.newPlantMarket(edition);
        ResourceMarket resourceMarket = factory.newResourceMarket(edition);


        Game game = (Game) openGame;
        //asserts
        assertSame(game.getEdition(), edition);
        assertSame(game.getBoard(), board);
        assertSame(game.getRound(), 20);
        assertSame(game.getPhase(), Phase.PlantOperation);
        assertSame(game.getPlayers().size(), 1);
        assertSame(game.getLevel(), 12);
        assertSame(game.getPlantMarket(), plantMarket);
        assertSame(game.getResourceMarket(), resourceMarket);
        assertSame(game.getAuction(), auction);
        assertSame(game.getNumMoves(), 11);
        assertSame(game.findPlayer("secret"), player);
    }

    @Test (expected = UnsupportedOperationException.class)
    public void GameGetPlayersAdd(){
        Game game = factory.newGame(edition);
        game.getPlayers().add(factory.newPlayer("sec", "col"));
    }

}
