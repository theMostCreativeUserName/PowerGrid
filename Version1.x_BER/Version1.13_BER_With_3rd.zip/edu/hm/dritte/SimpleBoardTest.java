package edu.hm.dritte;

import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Board;
import edu.hm.cs.rs.powergrid.datastore.City;
import edu.hm.cs.rs.powergrid.datastore.Factory;
import edu.hm.severin.powergrid.datastore.NeutralBoard;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class SimpleBoardTest {
    private final static String factoryfqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1);
    private Factory factory;

    @Before
    public void initFactory() {
        factory = Factory.newFactory(factoryfqcn);
    }

    /**
     * Generates an empty board, factories can only generate pre-filled boards.
     *
     * @return an empty board.
     */
    private Board newEmptyBoard() {
        return factory.newBoard(new EditionGermany());
    }


    @Test
    public void findCityNullNoCities() {
        final Board sut = newEmptyBoard();
        assertNull(sut.findCity("this is a name"));
    }

    // close
    @Test(expected = IllegalStateException.class)
    public void closeTwice() {
        final Board sut = newEmptyBoard();
        sut.close();
        sut.close();
    }

    @Test(expected = IllegalStateException.class)
    public void closeThenCloseRegions() {
        final Board sut = newEmptyBoard();
        sut.close();
        sut.closeRegions(5);
    }

    @Test
    public void closeOnceCheckImmutable() {
        final Board sut = newEmptyBoard();
        Set<City> cities = sut.getCities();
        assertEquals(42, sut.getCities().size());
        sut.close();
        cities.add(factory.newCity("tst", 194));
        assertEquals(43, cities.size());
        assertEquals(43, sut.getCities().size());
    }

}
