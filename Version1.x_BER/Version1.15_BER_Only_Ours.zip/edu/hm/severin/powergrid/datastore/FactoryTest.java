package edu.hm.severin.powergrid.datastore;


import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.*;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;

/**
 *
 * @author R. Schiedermeier, rs@cs.hm.edu
 * @author Pietsch
 * @version last modified 2020-04-07
 */
public class FactoryTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(1); // max seconds per test

    private final String fqcn = "edu.hm.severin.powergrid.datastore.NeutralFactory";

    private final edu.hm.cs.rs.powergrid.datastore.Factory factory = Factory.newFactory(fqcn);


    @Test
    public void newOtherCity() {
        // arrange
        City sut = factory.newCity("Duckburg", 1);
        // act
        final City have = factory.newCity("Mouseton", 1);
        // assert
        Assert.assertNotSame("factory returns different City objects for different names", sut, have);
    }

    @Test public void newSamePlayer() {
        // arrange
        Player sut = factory.newPlayer("geheim", "a");
        // act
        final Player have = factory.newPlayer("geheim2", "a");
        // assert
        Assert.assertSame("factory supplies one Player object per color", sut, have);
    }




    @Test public void newOtherBoard() {
        // arrange
        Edition test = new EditionGermany();
        Board sut = factory.newBoard(test);
        // act
        Edition test2 = new EditionGermany();
        final Board have = factory.newBoard(test2);
        // assert
        Assert.assertNotSame("factory returns different Board objects for different edition", sut, have);
    }


    @Test public void newResourceMarket() {
        // arrange
        ResourceMarket sut = factory.newResourceMarket(new EditionGermany());
        // assert
        Assert.assertSame( sut, null);
    }

    @Test public void newPlantMarket() {
        // arrange
        PlantMarket sut = factory.newPlantMarket(new EditionGermany());
        // assert
        Assert.assertSame( sut, null);
    }

    @Test public void newGame() {
        // arrange
        Game sut = factory.newGame(new EditionGermany());
        // assert
        Assert.assertSame( sut, null);
    }
    @Test public void newAction(){
        Auction sut = factory.newAuction(null, null);
        assertEquals(sut, null);
    }
    @Test public void newPlant(){
        Plant sut = factory.newPlant(0, null, 3, 4);
        assertEquals(sut, null);
    }
}