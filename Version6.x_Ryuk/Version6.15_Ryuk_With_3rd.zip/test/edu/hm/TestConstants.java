package edu.hm;

import org.junit.rules.Timeout;

abstract public class TestConstants {
    public final static String FACTORY_FQCN = "edu.hm.severin.powergrid.datastore.NeutralFactory";
    public final static Timeout TIMEOUT = Timeout.seconds(1);
}
