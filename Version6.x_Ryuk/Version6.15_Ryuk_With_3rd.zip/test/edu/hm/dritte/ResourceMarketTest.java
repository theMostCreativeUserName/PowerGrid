package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.cs.rs.powergrid.datastore.ResourceMarket;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.severin.powergrid.ListBag;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;

public class ResourceMarketTest {
    private final Edition edition = new EditionGermany();
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;
    private OpenFactory factory;

    @Before
    public void initFactory() {
        factory = OpenFactory.newFactory(TestConstants.FACTORY_FQCN);
    }

    protected OpenFactory getFactory() {
        return factory;
    }

    protected Edition getEdition() {
        return edition;
    }

    protected ResourceMarket getSut() {
        return getFactory().newResourceMarket(getEdition());
    }

    @Test
    public void resourceMarketAvailable() {
        // arrange
        final Bag<Resource> want = new ListBag<>();
        want.add(Resource.Coal, 24);
        want.add(Resource.Oil, 18);
        want.add(Resource.Garbage, 6);
        want.add(Resource.Uranium, 2);

        // act
        final ResourceMarket sut = getSut();
        final Bag<Resource> have = sut.getAvailable();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void resourceMarketSupply() {
        // arrange
        final Bag<Resource> want = new ListBag<>();
        want.add(Resource.Oil, 6);
        want.add(Resource.Garbage, 18);
        want.add(Resource.Uranium, 10);

        // act
        final ResourceMarket sut = getSut();
        final Bag<Resource> have = sut.getSupply();

        // assert
        assertEquals(want, have);
    }

    @Test(expected = NullPointerException.class)
    public void resourceMarketPriceNull() {
        // arrange
        final ResourceMarket sut = getSut();

        // act
        sut.getPrice(null);
    }
}
