package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Board;
import edu.hm.cs.rs.powergrid.datastore.City;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class BoardTest {
    private final Edition edition = new EditionGermany();
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;
    private OpenFactory factory;

    @Before
    public void initFactory() {
        factory = OpenFactory.newFactory(TestConstants.FACTORY_FQCN);
    }

    protected OpenFactory getFactory() {
        return factory;
    }

    protected Edition getEdition() {
        return edition;
    }

    protected Board getSut() {
        return getFactory().newBoard(getEdition());
    }

    @Test
    public void newBoardNotNull() {
        // act
        final Board sut = getSut();

        // assert
        assertNotNull(sut);
    }

    @Test(expected = NullPointerException.class)
    public void newBoardInvalid() {
        // act
        getFactory().newBoard(null);
    }

    @Test
    public void newBoard() {
        // act
        final Board sut = getSut();
        final boolean haveBoardCityEmpty = sut.getCities().isEmpty();

        // assert
        assertFalse(haveBoardCityEmpty);
    }

    @Test
    public void boardFindCityInvalid() {
        // arrange
        final Board board = getSut();

        // act
        final City have = board.findCity("this is a name");

        // assert
        assertNull(have);
    }
}
