package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.Bag;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Plant.Type;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.severin.powergrid.ListBag;
import edu.hm.severin.powergrid.datastore.NeutralPlant;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.Set;

import static edu.hm.cs.rs.powergrid.datastore.Resource.Coal;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Garbage;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Oil;
import static edu.hm.cs.rs.powergrid.datastore.Resource.Uranium;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class PlantTest {
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;

    protected Plant getSUT(int number, Type type, int resources, int cities) {
        return new NeutralPlant(number, type, resources, cities);
    }

    // constructor and getter
    @Test(expected = IllegalArgumentException.class)
    public void constructorInvalidNumber() {
        // arrange
        getSUT(-1, Plant.Type.Coal, 5, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorInvalidResources() {
        // arrange
        getSUT(14, Plant.Type.Eco, -4, 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorNegativeCities() {
        // arrange
        getSUT(14, Plant.Type.Eco, 143, -1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorTypeNull() {
        // arrange
        getSUT(14, null, 143, 41);
    }

    @Test
    public void allGetter1() {
        // arrange
        final int wantNumber = 1;
        final Type wantType = Type.Oil;
        final int wantResource = 2;
        final int wantCities = 3;
        final Plant sut = getSUT(wantNumber, wantType, wantResource, wantCities);

        // act
        final int haveNumber = sut.getNumber();
        final Plant.Type have = sut.getType();
        final int haveResources = sut.getNumberOfResources();
        final int haveCities = sut.getCities();

        // assert
        assertEquals(wantNumber, haveNumber);
        assertEquals(wantType, have);
        assertEquals(wantResource, haveResources);
        assertEquals(wantCities, haveCities);
    }

    @Test
    public void allGetter2() {
        // arrange
        final int wantNumber = 5;
        final Type wantType = Type.Fusion;
        final int wantResource = 8;
        final int wantCities = 9;
        final Plant sut = getSUT(wantNumber, wantType, wantResource, wantCities);

        // act
        final int haveNumber = sut.getNumber();
        final Plant.Type have = sut.getType();
        final int haveResources = sut.getNumberOfResources();
        final int haveCities = sut.getCities();

        // assert
        assertEquals(wantNumber, haveNumber);
        assertEquals(wantType, have);
        assertEquals(wantResource, haveResources);
        assertEquals(wantCities, haveCities);
    }

    @Test
    public void allGetter3() {
        // arrange
        final int wantNumber = 1;
        final Type wantType = Type.Coal;
        final int wantResource = 1;
        final int wantCities = 1;
        final Plant sut = getSUT(wantNumber, wantType, wantResource, wantCities);

        // act
        final int haveNumber = sut.getNumber();
        final Plant.Type have = sut.getType();
        final int haveResources = sut.getNumberOfResources();
        final int haveCities = sut.getCities();

        // assert
        assertEquals(wantNumber, haveNumber);
        assertEquals(wantType, have);
        assertEquals(wantResource, haveResources);
        assertEquals(wantCities, haveCities);
    }

    @Test
    public void allGetter4() {
        // arrange
        final int wantNumber = 9999999;
        final Type wantType = Type.Garbage;
        final int wantResource = 2;
        final int wantCities = 999999;
        final Plant sut = getSUT(wantNumber, wantType, wantResource, wantCities);

        // act
        final int haveNumber = sut.getNumber();
        final Plant.Type have = sut.getType();
        final int haveResources = sut.getNumberOfResources();
        final int haveCities = sut.getCities();

        // assert
        assertEquals(wantNumber, haveNumber);
        assertEquals(wantType, have);
        assertEquals(wantResource, haveResources);
        assertEquals(wantCities, haveCities);
    }

    @Test
    public void allGetter5() {
        // arrange
        final int wantNumber = 123;
        final Type wantType = Type.Hybrid;
        final int wantResource = 45;
        final int wantCities = 1;
        final Plant sut = getSUT(wantNumber, wantType, wantResource, wantCities);

        // act
        final int haveNumber = sut.getNumber();
        final Plant.Type have = sut.getType();
        final int haveResources = sut.getNumberOfResources();
        final int haveCities = sut.getCities();

        // assert
        assertEquals(wantNumber, haveNumber);
        assertEquals(wantType, have);
        assertEquals(wantResource, haveResources);
        assertEquals(wantCities, haveCities);
    }

    // hasOperated
    @Test
    public void hasOperatedInitial() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Oil, 0, 1);

        // act
        final boolean have = sut.hasOperated();

        // assert
        assertFalse(have);
    }

    // getResource
    @Test
    public void plantSingleResource() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Oil, 3, 4);

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantSingleResource2() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Uranium, 4, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(Uranium, Uranium, Uranium, Uranium));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantSingleResource3() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Uranium, 4, 3);
        final int want = 1;

        // act
        final int have = sut.getResources().size();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void plantSingleResource4() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Uranium, 1, 3);
        final int want = 1;

        // act
        final int have = sut.getResources().size();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void plantHybridResource1() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 3, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantHybridResource2() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 3, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantHybridResource3() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 3, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Coal, Coal));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantHybridResource4() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 3, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Coal));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantHybridResource5() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 4, 3);
        final Resource coal = Coal;

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(coal, coal, coal, coal));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantHybridResource6() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 4, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil, Oil));

        // assert
        assertTrue(have);
    }

    @Test
    public void plantHybridResource7() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 2, 3);

        // act
        final boolean haveSameCoal = sut.getResources().contains(new ListBag<>(Coal, Coal));
        final boolean haveDifferent = sut.getResources().contains(new ListBag<>(Oil, Coal));
        final boolean haveSameOil = sut.getResources().contains(new ListBag<>(Oil, Oil));

        // assert
        assertTrue(haveSameOil);
        assertTrue(haveDifferent);
        assertTrue(haveSameCoal);

    }

    @Test
    public void plantNoResource0() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Eco, 0, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertTrue(have);
    }

    @Test
    public void plantNoResource2() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Fusion, 4, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertTrue(have);
    }

    @Test
    public void plantNoResource3() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Level3, 4, 3);

        // act
        final boolean have = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertTrue(have);
    }

    @Test
    public void getResourcesCoal0() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Coal, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveContains = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertEquals(wantSize, haveSize);
        assertTrue(haveContains);
    }

    @Test
    public void getResourcesCoal1() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Coal, 1, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmptyBag = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveCoalBag = sut.getResources().contains(new ListBag<>(Coal));

        // assert
        assertEquals(wantSize, haveSize);
        assertTrue(haveCoalBag);
        assertFalse(haveEmptyBag);
    }

    @Test
    public void getResourcesCoal2() {
        // arrange
        final Plant sut = getSUT(2, Plant.Type.Coal, 2, 2);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmptyBag = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveCoalBag = sut.getResources().contains(new ListBag<>(Coal));
        final boolean haveCoalBag2 = sut.getResources().contains(new ListBag<>(Coal, Coal));

        // assert
        assertEquals(wantSize, haveSize);
        assertTrue(haveCoalBag2);
        assertFalse(haveEmptyBag);
        assertFalse(haveCoalBag);
    }

    @Test
    public void getResourcesCoal3() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Coal, 3, 3);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveCoal1 = sut.getResources().contains(new ListBag<>(Coal));
        final boolean haveCoal2 = sut.getResources().contains(new ListBag<>(Coal, Coal));
        final boolean haveCoal3 = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertFalse(haveCoal1);
        assertFalse(haveCoal2);
        assertTrue(haveCoal3);
    }

    @Test
    public void getResourcesGarbage0() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Garbage, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesGarbage1() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Garbage, 1, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveGarbage = sut.getResources().contains(new ListBag<>(Garbage));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertTrue(haveGarbage);
    }

    @Test
    public void getResourcesGarbage2() {
        // arrange
        final Plant sut = getSUT(2, Plant.Type.Garbage, 2, 2);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveGarbage = sut.getResources().contains(new ListBag<>(Garbage));
        final boolean haveGarbage2 = sut.getResources().contains(new ListBag<>(Garbage, Garbage));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertFalse(haveGarbage);
        assertTrue(haveGarbage2);
    }

    @Test
    public void getResourcesGarbage3() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Garbage, 3, 3);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveGarbage = sut.getResources().contains(new ListBag<>(Garbage));
        final boolean haveGarbage2 = sut.getResources().contains(new ListBag<>(Garbage, Garbage));
        final boolean haveGarbage3 = sut.getResources().contains(new ListBag<>(Garbage, Garbage, Garbage));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertFalse(haveGarbage);
        assertFalse(haveGarbage2);
        assertTrue(haveGarbage3);
    }

    @Test
    public void getResourcesUranium0() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Uranium, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesUranium1() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Uranium, 1, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveUranium = sut.getResources().contains(new ListBag<>(Uranium));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertTrue(haveUranium);
    }

    @Test
    public void getResourcesUranium2() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Uranium, 2, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveUranium = sut.getResources().contains(new ListBag<>(Uranium));
        final boolean haveUranium2 = sut.getResources().contains(new ListBag<>(Uranium, Uranium));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertFalse(haveUranium);
        assertTrue(haveUranium2);
    }

    @Test
    public void getResourcesUranium3() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Uranium, 3, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveUranium = sut.getResources().contains(new ListBag<>(Uranium));
        final boolean haveUranium2 = sut.getResources().contains(new ListBag<>(Uranium, Uranium));
        final boolean haveUranium3 = sut.getResources().contains(new ListBag<>(Uranium, Uranium, Uranium));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertFalse(haveUranium);
        assertFalse(haveUranium2);
        assertTrue(haveUranium3);
    }

    @Test
    public void getResourcesOil0() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Oil, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesOil1() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Oil, 1, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveOil = sut.getResources().contains(new ListBag<>(Oil));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertTrue(haveOil);
    }

    @Test
    public void getResourcesOil2() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Oil, 2, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveOil = sut.getResources().contains(new ListBag<>(Oil));
        final boolean haveOil2 = sut.getResources().contains(new ListBag<>(Oil, Oil));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertFalse(haveOil);
        assertTrue(haveOil2);
    }

    @Test
    public void getResourcesOil3() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Oil, 3, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveOil = sut.getResources().contains(new ListBag<>(Oil));
        final boolean haveOil2 = sut.getResources().contains(new ListBag<>(Oil, Oil));
        final boolean haveOil3 = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertFalse(haveOil);
        assertFalse(haveOil2);
        assertTrue(haveOil3);
    }

    @Test
    public void getResourcesEco0() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Eco, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesEco1() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Eco, 1, 1);
        final int wantSize = 1;

        //act
        final int haveSize = 1;
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean isEmpty = sut.getResources().isEmpty();

        // assert
        assertFalse(isEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesEco2() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Eco, 2, 1);
        final int wantSize = 1;

        //act
        final int haveSize = 1;
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean isEmpty = sut.getResources().isEmpty();

        // assert
        assertFalse(isEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesEco3() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Eco, 3, 1);
        final int wantSize = 1;

        //act
        final int haveSize = 1;
        final boolean amEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean isEmpty = sut.getResources().isEmpty();

        // assert
        assertFalse(isEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(amEmpty);
    }

    @Test
    public void getResourcesEco100() {
        // arrange
        final Plant sut = getSUT(100, Plant.Type.Eco, 100, 100);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean amEmpty = sut.getResources().isEmpty();

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesFusion0() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Fusion, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesFusion1() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Fusion, 1, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesFusion2() {
        // arrange
        final Plant sut = getSUT(2, Plant.Type.Fusion, 2, 2);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesFusion3() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Fusion, 3, 3);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesFusion100() {
        // arrange
        final Plant sut = getSUT(100, Plant.Type.Fusion, 100, 100);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesHybrid0() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Hybrid, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesHybrid1() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Hybrid, 1, 1);
        final int wantSize = 2;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveCoal = sut.getResources().contains(new ListBag<>(Coal));
        final boolean haveOil = sut.getResources().contains(new ListBag<>(Oil));
        final boolean amEmpty = sut.getResources().isEmpty();

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertTrue(haveCoal);
        assertTrue(haveOil);
    }

    @Test
    public void getResourcesHybrid2() {
        // arrange
        final Plant sut = getSUT(2, Plant.Type.Hybrid, 2, 2);
        final int wantSize = 3;

        // act
        final int haveSize = sut.getResources().size();
        final boolean havEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveCoal2 = sut.getResources().contains(new ListBag<>(Coal, Coal));
        final boolean haveOil2 = sut.getResources().contains(new ListBag<>(Oil, Oil));
        final boolean haveMixed = sut.getResources().contains(new ListBag<>(Coal, Oil));
        final boolean haveMixedReversed = sut.getResources().contains(new ListBag<>(Oil, Coal));

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertFalse(havEmpty);
        assertTrue(haveCoal2);
        assertTrue(haveOil2);
        assertTrue(haveMixed);
        assertTrue(haveMixedReversed);
    }

    @Test
    public void getResourcesHybrid3() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Hybrid, 3, 3);
        final int wantSize = 4;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveCoalSame = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal));
        final boolean haveOilSame = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil));
        final boolean haveMixed = sut.getResources().contains(new ListBag<>(Coal, Coal, Oil));
        final boolean haveMixedReversed = sut.getResources().contains(new ListBag<>(Coal, Oil, Oil));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertTrue(haveCoalSame);
        assertTrue(haveOilSame);
        assertTrue(haveMixed);
        assertTrue(haveMixedReversed);
    }

    @Test
    public void getResourcesHybrid4() {
        // arrange
        final Plant sut = getSUT(4, Plant.Type.Hybrid, 4, 4);
        final int wantSize = 5;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveCoalSame = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Coal));
        final boolean haveOilSame = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil, Oil));
        final boolean haveMixed3Same = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Oil));
        final boolean haveMixed3SameReversed = sut.getResources().contains(new ListBag<>(Coal, Oil, Oil, Oil));
        final boolean haveSplit = sut.getResources().contains(new ListBag<>(Coal, Coal, Oil, Oil));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertTrue(haveCoalSame);
        assertTrue(haveOilSame);
        assertTrue(haveMixed3Same);
        assertTrue(haveMixed3SameReversed);
        assertTrue(haveSplit);
    }

    @Test
    public void getResourcesHybrid5() {
        // arrange
        final Plant sut = getSUT(5, Plant.Type.Hybrid, 5, 5);
        final int wantSize = 6;

        // act
        final int haveSize = sut.getResources().size();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());
        final boolean haveSameCoal = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Coal, Coal));
        final boolean haveSameOil = sut.getResources().contains(new ListBag<>(Oil, Oil, Oil, Oil, Oil));
        final boolean haveMixed4Same = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Coal, Oil));
        final boolean haveMixed4SameReversed = sut.getResources().contains(new ListBag<>(Coal, Oil, Oil, Oil, Oil));
        final boolean haveMixed3Same = sut.getResources().contains(new ListBag<>(Coal, Coal, Oil, Oil, Oil));
        final boolean haveMixed3SameReversed = sut.getResources().contains(new ListBag<>(Coal, Coal, Coal, Oil, Oil));

        // assert
        assertEquals(wantSize, haveSize);
        assertFalse(haveEmpty);
        assertTrue(haveSameCoal);
        assertTrue(haveSameOil);
        assertTrue(haveMixed3Same);
        assertTrue(haveMixed3SameReversed);
        assertTrue(haveMixed4Same);
        assertTrue(haveMixed4SameReversed);
    }

    @Test
    public void getResourcesLevel30() {
        // arrange
        final Plant sut = getSUT(0, Plant.Type.Level3, 0, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesLevel31() {
        // arrange
        final Plant sut = getSUT(1, Plant.Type.Level3, 1, 1);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesLevel32() {
        // arrange
        final Plant sut = getSUT(2, Plant.Type.Level3, 2, 2);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

    @Test
    public void getResourcesLevel33() {
        // arrange
        final Plant sut = getSUT(3, Plant.Type.Level3, 3, 3);
        final int wantSize = 1;

        // act
        final int haveSize = sut.getResources().size();
        final boolean amEmpty = sut.getResources().isEmpty();
        final boolean haveEmpty = sut.getResources().contains(new ListBag<Resource>());

        // assert
        assertFalse(amEmpty);
        assertEquals(wantSize, haveSize);
        assertTrue(haveEmpty);
    }

   /* @Test
    public void getResourceTEST(){
        final Plant sut = getSUT(3, Plant.Type.Ultimate, 3, 3);
        Resource Oil = Resource.Oil;
        Resource coal = Resource.Coal;
        Resource uranium = Resource.Uranium;
        Bag<Resource> b1 = new ListBag<>(Arrays.asList(Oil,Oil,Oil));
        Bag<Resource> b6 = new ListBag<>(Arrays.asList(coal,coal,coal));
        Bag<Resource> b9 = new ListBag<>(Arrays.asList(uranium,uranium,uranium));

        Bag<Resource> b7 = new ListBag<>(Arrays.asList(coal,coal,uranium));
        Bag<Resource> b4 = new ListBag<>(Arrays.asList(coal,coal,Oil));
        Bag<Resource> b8 = new ListBag<>(Arrays.asList(uranium,uranium,coal));
        Bag<Resource> b5 = new ListBag<>(Arrays.asList(uranium,uranium,Oil));
        Bag<Resource> b2 = new ListBag<>(Arrays.asList(Oil, Oil, coal));
        Bag<Resource> b3 = new ListBag<>(Arrays.asList(Oil,Oil,uranium));

        Bag<Resource> b10 = new ListBag<>(Arrays.asList(Oil,uranium,coal));

        Set<Bag<Resource>> bag = new HashSet<>(List.of(b1,b2,b3,b4,b5,b6,b7,b8,b9,b10));
        assertEquals(bag.size(),sut.getResources().size());
    }*/

}
