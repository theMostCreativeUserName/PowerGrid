package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.Resource;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.severin.powergrid.datastore.NeutralPlayer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class PlayerTest {
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;
    private OpenFactory factory;

    @Before
    public void initFactory() {
        factory = OpenFactory.newFactory(TestConstants.FACTORY_FQCN);
    }

    protected OpenFactory getFactory() {
        return factory;
    }

    protected Player getSUT(String secret, String color) {
        return new NeutralPlayer(secret, color);
    }

    // constructor and getter
    @Test
    public void constructorValid() {
        // arrange
        final String wantSecret = "psst";
        final String wantColor = "random color";
        final Player sut = getSUT(wantSecret, wantColor);

        // act
        final String haveSecret = sut.getSecret();
        final String haveColor = sut.getColor();

        // assert
        assertEquals(wantColor, haveColor);
        assertEquals(wantSecret, haveSecret);
    }

    @Test(expected = NullPointerException.class)
    public void constructorSecretNull() {
        // arrange
        getSUT(null, "weird color");
    }

    @Test
    public void constructorSecretEmpty() {
        // arrange
        getSUT("", "brown color");
    }

    @Test(expected = NullPointerException.class)
    public void constructorColorNull() {
        // arrange
        getSUT("psssssst", null);
    }

    @Test
    public void constructorColorEmpty() {
        // arrange
        getSUT("hello there", "");
    }

    @Test(expected = NullPointerException.class)
    public void constructorSecretColorNull() {
        // arrange
        getSUT(null, null);
    }

    @Test
    public void constructorSecretColorEmpty() {
        // arrange
        getSUT("", "");
    }

    // getSecret and hasSecret
    @Test
    public void getSecretOnce() {
        // arrange
        final String want = "green";
        final Player sut = getSUT(want, "yellow");

        // act
        final String have = sut.getSecret();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void getSecretTwice() {
        // arrange
        final Player sut = getSUT("blue", "green");

        // act
        sut.getSecret();
        final String have = sut.getSecret();

        // assert
        assertNull(have);
    }


    // getElectro and setElectro
    @Test
    public void getElectro() {
        // arrange
        final int want = 0;
        final Player sut = getSUT("asjdf82u83jf2j", "light green");

        // act
        final int have = sut.getElectro();

        // assert
        assertEquals(want, have);
    }


    // setPassed and hasPassed
    @Test
    public void getPassed() {
        // arrange
        final Player sut = getSUT(":)", ":(");

        // act
        final boolean have = sut.hasPassed();

        // assert
        assertFalse(have);
    }


    // getCities
    @Test
    public void getCitiesEmpty() {
        // arrange
        final Player sut = getSUT("i", "o");

        // act
        final boolean have = sut.getCities().isEmpty();

        // assert
        assertTrue(have);
    }


    // getPlants
    @Test
    public void getPlantsEmpty() {
        // arrange
        final Player sut = getSUT("784,", "88234");

        // act
        final boolean have = sut.getPlants().isEmpty();

        // assert
        assertTrue(have);
    }


    // getResources
    @Test
    public void getResourcesInit() {
        // arrange
        final Player sut = getSUT("random secret", "green");

        // act
        final boolean have = sut.getResources().isEmpty();

        // assert
        assertTrue(have);
    }

    // compareTo
    @Test
    public void compareToSame() {
        // arrange
        final int want = 0;
        final Player sut = getSUT("secret", "green");
        final Player sut2 = getSUT("secret", "green");

        // act
        final int haveSutToSut2 = sut.compareTo(sut2);
        final int haveSut2ToSut = sut2.compareTo(sut);

        // assert
        assertEquals(want, haveSut2ToSut);
        assertEquals(want, haveSutToSut2);
    }

    // mutability checks
    @Test(expected = UnsupportedOperationException.class)
    public void getPlantsImmutable() {
        // arrange
        final Player sut = getSUT("psasdf", "gajsk");

        // act
        sut.getPlants().add(getFactory().newPlant(13, Plant.Type.Coal, 63, 14));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void getResourcesImmutable() {
        // arrange
        final Player sut = getSUT("psasdf", "gajsk");

        // act
        sut.getResources().add(Resource.Coal);
    }
}
