package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.datastore.City;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CityTest {
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;

    private OpenFactory factory;

    @Before
    public void initFactory() {
        factory = OpenFactory.newFactory(TestConstants.FACTORY_FQCN);
    }

    protected City getSUT(String name, int region) {
        return this.factory.newCity(name, region);
    }

    // invalid constructors
    @Test(expected = NullPointerException.class)
    public void nullName() {
        // arrange
        getSUT(null, 5);
    }

    @Test(expected = IllegalArgumentException.class)
    public void blankName1() {
        // arrange
        getSUT("", 5);
    }

    @Test(expected = IllegalArgumentException.class)
    public void blankName2() {
        // arrange
        getSUT("   ", 2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void blankName3() {
        // arrange
        getSUT("\n", 1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void invalidRegion1() {
        // arrange
        getSUT("a valid name", 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void invalidRegion2() {
        // arrange
        getSUT("a valid name", -1);
    }

    // getName
    @Test
    public void getName1() {
        // arrange
        final String want = "A Name!";
        final City sut = getSUT(want, 5);

        // act
        final String have = sut.getName();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void getName2() {
        // arrange
        final String want = "any other name";
        final City sut = getSUT(want, 1);

        // act
        final String have = sut.getName();

        // assert
        assertEquals(want, have);
    }

    // getRegion
    @Test
    public void getRegion1() {
        // arrange
        final int want = 1;
        final City sut = getSUT("name", want);

        // act
        final int have = sut.getRegion();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void getRegion2() {
        // arrange
        final int want = Integer.MAX_VALUE;
        final City sut = getSUT("name", want);

        // act
        final int have = sut.getRegion();

        // assert
        assertEquals(want, have);
    }

    // getConnections
    @Test
    public void getConnectionsInitEmpty() {
        // arrange
        final City sut = getSUT("any name", 1);

        // act
        final boolean have = sut.getConnections().isEmpty();

        // assert
        assertTrue(have);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void getConnectionsAdd() {
        // arrange
        final int wantCost = 15;
        final City sut = getSUT("any name", 1);
        final City target = getSUT("target", 2);

        // act
        sut.getConnections().put(target, wantCost);
    }

    // close
    @Test(expected = IllegalStateException.class)
    public void closeOnceNoConnections() {
        // arrange
        final City sut = getSUT("name1", 5);

        // act
        sut.close();
    }

    // compareTo
    @Test
    public void compareTo1() {
        // arrange
        final City sut = getSUT("abc", 15);
        final City sut2 = getSUT("abc", 17);

        // act
        final boolean equals = sut.compareTo(sut2) == 0;
        final boolean equalsOtherWay = sut2.compareTo(sut) == 0;

        // assert
        assertTrue(equals);
        assertTrue(equalsOtherWay);
    }

    @Test
    public void compareTo2() {
        // arrange
        final City sut = getSUT("abc", 1);
        final City sut2 = getSUT("ABC", 1);

        // act
        final boolean equals = sut.compareTo(sut2) == 0;
        final boolean equalsOtherWay = sut2.compareTo(sut) == 0;

        // assert
        assertTrue(equals);
        assertTrue(equalsOtherWay);
    }

    @Test
    public void compareTo3() {
        // arrange
        final City sut = getSUT("a", 1);
        final City sut2 = getSUT("z", 1);

        // act
        final boolean sutSmallerThanSut2 = sut.compareTo(sut2) < 0;
        final boolean sut2BiggerThanSut = sut2.compareTo(sut) > 0;

        // assert
        assertTrue(sutSmallerThanSut2);
        assertTrue(sut2BiggerThanSut);
    }

    @Test
    public void compareToWithSort() {
        // arrange
        final String city1Name = "aachen";
        final String city2Name = "Bauern";
        final String city3Name = "Dortmund";
        final String city4Name = "Kassel";
        final String city5Name = "Zypern";

        final City sut1 = getSUT(city5Name, 5);
        final City sut2 = getSUT(city3Name, 8);
        final City sut3 = getSUT(city2Name, 9);
        final City sut4 = getSUT(city1Name, 4);
        final City sut5 = getSUT(city4Name, 15);

        // act
        final List<City> cities = new ArrayList<>(Arrays.asList(sut4, sut5, sut3, sut1, sut2));
        Collections.sort(cities);

        final String haveCity1 = cities.get(0).getName();
        final String haveCity2 = cities.get(1).getName();
        final String haveCity3 = cities.get(2).getName();
        final String haveCity4 = cities.get(3).getName();
        final String haveCity5 = cities.get(4).getName();

        // assert
        assertEquals(city1Name, haveCity1);
        assertEquals(city2Name, haveCity2);
        assertEquals(city3Name, haveCity3);
        assertEquals(city4Name, haveCity4);
        assertEquals(city5Name, haveCity5);
    }
}
