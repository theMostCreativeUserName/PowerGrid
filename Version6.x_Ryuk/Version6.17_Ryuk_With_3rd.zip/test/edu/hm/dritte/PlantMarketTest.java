package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.PlantMarket;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.severin.powergrid.datastore.NeutralPlantMarket;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import static org.junit.Assert.assertEquals;

public class PlantMarketTest {
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;
    private OpenFactory factory;

    @Before
    public void initFactory() {
        factory = OpenFactory.newFactory(TestConstants.FACTORY_FQCN);
    }

    protected OpenFactory getFactory() {
        return factory;
    }

    protected PlantMarket getSut() {
        return new NeutralPlantMarket(new EditionGermany(), factory);
    }

    @Test
    public void plantMarket() {
        // arrange
        final PlantMarket plantMarket = getSut();
        final int want = 0;
        final int wanthidden = 42;

        // act
        final int actualSize = plantMarket.getActual().size();
        final int futureSize = plantMarket.getFuture().size();
        final int hiddenSize = plantMarket.getNumberHidden();

        // assert
        assertEquals(want, actualSize);
        assertEquals(want, futureSize);
        assertEquals(wanthidden, hiddenSize);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void plantMarketActualAddOperation() {
        // arrange
        final PlantMarket plantMarket = getSut();

        // act
        plantMarket.getActual().add(getFactory().newPlant(2, Plant.Type.Coal, 3, 4));
    }

    @Test(expected = UnsupportedOperationException.class)
    public void plantMarketFutureAddOperation() {
        // arrange
        final PlantMarket plantMarket = getSut();

        // act
        plantMarket.getFuture().add(getFactory().newPlant(2, Plant.Type.Coal, 3, 4));
    }
}
