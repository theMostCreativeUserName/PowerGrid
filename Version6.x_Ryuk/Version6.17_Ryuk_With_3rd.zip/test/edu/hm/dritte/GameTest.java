package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.Edition;
import edu.hm.cs.rs.powergrid.EditionGermany;
import edu.hm.cs.rs.powergrid.datastore.Auction;
import edu.hm.cs.rs.powergrid.datastore.Board;
import edu.hm.cs.rs.powergrid.datastore.Game;
import edu.hm.cs.rs.powergrid.datastore.Phase;
import edu.hm.cs.rs.powergrid.datastore.PlantMarket;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.ResourceMarket;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class GameTest {
    private final Edition edition = new EditionGermany();
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;
    private OpenFactory factory;

    @Before
    public void initFactory() {
        factory = OpenFactory.newFactory(TestConstants.FACTORY_FQCN);
    }

    protected OpenFactory getFactory() {
        return factory;
    }

    protected Edition getEdition() {
        return edition;
    }

    protected Game getSut() {
        return getFactory().newGame(getEdition());
    }

    @Test
    public void game() {
        // arrange
        final Class<?> wantEdition = getEdition().getClass();
        final int wantRound = 0;
        final Phase wantPhase = Phase.Opening;
        final List<Player> wantPlayers = new ArrayList<>();
        final int wantLevel = 0;
        final int wantMoves = 0;

        // act
        final Game sut = getSut();
        final Class<?> haveEdition = sut.getEdition().getClass();
        final int haveRound = sut.getRound();
        final Phase havePhase = sut.getPhase();
        final List<Player> havePlayers = sut.getPlayers();
        final int haveLevel = sut.getLevel();
        final int haveMoves = sut.getNumMoves();
        final Auction haveAuction = sut.getAuction();
        final ResourceMarket haveResourceMarket = sut.getResourceMarket();
        final PlantMarket havePlantMarket = sut.getPlantMarket();
        final Board haveBoard = sut.getBoard();

        // assert
        assertEquals(wantEdition, haveEdition);
        assertEquals(wantRound, haveRound);
        assertEquals(wantPhase, havePhase);
        assertEquals(wantPlayers, havePlayers);
        assertEquals(wantLevel, haveLevel);
        assertEquals(wantMoves, haveMoves);
        assertNull(haveAuction);
        assertNotNull(haveResourceMarket);
        assertNotNull(havePlantMarket);
        assertNotNull(haveBoard);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void gameGetPlayersImmutable() {
        // arrange
        final Game sut = getSut();

        // act
        sut.getPlayers().remove(0);
    }
}
