package edu.hm.dritte;

import edu.hm.TestConstants;
import edu.hm.cs.rs.powergrid.datastore.Auction;
import edu.hm.cs.rs.powergrid.datastore.Plant;
import edu.hm.cs.rs.powergrid.datastore.Player;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenFactory;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlant;
import edu.hm.cs.rs.powergrid.datastore.mutable.OpenPlayer;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class AuctionTest {
    @Rule
    public Timeout globalTimeout = TestConstants.TIMEOUT;
    private OpenFactory factory;

    @Before
    public void initFactory() {
        factory = OpenFactory.newFactory(TestConstants.FACTORY_FQCN);
    }

    protected OpenFactory getFactory() {
        return factory;
    }

    protected Auction getSut(OpenPlant plant, List<OpenPlayer> playerList) {
        return getFactory().newAuction(plant, playerList);
    }

    @Test(expected = NullPointerException.class)
    public void constructorPlantNull() {
        // arrange
        final OpenPlayer player = getFactory().newPlayer("123456", "123456");
        final List<OpenPlayer> players = new ArrayList<>();
        players.add(player);

        // act
        getSut(null, players);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorPlayersNull() {
        // arrange
        final OpenPlant plant = getFactory().newPlant(1, Plant.Type.Oil, 2, 3);

        // act
        getSut(plant, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorPlayersEmpty() {
        // arrange
        final OpenPlant plant = getFactory().newPlant(1, Plant.Type.Oil, 2, 3);
        final List<OpenPlayer> players = new ArrayList<>();

        // act
        getSut(plant, players);
    }

    @Test
    public void getPlant() {
        // arrange
        final OpenPlant want = getFactory().newPlant(1, Plant.Type.Oil, 2, 3);
        final List<OpenPlayer> players = new ArrayList<>();
        players.add(getFactory().newPlayer("123456", "123456"));
        players.add(getFactory().newPlayer("654321", "654321"));

        // act
        final Auction sut = getSut(want, players);
        final Plant have = sut.getPlant();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void getAmount() {
        // arrange
        final int want = 5;
        final OpenPlant plant = getFactory().newPlant(want, Plant.Type.Oil, 2, 3);
        final List<OpenPlayer> players = new ArrayList<>();
        players.add(getFactory().newPlayer("123456", "123456"));
        players.add(getFactory().newPlayer("654321", "654321"));

        // act
        final Auction sut = getSut(plant, players);
        final int have = sut.getAmount();

        // assert
        assertEquals(want, have);
    }

    @Test
    public void getPlayers() {
        // arrange
        final OpenPlant plant = getFactory().newPlant(1, Plant.Type.Oil, 2, 3);
        final List<OpenPlayer> want = new ArrayList<>();
        want.add(getFactory().newPlayer("123456", "123456"));
        want.add(getFactory().newPlayer("654321", "654321"));

        // act
        final Auction sut = getSut(plant, want);
        final List<Player> have = sut.getPlayers();

        // assert
        assertEquals(want, have);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void getPlayersImmutable() {
        // arrange
        final OpenPlant plant = getFactory().newPlant(1, Plant.Type.Oil, 2, 3);
        final List<OpenPlayer> want = new ArrayList<>();
        want.add(getFactory().newPlayer("123456", "123456"));
        want.add(getFactory().newPlayer("654321", "654321"));

        // act
        final Auction sut = getSut(plant, want);
        sut.getPlayers().remove(0); // Exception
    }
}
